# Group_89_Billboard
CAB302 Billboard 60% Assignment

Team Members: 
Celine, Daniela, Manoo, Gauri, Elena

Billboard Viewer: 
- Elena

Billboard Control Panel:
- Gauri 
- Manoo

Billboard Server: 
- Daniela 
- Celine

***Change if incorrect.***
