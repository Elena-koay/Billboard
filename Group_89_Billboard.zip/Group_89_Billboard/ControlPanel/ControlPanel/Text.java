package ControlPanel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.ConnectException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Properties;

import static java.awt.Color.*;

public class Text extends JFrame implements ActionListener {
    //Containers
    int port;
    String username, SessionToken;
    Boolean continues = false;
    Boolean continuecreation = false;
    private static String hostName;
    //Labels
    JLabel message_billboard = new JLabel("Message Billboard");
    JLabel fontLabel = new JLabel("The quick brown fox jumps over the lazy dog.");
    JLabel text = new JLabel("ENTER YOUR TEXT");
    JLabel name = new JLabel("Enter Name Of Billboard");
    //Text fields
    JTextField nameb = new JTextField("");
    JTextField TEXT = new JTextField("");
    //Combo boxes
    JComboBox fontsize = new JComboBox();
    JComboBox fontStyleBox = new JComboBox();
    JComboBox colors = new JComboBox();
    //Buttons
    JButton Confirm = new JButton("Preview");
    JButton Back = new JButton("Back");
    JButton Save = new JButton("Save");
    JButton logout = new JButton("Logout");
    //container
    Container c = getContentPane();
    //String
    String sizes[] = {"10", "12", "14", "16", "18", "20", "24"};
    String color[] = {"BLACK", "RED", "BLUE", "YELLOW", "PINK", "WHITE"};
    String fontstyles[] = {"PLAIN", "BOLD", "ITALIC"};
    String HexColor;
    String nameBillboard = "Billboard";
    String xml;
    String fontSelected = "PLAIN", ColorSelected = "Black", SizeSelected = "10";
    String FinalText;

    //Font
    Font font = new Font("Arial", Font.BOLD, 12);
    //Login
    Login log = new Login();
    //Socket
    Socket s;

    //Constructor
    Text() {
        setLayoutManager();
        setLocationAndSize();
        ListFunction();
        addComponents();
        addActionEvent();
    }

    //Function to Add Items to Combo Box
    public void ListFunction() {
        //Font Style Combo Box
        fontStyleBox.setEditable(true);
        for (int i = 0; i < fontstyles.length; i++) {
            fontStyleBox.addItem(fontstyles[i]);
        }
        //Font Colors Combo Box
        colors.setEditable(true);
        for (int i = 0; i < color.length; i++) {
            colors.addItem(color[i]);
        }
        //Font Size Combo Box
        fontsize.setEditable(true);
        for (int i = 0; i < sizes.length; i++) {
            fontsize.addItem(sizes[i]);
        }
    }

    //Function to add components to the container
    public void addComponents() {
        c.add(message_billboard);
        c.add(name);
        c.add(nameb);
        c.add(fontLabel);
        c.add(text);
        c.add(TEXT);
        c.add(fontsize);
        c.add(fontStyleBox);
        c.add(colors);
        c.add(Confirm);
        c.add(Save);
        c.add(logout);
        c.add(Back);
        c.setBackground(Color.WHITE);
        c.setForeground(Color.BLACK);
    }

    //Function to add action event to components
    public void addActionEvent() {
        Confirm.addActionListener(this);
        Save.addActionListener(this);
        Back.addActionListener(this);
        logout.addActionListener(this);
    }

    //Function to set Layout
    public void setLayoutManager() {
        //Setting layout manager of Container to null
        c.setLayout(null);
    }

    //Function to set the location and sizes of different components
    public void setLocationAndSize() {
        message_billboard.setBounds(10, 10, 250, 40);
        logout.setBounds(300, 10, 75, 30);
        message_billboard.setFont(new Font("Arial", Font.BOLD, 18));
        name.setBounds(10, 60, 200, 40);
        nameb.setBounds(10, 110, 200, 40);
        fontLabel.setBounds(10, 160, 400, 40);
        text.setBounds(10, 210, 250, 40);
        TEXT.setBounds(10, 260, 200, 40);
        fontStyleBox.setBounds(10, 310, 150, 40);
        colors.setBounds(10, 360, 150, 40);
        fontsize.setBounds(10, 410, 150, 40);
        Confirm.setBounds(10, 460, 100, 40);
        Save.setBounds(10, 510, 100, 40);
        Back.setBounds(120, 510, 100, 40);
    }

    //Function to set font
    public void setFont(String fontSelected) {
        if (fontSelected == "PLAIN") {
            font = new Font("Arial", Font.PLAIN, 12);
            fontLabel.setFont(font);
        }
        if (fontSelected == "BOLD") {
            font = new Font("Arial", Font.BOLD, 12);
            fontLabel.setFont(font);
        }
        if (fontSelected == "ITALIC") {
            font = new Font("Arial", Font.ITALIC, 12);
            fontLabel.setFont(font);
        }
    }

    //Function to set Size
    public void setSize(String SizeSelected) {
        if (SizeSelected == "12") {
            if (fontSelected == "PLAIN") {
                font = new Font("Arial", Font.PLAIN, 12);
                fontLabel.setFont(font);
            } else if (fontSelected == "BOLD") {
                font = new Font("Arial", Font.BOLD, 12);
                fontLabel.setFont(font);
            } else if (fontSelected == "ITALIC") {
                font = new Font("Arial", Font.ITALIC, 12);
                fontLabel.setFont(font);
            }
        } else if (SizeSelected == "14") {
            if (fontSelected == "PLAIN") {
                font = new Font("Arial", Font.PLAIN, 14);
                fontLabel.setFont(font);
            } else if (fontSelected == "BOLD") {
                font = new Font("Arial", Font.BOLD, 14);
                fontLabel.setFont(font);
            } else if (fontSelected == "ITALIC") {
                font = new Font("Arial", Font.ITALIC, 14);
                fontLabel.setFont(font);
            }
        } else if (SizeSelected == "16") {
            if (fontSelected == "PLAIN") {
                font = new Font("Arial", Font.PLAIN, 16);
                fontLabel.setFont(font);

            } else if (fontSelected == "BOLD") {
                font = new Font("Arial", Font.BOLD, 16);
                fontLabel.setFont(font);
            } else if (fontSelected == "ITALIC") {
                font = new Font("Arial", Font.ITALIC, 16);
                fontLabel.setFont(font);
            }
        } else if (SizeSelected == "18") {
            if (fontSelected == "PLAIN") {
                font = new Font("Arial", Font.PLAIN, 18);
                fontLabel.setFont(font);
            } else if (fontSelected == "BOLD") {
                font = new Font("Arial", Font.BOLD, 18);
                fontLabel.setFont(font);

            } else if (fontSelected == "ITALIC") {
                font = new Font("Arial", Font.ITALIC, 18);
                fontLabel.setFont(font);
            }
        } else if (SizeSelected == "20") {
            if (fontSelected == "PLAIN") {
                font = new Font("Arial", Font.PLAIN, 20);
                fontLabel.setFont(font);
            } else if (fontSelected == "BOLD") {
                font = new Font("Arial", Font.BOLD, 20);
                fontLabel.setFont(font);
            } else if (fontSelected == "ITALIC") {
                font = new Font("Arial", Font.ITALIC, 20);
                fontLabel.setFont(font);
            }
        } else if (SizeSelected == "24") {
            if (fontSelected == "PLAIN") {
                font = new Font("Arial", Font.PLAIN, 24);
                fontLabel.setFont(font);
            } else if (fontSelected == "BOLD") {
                font = new Font("Arial", Font.BOLD, 24);
                fontLabel.setFont(font);
            } else if (fontSelected == "ITALIC") {
                font = new Font("Arial", Font.ITALIC, 24);
                fontLabel.setFont(font);
            }
        }
    }

    //Funtion to create XML
    public void createXML() {
        if(fontSelected=="PLAIN") {
            xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                    "<billboard background=\"#0000FF\">" +
                    "<message colour=\"" + HexColor + "\">" + FinalText + "</message>" +
                    "</billboard>";
        }
        else if(fontSelected=="BOLD"){
            xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                    "<billboard background=\"#0000FF\">" +
                    "<message colour=\"" + HexColor + "\"><b>" + FinalText + "</b></message>" +
                    "</billboard>";

        }
        else if(fontSelected=="ITALIC"){
            xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                    "<billboard background=\"#0000FF\">" +
                    "<message colour=\"" + HexColor + "\"><i>" + FinalText + "</i></message>" +
                    "</billboard>";

        }
    }

    //Function to set Color
    public void setColor(String ColorSelected) {
        if (ColorSelected == "RED") {
            fontLabel.setForeground(RED);
            HexColor = "#FF0000";
        } else if (ColorSelected == "BLUE") {
            fontLabel.setForeground(BLUE);
            HexColor = "#0000FF";
        } else if (ColorSelected == "BLACK") {
            fontLabel.setForeground(BLACK);
            HexColor = "#000000";
        } else if (ColorSelected == "YELLOW") {
            fontLabel.setForeground(YELLOW);
            HexColor = "#FFFF00";
        } else if (ColorSelected == "PINK") {
            fontLabel.setForeground(PINK);
            HexColor = "#FFC0CB";
        } else if (ColorSelected == "WHITE") {
            fontLabel.setForeground(WHITE);
            HexColor = "#FFFFFF";
        } else {
            fontLabel.setForeground(BLACK);
            HexColor = "#000000";
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String buttonString = e.getActionCommand();
        //Checks if preview button was clicked
        if (buttonString.equals("Preview")) {
            FinalText = TEXT.getText();
            fontSelected = String.valueOf(fontStyleBox.getSelectedItem());
            SizeSelected = String.valueOf(fontsize.getSelectedItem());
            ColorSelected = String.valueOf(colors.getSelectedItem());
            //checks for empty fields
            if (FinalText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Text Field cannot be empty");
            } else {
                fontLabel.setText(FinalText);
                setFont(fontSelected);
                setColor(ColorSelected);
                setSize(SizeSelected);
                createXML();
            }
        }
        //checks if Save button was clicked
        if (buttonString.equals("Save")) {
            nameBillboard = nameb.getText();
            FinalText = TEXT.getText();
            fontSelected = String.valueOf(fontStyleBox.getSelectedItem());
            SizeSelected = String.valueOf(fontsize.getSelectedItem());
            ColorSelected = String.valueOf(colors.getSelectedItem());
            //checks if fields are empty
            if (nameBillboard.isEmpty() || FinalText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Fields Cannot be Empty");
            } else {
                createXML();
                BufferedReader input = null;
                PrintWriter output = null;
                String currentDirectory = System.getProperty("user.dir");
                //reading from client props file
                try (InputStream client_properties = new FileInputStream(currentDirectory + "/client.props")) {
                    Properties client_props = new Properties();
                    // load a properties file
                    client_props.load(client_properties);

                    // get the port property value
                    port = Integer.parseInt(client_props.getProperty("srv.port"));
                    hostName = client_props.getProperty("srv.hostname").toString();
                    //sending reqquest to server
                    try {
                        SessionToken = log.getSessionToken();
                        s = new Socket(hostName, port);
                        System.out.println("Connecting to Server:" + hostName + " port:" + port);
                        output = new PrintWriter(s.getOutputStream(), true);
                        input = new BufferedReader(new InputStreamReader(s.getInputStream()));
                        output.println(SessionToken);
                        output.println("billboard:update:" + nameBillboard + ":" + xml);
                        String answer = "";
                        //reading response
                        while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                            System.out.println("{Server} Response:" + answer);
                            if (answer.equals("ACK")) {
                                continuecreation = true;
                            } else if (answer.contains("ERR")) {
                                continuecreation = false;
                            }
                        }
                        //reading response
                        while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                            System.out.println("{Server} Response:" + answer);
                            if (answer.equals("ACK:BILLBOARD_CREATED") || answer.equals("ACK:BILLBOARD_EDITED")) {
                                if (answer.equals("ACK:BILLBOARD_CREATED")) {
                                    JOptionPane.showMessageDialog(this, "Billboard created");
                                } else if (answer.equals("ACK:BILLBOARD_EDITED")) {
                                    JOptionPane.showMessageDialog(this, "Billboard edited");
                                }
                                continuecreation = true;
                            } else if (answer.contains("ERR")) {
                                continuecreation = false;
                                JOptionPane.showMessageDialog(this, answer);
                            }
                        }

                    } catch (UnknownHostException Se) {
                        System.err.println("Unknown host: " + hostName);
                        System.exit(1);
                    } catch (ConnectException Se) {
                        System.err.println("Connection refused by host: " + hostName);
                        System.exit(1);
                    } catch (IOException Se) {
                        Se.printStackTrace();
                    } catch (NullPointerException Se) {
                        System.out.println("NullPointerException thrown!");
                    }
                    // finally, close the socket and decrement runningThreads
                    finally {
                        System.out.println("closing");
                        try {
                            input.close();
                            output.close();
                            s.close();
                            System.out.flush();
                        } catch (IOException Se) {
                            System.out.println("Couldn't close socket");
                        }
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        }


            //checks  if logout button was pressed
            if (buttonString.equals("Logout")) {
                String currentDirectory = System.getProperty("user.dir");
                username = log.getUsername();
                SessionToken = log.getSessionToken();
                BufferedReader input = null;
                PrintWriter output = null;
                //reading from client props file
                try (InputStream client_properties = new FileInputStream(currentDirectory + "/client.props")) {
                    Properties client_props = new Properties();
                    // load a properties file
                    client_props.load(client_properties);

                    // get the port property value
                    port = Integer.parseInt(client_props.getProperty("srv.port"));
                    hostName = client_props.getProperty("srv.hostname").toString();
                    //writing to server
                    try {
                        s = new Socket(hostName, port);
                        output = new PrintWriter(s.getOutputStream(), true);
                        input = new BufferedReader(new InputStreamReader(s.getInputStream()));
                        output.println(SessionToken);
                        output.println("user:logout");
                        String answer = "";
                        //reading response
                        while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                            System.out.println("{Server} Response:" + answer);
                            if (answer.equals("Sucess: Logged Out")) {
                                continues = true;
                            } else if (answer.contains("ERR")) {
                                continues = false;
                            }
                        }
                        //reading response
                        while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                            System.out.println("{Server} Response:" + answer);
                            if (answer.equals("Sucess: Logged Out")) {
                                continues = true;
                            } else if (answer.contains("ERR")) {
                                continues = false;
                            }
                        }
                        //shows error
                        if (!continues) {
                            JOptionPane.showMessageDialog(this, answer);
                        } else {
                            //shows acknowledgement, closes connection, disposes current window, shows login window
                            JOptionPane.showMessageDialog(this, "Logout Succesfutl");
                            s.close();
                            dispose();
                            Login login = new Login();
                            login.setBackground(Color.BLACK);
                            login.setForeground(Color.WHITE);
                            login.setBounds(10, 10, 370, 600);
                            login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                            login.setVisible(true);
                            login.setTitle("Billboard Control Panel Login");

                        }
                    } catch (UnknownHostException Se) {
                        System.err.println("Unknown host: " + hostName);
                        System.exit(1);
                    } catch (ConnectException Se) {
                        System.err.println("Connection refused by host: " + hostName);
                        System.exit(1);
                    } catch (IOException Se) {
                        Se.printStackTrace();
                    } catch (NullPointerException Se) {
                        System.out.println("NullPointerException thrown!");
                    }
                    // finally, close the socket and decrement runningThreads
                    finally {
                        System.out.println("closing");
                        try {
                            input.close();
                            output.close();
                            s.close();
                            System.out.flush();
                        } catch (IOException Se) {
                            System.out.println("Couldn't close socket");
                        }
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }

        //Function to return back to previous screen
        if (buttonString.equals("Back")) {
            setVisible(false);
            JFrame CB = new CreateBillBoard();
            CB.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            CB.setBounds(20, 20, 400, 600);
            CB.setVisible(true);
            CB.setTitle("Create Billboard");
        }

    }
}
