package ControlPanel;

import org.w3c.dom.*;
import org.xml.sax.InputSource;
import javax.swing.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.ConnectException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Properties;

public class BillboardInfo extends JFrame implements ActionListener {
    //Integer
    int port;

    //Boolean
    Boolean continues = false;
    Boolean getinfo=false;

    //container
    Container c = getContentPane();

    //labels
    JLabel billinfo = new JLabel("Billboard Information");
    JLabel enterbillName = new JLabel("Billboard Name");
    JTextArea info = new JTextArea(16,58);

    //Scroll for textarea
    JScrollPane sp = new JScrollPane(info);

    //Textfield
    JTextField usernameText = new JTextField("");

    //String
    String userName = null;
    String username, SessionToken;
    private static String hostName;

    //Buttons
    JButton confirmButton = new JButton("Confirm");
    JButton Back = new JButton("Back");
    JButton logout = new JButton("Logout");

    //Object of login class
    Login log = new Login();

    //Constructor
    BillboardInfo(){
        setLayoutManager();
        setBounds();
        add();
        addActionEvent();
    }

    //Function to set Action Event to components
    public void addActionEvent() {
        confirmButton.addActionListener(this);
        Back.addActionListener(this);
        logout.addActionListener(this);
    }

    //Function to set layout to null
    public void setLayoutManager()
    {
        c.setLayout(null);
    }
    //Function to add components to container
    public void add(){
        c.add(logout);
        c.add(billinfo);
        c.add(enterbillName);
        c.add(usernameText);
        c.add(sp);
        c.add(confirmButton);
        c.add(Back);
        c.setBackground(Color.WHITE);
        c.setForeground(Color.BLACK);
    }

    //Function to set bounds to components
    public void setBounds(){
        logout.setBounds(300,10,75,30);
        billinfo.setFont(new Font("Arial ",Font.BOLD,18));
        billinfo.setBounds(10,10,200,30);
        enterbillName.setBounds(10,50,100,30);
        usernameText.setBounds(120,50,150,30);
        info.setLineWrap(true);
        info.setEditable(false);
        info.setWrapStyleWord(true);
        sp.setBounds(10,200,400,350);
        sp.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        confirmButton.setBounds(10,130,100,30);
        Back.setBounds(120,130,100,30);
    }

    //parsing xml string
    private void doParse(String Permis) {
        info.setText("");
        String data = Permis;
        if (data.trim().length() == 0) {
            info.setText("ERROR");
            return;
        }
        Document xmldoc;
        try {
            DocumentBuilder docReader
                    = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            xmldoc = docReader.parse(new InputSource(new StringReader(data)));
        }
        catch (Exception e) {
            info.setText("ERROR:  The input is not well-formed XML.\n\n" + e);
            return;
        }
        Element root = xmldoc.getDocumentElement();
        listNodes(root,"",1);
    }

    private void listNodes(Element node, String indent, int level) {
        info.append( "\n"+level +"."  + node.getTagName() + ':');
        NamedNodeMap attributes = node.getAttributes();
        for (int i = 0; i < attributes.getLength(); i++) {
            Attr attribute = (Attr)attributes.item(i);
            info.append( "\n"+  attribute.getName()  + attribute.getValue() +"\n");
        }
        level++;
        String prefix = indent + level + ". ";
        NodeList children = node.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            int nodeType = child.getNodeType();
            if (nodeType == Node.ELEMENT_NODE)
                listNodes( (Element)child, indent, level);
            else if (nodeType == Node.TEXT_NODE) {
                String text = child.getTextContent();
                text = text.trim();
                if (text.length() > 0)
                    info.append(prefix + text + '\n');
            }
            else
                info.append(prefix + "(Some other type of node.)\n");
        }
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        String buttonString = e.getActionCommand();
        //checks if confirm button was pressed
        if(buttonString.equals("Confirm")) {
            info.setText("");
            //checks if field id empty
            userName = usernameText.getText();
            if (userName.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Field cannot be empty");
            } else {
                String information = "";
                String answer = "";
                Socket socket = null;
                String currentDirectory = System.getProperty("user.dir");
                BufferedReader input = null;
                PrintWriter output = null;

                //reading from client props file
                try (InputStream client_properties = new FileInputStream(currentDirectory + "/client.props")) {
                    Properties client_props = new Properties();
                    // load a properties file
                    client_props.load(client_properties);
                    // get the port property value
                    port = Integer.parseInt(client_props.getProperty("srv.port"));
                    hostName = client_props.getProperty("srv.hostname").toString();
                    //sending request to server
                    try {
                        System.out.println("Connecting to Server:" + hostName + " port:" + port);
                        SessionToken = log.getSessionToken();
                        socket = new Socket(hostName, port);
                        output = new PrintWriter(socket.getOutputStream(), true);
                        input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                        output.println(SessionToken);
                        output.println("billboard:get:" + userName);

                        //reading response from server
                        while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                            System.out.println("{Server} Response:" + answer);
                            if (answer.equals("ACK")) {
                                getinfo = true;
                            } else if (answer.contains("ERR")) {
                                getinfo = false;
                            }
                        }
                        //reading response from server
                        while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                            System.out.println("{Server} Response:" + answer);
                            if (answer.contains("ERR:")) {
                                getinfo = false;
                                JOptionPane.showMessageDialog(this, answer);
                            } else {
                                getinfo = true;
                                information = information + answer;
                            }
                        }
                        //shhows error
                        
                         if(getinfo){
                            doParse(information);
                        }

                    } catch (UnknownHostException Se) {
                        System.err.println("Unknown host: " + hostName);
                        System.exit(1);
                    } catch (ConnectException Se) {
                        System.err.println("Connection refused by host: " + hostName);
                        System.exit(1);
                    } catch (IOException Se) {
                        Se.printStackTrace();
                    } catch (NullPointerException Se) {
                        System.out.println("NullPointerException thrown!");
                    }
                    // finally, close the socket and decrement runningThreads
                    finally {
                        System.out.println("closing");
                        try {
                            input.close();
                            output.close();
                            socket.close();
                            System.out.flush();
                        } catch (IOException Se) {
                            System.out.println("Couldn't close socket");
                        }
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        }   //checks if logout button was pressed
        if (buttonString.equals("Logout")) {
            String currentDirectory = System.getProperty("user.dir");
            username = log.getUsername();
            SessionToken = log.getSessionToken();
            Socket s = log.getSocket();
            BufferedReader input = null;
            PrintWriter output = null;
            //getting info from props file
            try (InputStream client_properties = new FileInputStream(currentDirectory + "/client.props")) {
                Properties client_props = new Properties();
                // load a properties file
                client_props.load(client_properties);

                // get the port property value
                port = Integer.parseInt(client_props.getProperty("srv.port"));
                hostName = client_props.getProperty("srv.hostname").toString();

                //writing to server
                try {
                    s = new Socket(hostName, port);
                    output = new PrintWriter(s.getOutputStream(), true);
                    input = new BufferedReader(new InputStreamReader(s.getInputStream()));
                    output.println(SessionToken);
                    output.println("user:logout");
                    String answer = "";
                    //readinf response
                    while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                        System.out.println("{Server} Response:" + answer);
                        if (answer.equals("Sucess: Logged Out")) {
                            continues = true;
                        }
                        else if (answer.contains("ERR")){
                            continues = false;
                        }
                    }
                    //reading response
                    while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                        System.out.println("{Server} Response:" + answer);
                        if (answer.equals("Sucess: Logged Out")) {
                            continues = true;
                        }
                        else if (answer.contains("ERR")){
                            continues = false;
                        }
                    }
                    //shows eroor message
                    if (!continues) {
                        JOptionPane.showMessageDialog(this, answer);
                    } else {
                        //closes connections, disposes screen , goes back to login screen
                        JOptionPane.showMessageDialog(this, "Logout Succesfull");
                        s.close();
                        dispose();
                        Login login = new Login();
                        login.setBackground(Color.BLACK);
                        login.setForeground(Color.WHITE);
                        login.setBounds(10, 10, 370, 600);
                        login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        login.setVisible(true);
                        login.setTitle("Billboard Control Panel Login");
                    }
                } catch (UnknownHostException Se) {
                    System.err.println("Unknown host: " + hostName);
                    System.exit(1);
                } catch (ConnectException Se) {
                    System.err.println("Connection refused by host: " + hostName);
                    System.exit(1);
                } catch (IOException Se) {
                    Se.printStackTrace();
                } catch (NullPointerException Se) {
                    System.out.println("NullPointerException thrown!");
                }
                // finally, close the socket and decrement runningThreads
                finally {
                    System.out.println("closing");
                    try {
                        input.close();
                        output.close();
                        s.close();
                        System.out.flush();
                    } catch (IOException Se) {
                        System.out.println("Couldn't close socket");
                    }
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        //checks if back button was pressed
        if(buttonString.equals("Back")) {
            setVisible(false);
            JFrame listBillboard = new ListBillboard();
            listBillboard.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            listBillboard.setBounds(20, 20, 400, 600);
            listBillboard.setVisible(true);
            listBillboard.setTitle("List Billboards");
        }
    }
}
