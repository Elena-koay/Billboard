package ControlPanel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.ConnectException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Properties;

public class ListBillboard extends JFrame implements ActionListener {
    //container
    Container c = getContentPane();
    //buttons
    JButton access = new JButton("Access all Billboards");
    JButton delete = new JButton("Delete Billboards");
    JButton info = new JButton("Billboard Info");
    JButton back = new JButton("Back");
    JButton logout = new JButton("Logout");
    //label
    JLabel LB = new JLabel("List Billboards");
    //string
    String username, SessionToken;
    private static String hostName;
    //Boolean
    Boolean continues = false;
    //Int
    int port;
    //object
    Login log = new Login();

    //constructor
    ListBillboard() {
        setLayoutManager();
        setLocationAndSize();
        addComponents();
        addActionEvent();
    }
    //function to add components to container
    public void addComponents() {
        c.add(LB);
        c.add(access);
        c.add(info);
        c.add(delete);
        c.add(back);
        c.add(logout);
        c.setBackground(Color.WHITE);
        c.setForeground(Color.BLACK);
    }
    //function to add action listener to components
    public void addActionEvent() {
        logout.addActionListener(this);
        access.addActionListener(this);
        info.addActionListener(this);

        delete.addActionListener(this);
        back.addActionListener(this);
    }
    //function to setlayout
    public void setLayoutManager() {
        //Setting layout manager of Container to null
        c.setLayout(null);
    }
    //function to set bounds
    public void setLocationAndSize() {
        logout.setBounds(300,10,75,30);
        LB.setBounds(140,10,200,40);
        LB.setFont(new Font("Arial", Font.BOLD,18));
        access.setBounds(100, 100, 200, 40);
        delete.setBounds(100, 200, 200, 40);
        info.setBounds(100,300,200,40);
        back.setBounds(150, 400, 100, 40);

    }
    //function to check if user has permissions
    public void actionPerformed(ActionEvent e) {
        String buttonString = e.getActionCommand();
        //checks if Billboard Info Button was clicked
        if(buttonString.equals("Billboard Info")){
            //disposes current screen and opens new one
            dispose();
            BillboardInfo BI = new BillboardInfo();
            BI.setBounds(20, 20, 450, 600);
            BI.setVisible(true);
            BI.setTitle("Billboard Information");
            BI.setBackground(Color.BLACK);
            BI.setForeground(Color.WHITE);
            BI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        }
        //checks if Access all Billboards Button was clicked
        if (buttonString.equals("Access all Billboards")) {
            //disposes current screen and opens new one
            dispose();
            AccessBillboards AB = new AccessBillboards();
            AB.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            AB.setBounds(20, 20, 750, 650);
            AB.setVisible(true);
            AB.setBackground(Color.BLACK);
            AB.setForeground(Color.WHITE);
            AB.setTitle("Access Billboards");
        }
        //checks if Delete Billboards Button was clicked
        else if (buttonString.equals("Delete Billboards")) {
            //disposes current screen and opens new one
            dispose();
            JFrame deleteBillboard = new DeleteBillboard();
            deleteBillboard.setBounds(20, 20, 400, 600);
            deleteBillboard.setVisible(true);
            deleteBillboard.setTitle("Delete Billboards");
            deleteBillboard.setBackground(Color.BLACK);
            deleteBillboard.setForeground(Color.WHITE);
            deleteBillboard.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        }
        //checks if Logout Button was clicked
        if (buttonString.equals("Logout")) {
            //disposes current screen and opens new one
            String currentDirectory = System.getProperty("user.dir");
            username = log.getUsername();
            SessionToken = log.getSessionToken();
            Socket s = log.getSocket();
            BufferedReader input = null;
            PrintWriter output = null;

            try (InputStream client_properties = new FileInputStream(currentDirectory + "/client.props")) {
                Properties client_props = new Properties();
                // load a properties file
                client_props.load(client_properties);
                // get the port property value
                port = Integer.parseInt(client_props.getProperty("srv.port"));
                hostName = client_props.getProperty("srv.hostname").toString();
                try {
                    s = new Socket(hostName, port);
                    output = new PrintWriter(s.getOutputStream(), true);
                    input = new BufferedReader(new InputStreamReader(s.getInputStream()));

                    output.println(SessionToken);
                    output.println("user:logout");
                    String answer = "";
                    while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                        System.out.println("{Server} Response:" + answer);
                        if (answer.equals("Sucess: Logged Out")) {
                            continues = true;
                        }
                        else if (answer.contains("ERR")){
                            continues = false;
                        }
                    }
                    while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                        System.out.println("{Server} Response:" + answer);
                        if (answer.equals("Sucess: Logged Out")) {
                            continues = true;
                        }
                        else if (answer.contains("ERR")){
                            continues = false;
                        }
                    }
                    if (!continues) {
                        JOptionPane.showMessageDialog(this, answer);
                    } else {
                        JOptionPane.showMessageDialog(this, "Logout Succesfutl");
                        //closes connection
                        s.close();
                        //disposes current screen and goes back to Login
                        dispose();
                        Login login = new Login();
                        login.setBackground(Color.BLACK);
                        login.setForeground(Color.WHITE);
                        login.setBounds(10, 10, 370, 600);
                        login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        login.setVisible(true);
                        login.setTitle("Billboard Control Panel Login");

                    }
                } catch (UnknownHostException Se) {
                    System.err.println("Unknown host: " + hostName);
                    System.exit(1);
                } catch (ConnectException Se) {
                    System.err.println("Connection refused by host: " + hostName);
                    System.exit(1);
                } catch (IOException Se) {
                    Se.printStackTrace();
                } catch (NullPointerException Se) {
                    System.out.println("NullPointerException thrown!");
                }
                // finally, close the socket and decrement runningThreads
                finally {
                    System.out.println("closing");
                    try {
                        //Closing connections
                        input.close();
                        output.close();
                        s.close();
                        System.out.flush();
                    } catch (IOException Se) {
                        System.out.println("Couldn't close socket");
                    }
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        //Checks if Back Button was clicked
        else if (buttonString.equals("Back")) {
            //disposes current screen and opens new one
            dispose();
            JFrame menu = new Menu();
            menu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            menu.setBounds(20, 20, 400, 600);
            menu.setVisible(true);
            menu.setTitle("Control Panel");
        }
    }
}
