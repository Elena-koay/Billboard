package ControlPanel;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.Image;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.*;
import java.util.Base64;
import java.util.Properties;

public class ImageText extends JFrame implements ActionListener {
    //Integer
    int port;

    //Boolean
    Boolean continues = false;
    Boolean continuecreation=false;

    //Labels
    JLabel message_billboard = new JLabel("Image&Text Billboard");
    JLabel name = new JLabel("Enter Name Of Billboard");
    JLabel text = new JLabel("ENTER YOUR TEXT");
    JLabel pt = new JLabel("");
    JLabel pp = new JLabel("");

    //Text Field
    JTextField nameb = new JTextField("");
    JTextField urltext = new JTextField();
    JTextField TEXT = new JTextField();

    //Buttons
    JButton Browse = new JButton("Browse");
    JButton URL = new JButton("URL");
    JButton Confirm = new JButton("Confirm");
    JButton Back = new JButton("Back");
    JButton Save = new JButton("Save");
    JButton logout = new JButton("Logout");
    JButton Preview = new JButton("Preview");

    //Container
    Container c = getContentPane();

    //String
    String nameBillboard = null;
    String FinalText = null;
    private static String hostName;
    String username, SessionToken;
    String xml;
    String path = null, pathurl = null;
    String outpath;
    String encodedImage = "";
    String fontSelected = "PLAIN", ColorSelected = "Black", SizeSelected = "10";
    String sizes[] = {"10", "12", "14", "16", "18", "20", "24"};
    String color[] = {"BLACK", "RED", "BLUE", "YELLOW", "PINK", "WHITE"};
    String fontstyles[] = {"PLAIN", "BOLD", "ITALIC"};
    String HexColor;

    //Log
    Login log = new Login();

    //URL
    URL purl;

    //Combo Box
    JComboBox fontsize = new JComboBox();
    JComboBox fontStyleBox = new JComboBox();
    JComboBox colors = new JComboBox();
    //Font

    Font font = new Font("Arial", Font.BOLD, 12);

    //Constructor
    ImageText() {
        setLayoutManager();
        setLocationAndSize();
        ListFunction();
        addComponents();
        addActionEvent();
    }

    //Function to Add Items to Combo Box
    public void ListFunction() {
        //Font Style Combo Box
        fontStyleBox.setEditable(true);
        for (int i = 0; i < fontstyles.length; i++) {
            fontStyleBox.addItem(fontstyles[i]);
        }
        //Font Colors Combo Box
        colors.setEditable(true);
        for (int i = 0; i < color.length; i++) {
            colors.addItem(color[i]);
        }
        //Font Size Combo Box
        fontsize.setEditable(true);
        for (int i = 0; i < sizes.length; i++) {
            fontsize.addItem(sizes[i]);
        }
    }

    //Function to add components to the container
    public void addComponents() {
        c.add(message_billboard);
        c.add(name);
        c.add(nameb);
        c.add(Browse);
        c.add(urltext);
        c.add(URL);
        c.add(fontsize);
        c.add(fontStyleBox);
        c.add(colors);
        c.add(Confirm);
        c.add(Save);
        c.add(Preview);
        c.add(Back);
        c.add(text);
        c.add(TEXT);
        c.add(logout);
        c.add(pt);
        c.add(pp);
        c.setBackground(Color.WHITE);
        c.setForeground(Color.BLACK);
    }

    //Function to add action event to components
    public void addActionEvent() {
        Browse.addActionListener(this);
        URL.addActionListener(this);
        Save.addActionListener(this);
        Back.addActionListener(this);
        Preview.addActionListener(this);
        Confirm.addActionListener(this);
        logout.addActionListener(this);
    }

    //Function to set Layout
    public void setLayoutManager() {
        //Setting layout manager of Container to null
        c.setLayout(null);
    }

    //Function to set the location and sizes of different components
    public void setLocationAndSize() {
        logout.setBounds(400, 10, 75, 30);
        message_billboard.setBounds(10, 10, 250, 30);
        message_billboard.setFont(new Font("Arial", Font.BOLD, 18));
        name.setBounds(10, 50, 200, 30);
        nameb.setBounds(10, 100, 200, 30);
        Browse.setBounds(10, 150, 100, 30);
        urltext.setBounds(120, 150, 250, 30);
        URL.setBounds(380, 150, 100, 30);
        text.setBounds(10, 200, 150, 30);
        TEXT.setBounds(170, 200, 200, 30);
        fontStyleBox.setBounds(10, 250, 100, 30);
        fontsize.setBounds(120, 250, 100, 30);
        colors.setBounds(230, 250, 100, 30);
        Save.setBounds(10, 300, 100, 30);
        Preview.setBounds(120, 300, 100, 30);
        Back.setBounds(230,300,100,30);
        pt.setBounds(10,340,200,30);
        pp.setBounds(10,380,450,250);

    }

    //method to encode string to base64
    public String encodeImage(String imgPath) throws Exception {
        File file = new File(imgPath);
        FileInputStream imageStream = new FileInputStream(file);
        //byte[] data = imageStream.readAllBytes();
        long length = file.length();
        byte data[] = new byte[(int) length];
        imageStream.read(data);
        imageStream.close();
        String imageString = Base64.getEncoder().encodeToString(data);
        return imageString;
    }

    //Function for create XML
    public void createXML() {
        //checks if url was entered
        if (path == null) {
            if(fontSelected=="PLAIN") {
                xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                        "<billboard background=\"#0000FF\">" +
                        "<message colour=\"" + HexColor + "\">" + FinalText +
                        "</message>" +
                        "<picture url =\"" + pathurl + "\"/>" +
                        "</billboard>";
            }
            else if (fontSelected=="BOLD"){
                xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                        "<billboard background=\"#0000FF\">" +
                        "<message colour=\"" + HexColor + "\"><b>" + FinalText +
                        "</b></message>" +
                        "<picture url =\"" + pathurl + "\"/>" +
                        "</billboard>";

            }
            else if(fontSelected=="ITALIC"){
                xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                        "<billboard background=\"#0000FF\">" +
                        "<message colour=\"" + HexColor + "\"><i>" + FinalText +
                        "</i></message>" +
                        "<picture url =\"" + pathurl + "\"/>" +
                        "</billboard>";
            }
        }
        //checks if image was chosen through browse
        if (pathurl == null) {
            if (fontSelected == "PLAIN") {
                xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                        "<billboard background=\"#0000FF\">" +
                        "<message colour=\"" + HexColor + "\">" + FinalText +
                        "</message>" +
                        "<picture data =\"" + encodedImage + "\"/>" +
                        "</billboard>";
            } else if (fontSelected == "BOLD") {
                xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                        "<billboard background=\"#0000FF\">" +
                        "<message colour=\"" + HexColor + "\"><b>" + FinalText +
                        "</b></message>" +
                        "<picture data =\"" + encodedImage + "\"/>" +
                        "</billboard>";
            } else if (fontSelected == "ITALIC") {
                xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                        "<billboard background=\"#0000FF\">" +
                        "<message colour=\"" + HexColor + "\"><i>" + FinalText +
                        "</i></message>" +
                        "<picture data =\"" + encodedImage + "\"/>" +
                        "</billboard>";
            }
        }
    }

    //Function to set font
    public void setFont(String fontSelected) {
        //check if font style was plain
        if (fontSelected == "PLAIN") {
            font = new Font("Arial", Font.PLAIN, 12);
        }
        //check if font style was bold
        if (fontSelected == "BOLD") {
            font = new Font("Arial", Font.BOLD, 12);
        }
        //check if font style was italic
        if (fontSelected == "ITALIC") {
            font = new Font("Arial", Font.ITALIC, 12);
        }
    }

    //Function to set Size
    public void setSize(String SizeSelected) {
        if (SizeSelected == "12") {
            if (fontSelected == "PLAIN") {
                font = new Font("Arial", Font.PLAIN, 12);
            } else if (fontSelected == "BOLD") {
                font = new Font("Arial", Font.BOLD, 12);
            } else if (fontSelected == "ITALIC") {
                font = new Font("Arial", Font.ITALIC, 12);
            }
        } else if (SizeSelected == "14") {
            if (fontSelected == "PLAIN") {
                font = new Font("Arial", Font.PLAIN, 14);
            } else if (fontSelected == "BOLD") {
                font = new Font("Arial", Font.BOLD, 14);
            } else if (fontSelected == "ITALIC") {
                font = new Font("Arial", Font.ITALIC, 14);
            }
        } else if (SizeSelected == "16") {
            if (fontSelected == "PLAIN") {
                font = new Font("Arial", Font.PLAIN, 16);
            } else if (fontSelected == "BOLD") {
                font = new Font("Arial", Font.BOLD, 16);
            } else if (fontSelected == "ITALIC") {
                font = new Font("Arial", Font.ITALIC, 16);
            }
        } else if (SizeSelected == "18") {
            if (fontSelected == "PLAIN") {
                font = new Font("Arial", Font.PLAIN, 18);
            } else if (fontSelected == "BOLD") {
                font = new Font("Arial", Font.BOLD, 18);
            } else if (fontSelected == "ITALIC") {
                font = new Font("Arial", Font.ITALIC, 18);
            }
        } else if (SizeSelected == "20") {
            if (fontSelected == "PLAIN") {
                font = new Font("Arial", Font.PLAIN, 20);
            } else if (fontSelected == "BOLD") {
                font = new Font("Arial", Font.BOLD, 20);
            } else if (fontSelected == "ITALIC") {
                font = new Font("Arial", Font.ITALIC, 20);
            }
        } else if (SizeSelected == "24") {
            if (fontSelected == "PLAIN") {
                font = new Font("Arial", Font.PLAIN, 24);
            } else if (fontSelected == "BOLD") {
                font = new Font("Arial", Font.BOLD, 24);
            } else if (fontSelected == "ITALIC") {
                font = new Font("Arial", Font.ITALIC, 24);
            }
        }
    }

    public ImageIcon ResizeImage(String ImagePath) {
        ImageIcon MyImage = new ImageIcon(ImagePath);
        java.awt.Image img = MyImage.getImage();
        java.awt.Image newImg = img.getScaledInstance(pp.getWidth(), pp.getHeight(), java.awt.Image.SCALE_SMOOTH);
        ImageIcon image = new ImageIcon(newImg);
        return image;
    }


    //Function sets color
    public void setColor(String ColorSelected) {
        if (ColorSelected == "RED") {
            HexColor = "#FF0000";
        } else if (ColorSelected == "BLUE") {
            HexColor = "#0000FF";
        } else if (ColorSelected == "BLACK") {
            HexColor = "#000000";
        } else if (ColorSelected == "YELLOW") {
            HexColor = "#FFFF00";
        } else if (ColorSelected == "PINK") {
            HexColor = "#FFC0CB";
        } else if (ColorSelected == "WHITE") {
            HexColor = "#FFFFFF";
        } else {
            HexColor = "#000000";
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String buttonString = e.getActionCommand();
        //checks if browse button was pressed
        if (buttonString.equals("Browse")) {
            JFileChooser file = new JFileChooser();
            file.setCurrentDirectory(new File(System.getProperty("user.home")));
            //filter the files
            FileNameExtensionFilter filter = new FileNameExtensionFilter("*.Images", "jpg", "png", "xml");
            file.addChoosableFileFilter(filter);
            int result = file.showSaveDialog(null);
            //if the user click on save in Jfilechooser
            if (result == JFileChooser.APPROVE_OPTION) {
                File selectedFile = file.getSelectedFile();
                path = selectedFile.getAbsolutePath();
                JOptionPane.showMessageDialog(this, "Image has been selected");
                pathurl = null;
                try {
                    encodedImage = encodeImage(path);
                } catch (Exception exception) {
                    exception.printStackTrace();
                }

            }
        }

        //checks if URL button was pressed
        if (buttonString == "URL") {
            pathurl = urltext.getText();
            //displays error if text field empty
            if (pathurl.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Enter URL");
            } else {
                try {
                    purl = new URL(pathurl);
                } catch (MalformedURLException malformedURLException) {
                    JOptionPane.showMessageDialog(this, "URL broken");
                }
                path = null;
            }
        }
        if (buttonString.equals("Preview")) {
            FinalText = TEXT.getText();
            fontSelected = String.valueOf(fontStyleBox.getSelectedItem());
            SizeSelected = String.valueOf(fontsize.getSelectedItem());
            ColorSelected = String.valueOf(colors.getSelectedItem());
            pt.setText(FinalText);
            setFont(fontSelected);
            setColor(ColorSelected);
            setSize(SizeSelected);

            if (pathurl == null) {
                pp.setIcon(ResizeImage(path));
            } else if (path == null) {
                try {
                    purl = new URL(pathurl);
                } catch (MalformedURLException malformedURLException) {
                    JOptionPane.showMessageDialog(this, "URL broken");
                }
                java.awt.Image image = null;
                try {
                    image = ImageIO.read(purl);
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
                pp.setIcon(new ImageIcon(image));
            }
        }

        //Checks if Save button was pressed
        if (buttonString.equals("Save")) {
            FinalText = TEXT.getText();
            nameBillboard = nameb.getText();
            if ((pathurl == null && path == null)|| FinalText.isEmpty()||nameBillboard.isEmpty()){
                JOptionPane.showMessageDialog(this, "Fields cannot be empty");
            }
            else {
                fontSelected = String.valueOf(fontStyleBox.getSelectedItem());
                ColorSelected = String.valueOf(colors.getSelectedItem());
                SizeSelected = String.valueOf(fontsize.getSelectedItem());
                setFont(fontSelected);
                setSize(SizeSelected);
                setColor(ColorSelected);
                //calls funtion to create xml string
                createXML();
                //Getting Socket through login class object
                Socket s = log.getSocket();
                //sending name,xml to server
                BufferedReader input = null;
                PrintWriter output = null;
                String currentDirectory = System.getProperty("user.dir");
                try (InputStream client_properties = new FileInputStream(currentDirectory + "/client.props")) {
                    Properties client_props = new Properties();
                    // load a properties file
                    client_props.load(client_properties);

                    // get the port property value
                    port = Integer.parseInt(client_props.getProperty("srv.port"));
                    hostName = client_props.getProperty("srv.hostname").toString();

                    //writing to server
                    try {
                        SessionToken = log.getSessionToken();
                        s = new Socket(hostName, port);
                        System.out.println("Connecting to Server:" + hostName + " port:" + port);
                        output = new PrintWriter(s.getOutputStream(), true);
                        input = new BufferedReader(new InputStreamReader(s.getInputStream()));
                        output.println(SessionToken);
                        output.println("billboard:update:" + nameBillboard + ":" + xml);
                        String answer = "";
                        //reading response
                        while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                            System.out.println("{Server} Response:" + answer);
                            if (answer.equals("ACK")) {
                                continuecreation = true;
                            } else if (answer.contains("ERR")) {
                                continuecreation = false;
                            }
                        }
                        //reading response
                        while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                            System.out.println("{Server} Response:" + answer);
                            if (answer.equals("ACK:BILLBOARD_CREATED") || answer.equals("ACK:BILLBOARD_EDITED")) {
                                if (answer.equals("ACK:BILLBOARD_CREATED")) {
                                    JOptionPane.showMessageDialog(this, "Billboard created");
                                } else if (answer.equals("ACK:BILLBOARD_EDITED")) {
                                    JOptionPane.showMessageDialog(this, "Billboard edited");
                                }
                                continuecreation = true;
                            } else if (answer.contains("ERR")) {
                                continuecreation = false;
                                JOptionPane.showMessageDialog(this, answer);
                            }
                        }
                    } catch (UnknownHostException Se) {
                        System.err.println("Unknown host: " + hostName);
                        System.exit(1);
                    } catch (ConnectException Se) {
                        System.err.println("Connection refused by host: " + hostName);
                        System.exit(1);
                    } catch (IOException Se) {
                        Se.printStackTrace();
                    } catch (NullPointerException Se) {
                        System.out.println("NullPointerException thrown!");
                    }
                    // finally, close the socket and decrement runningThreads
                    finally {
                        System.out.println("closing");
                        try {
                            input.close();
                            output.close();
                            s.close();
                            System.out.flush();
                        } catch (IOException Se) {
                            System.out.println("Couldn't close socket");
                        }
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        }

        //button checks if logout was pressed
        if (buttonString.equals("Logout")) {
            String currentDirectory = System.getProperty("user.dir");
            username = log.getUsername();
            SessionToken = log.getSessionToken();
            Socket s = log.getSocket();
            BufferedReader input = null;
            PrintWriter output = null;
            //reading from client props file
            try (InputStream client_properties = new FileInputStream(currentDirectory + "/client.props")) {
                Properties client_props = new Properties();
                // load a properties file
                client_props.load(client_properties);

                // get the port property value
                port = Integer.parseInt(client_props.getProperty("srv.port"));
                hostName = client_props.getProperty("srv.hostname").toString();

                try {
                    s = new Socket(hostName, port);
                    output = new PrintWriter(s.getOutputStream(), true);
                    input = new BufferedReader(new InputStreamReader(s.getInputStream()));
                    output.println(SessionToken);
                    output.println("user:logout");
                    String answer = "";
                    //reading from server
                    while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                        System.out.println("{Server} Response:" + answer);
                        if (answer.equals("Sucess: Logged Out")) {
                            continues = true;
                        }
                        else if (answer.contains("ERR")){
                            continues = false;
                        }
                    }
                    //reading from server
                    while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                        System.out.println("{Server} Response:" + answer);
                        if (answer.equals("Sucess: Logged Out")) {
                            continues = true;
                        }
                        else if (answer.contains("ERR")){
                            continues = false;
                        }
                    }
                    //shows error
                    if (!continues) {
                        JOptionPane.showMessageDialog(this, answer);
                    } else {
                        //shows acknowledgement, closes connection, disposes current window, shows login window
                        JOptionPane.showMessageDialog(this, "Logout Succesfutl");
                        s.close();
                        dispose();
                        Login login = new Login();
                        login.setBackground(Color.BLACK);
                        login.setForeground(Color.WHITE);
                        login.setBounds(10, 10, 370, 600);
                        login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        login.setVisible(true);
                        login.setTitle("Billboard Control Panel Login");
                    }
                } catch (UnknownHostException Se) {
                    System.err.println("Unknown host: " + hostName);
                    System.exit(1);
                } catch (ConnectException Se) {
                    System.err.println("Connection refused by host: " + hostName);
                    System.exit(1);
                } catch (IOException Se) {
                    Se.printStackTrace();
                } catch (NullPointerException Se) {
                    System.out.println("NullPointerException thrown!");
                }
                // finally, close the socket and decrement runningThreads
                finally {
                    System.out.println("closing");
                    try {
                        input.close();
                        output.close();
                        s.close();
                        System.out.flush();
                    } catch (IOException Se) {
                        System.out.println("Couldn't close socket");
                    }
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        //Function to return back to previous screen
        if (buttonString.equals("Back")) {
            setVisible(false);
            JFrame CB = new CreateBillBoard();
            CB.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            CB.setBounds(20, 20, 400, 600);
            CB.setVisible(true);
            CB.setTitle("Create Billboard");
        }
    }
}
