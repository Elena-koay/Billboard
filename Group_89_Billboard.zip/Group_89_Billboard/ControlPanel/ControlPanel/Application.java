package ControlPanel;

import javax.swing.*;
import java.awt.*;

public class Application {
    public static void main(String[] args){
        // creating an object of Login class
        Login login= new Login();
        //login window settings
        login.setBackground(Color.BLACK);
        login.setForeground(Color.WHITE);
        login.setBounds(10,10,370,600);
        login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        login.setVisible(true);
        login.setTitle("Billboard Control Panel Login");
    }
}