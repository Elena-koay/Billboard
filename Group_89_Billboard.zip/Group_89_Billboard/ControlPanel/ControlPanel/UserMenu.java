package ControlPanel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.ConnectException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Properties;

public class UserMenu extends JFrame implements ActionListener {
    //Integer
    int port;

    //String
    String username, SessionToken;
    private static String hostName;

    //Boolean
    Boolean continues = false;

    //Container
    Container c = getContentPane();
    //Buttons
    JButton List = new JButton("List of Users");
    JButton Create = new JButton("Create Users");
    JButton Edit = new JButton("Edit Permission");
    JButton Delete = new JButton("Delete Users");
    JButton ChangePassword = new JButton("Change Password");
    JButton Back = new JButton("Back");
    JButton logout = new JButton("Logout");
    JButton perm = new JButton("Get Permission");

    //Label
    JLabel edituser = new JLabel("User Menu");

    //Object
    Login log = new Login();

    //Constructor
    UserMenu() {
        setLayoutManager();
        setLocationAndSize();
        addComponents();
        addActionEvent();
    }

    //fucntion to add components
    public void addComponents() {
        c.add(logout);
        c.add(List);
        c.add(Create);
        c.add(Edit);
        c.add(Delete);
        c.add(ChangePassword);
        c.add(perm);
        c.add(Back);
        c.add(edituser);
        c.add(logout);
        c.setBackground(Color.WHITE);
        c.setForeground(Color.BLACK);
    }

    //function to add action event
    public void addActionEvent() {
        logout.addActionListener(this);
        List.addActionListener(this);
        Create.addActionListener(this);
        Edit.addActionListener(this);
        Delete.addActionListener(this);
        ChangePassword.addActionListener(this);
        perm.addActionListener(this);
        Back.addActionListener(this);
    }

    //function to set layout
    public void setLayoutManager() {
        //Setting layout manager of Container to null
        c.setLayout(null);
    }

    //fucntion to set bounds
    public void setLocationAndSize() {
        logout.setBounds(300,10,75,30);
        edituser.setBounds(150,10,180,40);
        List.setBounds(100, 60, 180, 40);
        Create.setBounds(100, 120, 180, 40);
        Edit.setBounds(100, 180, 180, 40);
        Delete.setBounds(100,240 , 180, 40);
        ChangePassword.setBounds(100,300,180,40);
        perm.setBounds(100,360,180,40);
        Back.setBounds(150,420,100,40);
        edituser.setFont(new Font("Arial", Font.BOLD,18));
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        String buttonString = e.getActionCommand();

        //checks if Get permission button was pressed
        if(buttonString.equals("Get Permission")){
            dispose();
            UserPermissions UP = new UserPermissions();
            UP.setBounds(20, 20, 400, 600);
            UP.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            UP.setVisible(true);
            UP.setTitle("User Permission");
        }

        //checks if list users is pressed
        if (buttonString.equals("List of Users")) {
            dispose();
            ListUsers List = new ListUsers();
            List.setBounds(20, 20, 400, 600);
            List.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            List.setVisible(true);
            List.setTitle("List of Users");
        }

        //chekcs if create users button was pressed
        if (buttonString.equals("Create Users")) {
            dispose();
            CreateUsers create = new CreateUsers();
            create.setBounds(20, 20, 400, 600);
            create.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            create.setVisible(true);
            create.setTitle("Create Users");
        }

        //checks if edit users is selected
        if(buttonString.equals("Edit Permission")){
            dispose();
            EditPermissions edit = new EditPermissions();
            edit.setBounds(20, 20, 400, 600);
            edit.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            edit.setVisible(true);
            edit.setTitle("Edit Permission");
        }

        //checks if delete users is selected
        if (buttonString.equals("Delete Users")) {
            dispose();
            DeleteUser delete= new DeleteUser();
            delete.setBounds(20,20,400,600);
            delete.setVisible(true);
            delete.setTitle("Delete Users");
            delete.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        }

        //checks if change password is selected
        if(buttonString.equals("Change Password")){
            dispose();
            ChangePassword changePassword= new ChangePassword();
            changePassword.setBounds(20,20,400,600);
            changePassword.setVisible(true);
            changePassword.setTitle("Change Password");
            changePassword.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        }

        //checks if logout is selected
        if (buttonString.equals("Logout")) {

            String currentDirectory = System.getProperty("user.dir");
            username = log.getUsername();
            SessionToken = log.getSessionToken();
            Socket s = log.getSocket();
            BufferedReader input = null;
            PrintWriter output = null;
            //reading client props file
            try (InputStream client_properties = new FileInputStream(currentDirectory + "/client.props")) {
                Properties client_props = new Properties();
                // load a properties file
                client_props.load(client_properties);

                // get the port property value
                port = Integer.parseInt(client_props.getProperty("srv.port"));
                hostName = client_props.getProperty("srv.hostname").toString();

                //sending request to server
                try {
                    s = new Socket(hostName, port);
                    output = new PrintWriter(s.getOutputStream(), true);
                    input = new BufferedReader(new InputStreamReader(s.getInputStream()));
                    output.println(SessionToken);
                    output.println("user:logout");
                    String answer = "";

                    //reading response
                    while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                        System.out.println("{Server} Response:" + answer);
                        if (answer.equals("Sucess: Logged Out")) {
                            continues = true;
                        }
                        else if (answer.contains("ERR")){
                            continues = false;
                        }
                    }

                    //reading response
                    while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                        System.out.println("{Server} Response:" + answer);
                        if (answer.equals("Sucess: Logged Out")) {
                            continues = true;
                        }
                        else if (answer.contains("ERR")){
                            continues = false;
                        }
                    }

                    //shows error
                    if (!continues) {
                        JOptionPane.showMessageDialog(this, answer);
                    } else {
                        //shows acknowledgement, closes connection, disposes current window, shows login window
                        JOptionPane.showMessageDialog(this, "Logout Succesfutl");
                        s.close();
                        dispose();
                        Login login = new Login();
                        login.setBackground(Color.BLACK);
                        login.setForeground(Color.WHITE);
                        login.setBounds(10, 10, 370, 600);
                        login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        login.setVisible(true);
                        login.setTitle("Billboard Control Panel Login");
                    }
                } catch (UnknownHostException Se) {
                    System.err.println("Unknown host: " + hostName);
                    System.exit(1);
                } catch (ConnectException Se) {
                    System.err.println("Connection refused by host: " + hostName);
                    System.exit(1);
                } catch (IOException Se) {
                    Se.printStackTrace();
                } catch (NullPointerException Se) {
                    System.out.println("NullPointerException thrown!");
                }
                // finally, close the socket and decrement runningThreads
                finally {
                    System.out.println("closing");
                    try {
                        input.close();
                        output.close();
                        s.close();
                        System.out.flush();
                    } catch (IOException Se) {
                        System.out.println("Couldn't close socket");
                    }
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }

        //check if back button was pressed
        if (buttonString.equals("Back")) {
            dispose();
            JFrame menu = new Menu();
            menu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            menu.setBounds(20, 20, 400, 600);
            menu.setVisible(true);
            menu.setTitle("Control Panel");
        }
    }
}