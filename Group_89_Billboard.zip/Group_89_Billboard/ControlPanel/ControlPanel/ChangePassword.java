package ControlPanel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.ConnectException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Properties;

public class ChangePassword extends JFrame implements ActionListener {
    //Integer
    int port;

    //Boolean
    Boolean continues = false;
    Boolean changepassword= false;

    //container
    Container c = getContentPane();

    //labels
    JLabel changePass = new JLabel("Change Password");
    JLabel enterUserName = new JLabel("Enter Username");
    JLabel enterPassword = new JLabel("Enter Password");

    //Text field
    JTextField usernameText = new JTextField("");
    JPasswordField password = new JPasswordField("");

    //String
    String userName = null;
    String username, SessionToken;
    String passWord=null;
    private static String hostName;

    //Buttons
    JButton confirmButton = new JButton("Confirm");
    JButton Back = new JButton("Back");
    JButton logout = new JButton("Logout");

    //Object
    Login log = new Login();

    //Constructor
    ChangePassword(){
        setLayoutManager();
        setBounds();
        add();
        addActionEvent();
    }

    //Function to add action event to component
    public void addActionEvent() {
        logout.addActionListener(this);
        confirmButton.addActionListener(this);
        Back.addActionListener(this);
    }

    //Function to setLayout to null
    public void setLayoutManager() {
        c.setLayout(null);
    }

    //Function to add components to the container
    public void add(){
        c.add(logout);
        c.add(changePass);
        c.add(enterUserName);
        c.add(enterPassword);
        c.add(usernameText);
        c.add(password);
        c.add(confirmButton);
        c.add(Back);
        c.setBackground(Color.WHITE);
        c.setForeground(Color.BLACK);
    }

    //Function to setBounds to components
    public void setBounds(){
        logout.setBounds(300,10,75,30);
        changePass.setFont(new Font("Arial ",Font.BOLD,18));
        changePass.setBounds(10,10,200,30);
        enterUserName.setBounds(10,50,100,30);
        usernameText.setBounds(120,50,150,30);
        enterPassword.setBounds(10,90,100,30);
        password.setBounds(120,90,150,30);
        confirmButton.setBounds(10,130,100,30);
        Back.setBounds(10,170,100,30);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String buttonString = e.getActionCommand();
        //checks if confirm button was pressed
        if(buttonString.equals("Confirm")) {
            userName = usernameText.getText();
            passWord = String.valueOf(password.getPassword());
            //Checking if Fields are empty
            if (userName.isEmpty() || passWord.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Fields cannot be empty");
            }
            else {
                //hashing password
                String hash_pass = "";
                try {
                    hash_pass= PasswordHash.getHashPWD(passWord);
                } catch (NoSuchAlgorithmException ex) {
                    ex.printStackTrace();
                }
                //starting a connection with the server
                //send a request
                //read the response
                //sending username and hash to the server
                String answer = "";
                Socket socket = null;
                String currentDirectory = System.getProperty("user.dir");
                BufferedReader input = null;
                PrintWriter output = null;
                //reading from properties file
                try (InputStream client_properties = new FileInputStream(currentDirectory+"/client.props")) {
                    Properties client_props = new Properties();
                    // load a properties file
                    client_props.load(client_properties);

                    // get the port property value
                    port = Integer.parseInt(client_props.getProperty("srv.port"));
                    hostName = client_props.getProperty("srv.hostname").toString();

                    //connecting to server
                    try {
                        System.out.println("Connecting to Server:"+hostName+" port:"+port);
                        SessionToken = log.getSessionToken();
                        socket = new Socket(hostName, port);
                        output = new PrintWriter(socket.getOutputStream(), true);
                        input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                        output.println(SessionToken);
                        output.println("user:set password:"+userName+":"+hash_pass);
                        while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                            System.out.println("{Server} Response:" + answer);
                            if (answer.equals("ACK")) {
                                changepassword = true;
                            } else if (answer.contains("ERR")) {
                                changepassword = false;
                            }
                        }
                        //reading response
                        while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                            System.out.println("{Server} Response:" + answer);
                            if (answer.equals("Success: Password Updated!")) {
                                changepassword = true;

                            } else if (answer.contains("ERR")) {
                                changepassword = false;
                                //displays error
                                JOptionPane.showMessageDialog(this, answer);
                            }
                        }
                        //shows acknowledgement
                        if(changepassword){
                            JOptionPane.showMessageDialog(this,"Password Changed");
                        }
                    } catch (UnknownHostException Se) {
                        System.err.println("Unknown host: " + hostName);
                        System.exit(1);
                    } catch (ConnectException Se) {
                        System.err.println("Connection refused by host: " + hostName);
                        System.exit(1);
                    } catch (IOException Se) {
                        Se.printStackTrace();
                    } catch (NullPointerException Se) {
                        System.out.println("NullPointerException thrown!");
                    }
                    // finally, close the socket and decrement runningThreads
                    finally {
                        System.out.println("closing");
                        try {
                            input.close();
                            output.close();
                            socket.close();
                            System.out.flush();
                        } catch (IOException Se) {
                            System.out.println("Couldn't close socket");
                        }
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        }
        //checks if logout was pressed
        if (buttonString.equals("Logout")) {
            String currentDirectory = System.getProperty("user.dir");
            username = log.getUsername();
            SessionToken = log.getSessionToken();
            Socket s = log.getSocket();
            BufferedReader input = null;
            PrintWriter output = null;

            //reading from client.props
            try (InputStream client_properties = new FileInputStream(currentDirectory + "/client.props")) {
                Properties client_props = new Properties();
                // load a properties file
                client_props.load(client_properties);
                // get the port property value
                port = Integer.parseInt(client_props.getProperty("srv.port"));
                hostName = client_props.getProperty("srv.hostname").toString();

                //connecting to server
                try {
                    s = new Socket(hostName, port);
                    output = new PrintWriter(s.getOutputStream(), true);
                    input = new BufferedReader(new InputStreamReader(s.getInputStream()));
                    output.println(SessionToken);
                    output.println("user:logout");
                    String answer = "";

                    //reading response
                    while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                        System.out.println("{Server} Response:" + answer);
                        if (answer.equals("Sucess: Logged Out")) {
                            continues = true;
                        }
                        else if (answer.contains("ERR")){
                            continues = false;
                        }
                    }
                    //reading response
                    while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                        System.out.println("{Server} Response:" + answer);
                        if (answer.equals("Sucess: Logged Out")) {
                            continues = true;
                        }
                        else if (answer.contains("ERR")){
                            continues = false;
                        }
                    }
                    //shows error
                    if (!continues) {
                        JOptionPane.showMessageDialog(this, answer);
                    } else {
                        //shows acknowledgment, closes connection,disposes current screen, open login screen
                        JOptionPane.showMessageDialog(this, "Logout Succesfutl");
                        s.close();
                        dispose();
                        Login login = new Login();
                        login.setBackground(Color.BLACK);
                        login.setForeground(Color.WHITE);
                        login.setBounds(10, 10, 370, 600);
                        login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        login.setVisible(true);
                        login.setTitle("Billboard Control Panel Login");
                    }
                } catch (UnknownHostException Se) {
                    System.err.println("Unknown host: " + hostName);
                    System.exit(1);
                } catch (ConnectException Se) {
                    System.err.println("Connection refused by host: " + hostName);
                    System.exit(1);
                } catch (IOException Se) {
                    Se.printStackTrace();
                } catch (NullPointerException Se) {
                    System.out.println("NullPointerException thrown!");
                }
                // finally, close the socket and decrement runningThreads
                finally {
                    System.out.println("closing");
                    try {
                        input.close();
                        output.close();
                        s.close();
                        System.out.flush();
                    } catch (IOException Se) {
                        System.out.println("Couldn't close socket");
                    }
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        //checks if back button was pressed
        if(buttonString.equals("Back")) {
            setVisible(false);
            JFrame editUser = new UserMenu();
            editUser.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            editUser.setBounds(20, 20, 400, 600);
            editUser.setVisible(true);
            editUser.setTitle("User Menu");
        }
    }
}