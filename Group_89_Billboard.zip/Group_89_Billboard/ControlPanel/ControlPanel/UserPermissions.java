package ControlPanel;

import javax.sound.midi.SysexMessage;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.ConnectException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UserPermissions extends JFrame implements ActionListener {
    //Integer
    int port;

    //Boolean
    Boolean continues = false;
    Boolean continuecreation=false;

    //container
    Container c = getContentPane();

    //labels
    JLabel editUser = new JLabel("Get User Permission");
    JLabel enterUserName = new JLabel("Enter Username");
    JLabel Permission = new JLabel("");
    JLabel Permission1 = new JLabel("");

    //Table
    Object[][] row={};
    Object[] column={"Billboard","Create Billboard","Edit Billboa","Start time","Duration","Recurring Type","Recurring Count"};
    DefaultTableModel model = new DefaultTableModel(row,column){
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    //Textfield
    JTextField usernameText = new JTextField("");

    //String
    String userName = null;
    String username, SessionToken;
    private static String hostName;

    //Buttons
    JButton confirmButton = new JButton("Confirm");
    JButton Back = new JButton("Back");
    JButton logout = new JButton("Logout");

    //Object
    Login log = new Login();

    //Constructor
    UserPermissions(){
        setLayoutManager();
        setBounds();
        add();
        addActionEvent();
    }

    //Function to set Action Event to components
    public void addActionEvent() {
        confirmButton.addActionListener(this);
        Back.addActionListener(this);
        logout.addActionListener(this);
    }

    //Function to set layout to null
    public void setLayoutManager() {
        c.setLayout(null);
    }

    //Function to add components to container
    public void add(){
        c.add(logout);
        c.add(editUser);
        c.add(enterUserName);
        c.add(usernameText);
        c.add(Permission);
        c.add(Permission1);
        c.add(confirmButton);
        c.add(Back);
        c.setBackground(Color.WHITE);
        c.setForeground(Color.BLACK);
    }

    //Function to set bounds to components
    public void setBounds(){
        logout.setBounds(300,10,75,30);
        editUser.setFont(new Font("Arial ",Font.BOLD,18));
        editUser.setBounds(10,10,200,30);
        enterUserName.setBounds(10,50,100,30);
        usernameText.setBounds(120,50,150,30);
        Permission.setBounds(10,200,800,150);
        confirmButton.setBounds(10,130,100,30);
        Back.setBounds(120,130,100,30);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String buttonString = e.getActionCommand();

        //checks if confirm button was pressed
        if(buttonString.equals("Confirm")) {
            Permission.setText("");
            userName = usernameText.getText();
            if (userName.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Field cannot be empty");
            }
            else {
                String permiss = "";
                String answer = "";
                Socket socket = null;
                String currentDirectory = System.getProperty("user.dir");
                BufferedReader input = null;
                PrintWriter output = null;

                //reading from client props file
                try (InputStream client_properties = new FileInputStream(currentDirectory+"/client.props")) {
                    Properties client_props = new Properties();
                    // load a properties file
                    client_props.load(client_properties);

                    // get the port property value
                    port = Integer.parseInt(client_props.getProperty("srv.port"));
                    hostName = client_props.getProperty("srv.hostname").toString();

                    //sending request to server
                    try {
                        System.out.println("Connecting to Server:"+hostName+" port:"+port);
                        SessionToken = log.getSessionToken();
                        socket = new Socket(hostName, port);
                        output = new PrintWriter(socket.getOutputStream(), true);
                        input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                        output.println(SessionToken);
                        output.println("user:get permission:"+userName);

                        //getting response from server
                        while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                            System.out.println("{Server} Response:" + answer);
                            if (answer.equals("ACK")) {
                                continuecreation = true;
                            } else if (answer.contains("ERR")) {
                                continuecreation = false;
                            }
                        }

                        //getting response from server
                        while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                            if (answer.contains("ERR")) {
                                continuecreation = false;
                                //shows error
                                JOptionPane.showMessageDialog(this, answer);
                            }
                            else{
                                continuecreation = true;
                                permiss = permiss + answer;
                            }
                        }
                        //displays permission
                        if(continuecreation){
                            Permission.setText(permiss);
                        }
                    } catch (UnknownHostException Se) {
                        System.err.println("Unknown host: " + hostName);
                        System.exit(1);
                    } catch (ConnectException Se) {
                        System.err.println("Connection refused by host: " + hostName);
                        System.exit(1);
                    } catch (IOException Se) {
                        Se.printStackTrace();
                    } catch (NullPointerException Se) {
                        System.out.println("NullPointerException thrown!");
                    }
                    // finally, close the socket and decrement runningThreads
                    finally {
                        System.out.println("closing");
                        try {
                            input.close();
                            output.close();
                            socket.close();
                            System.out.flush();
                        } catch (IOException Se) {
                            System.out.println("Couldn't close socket");
                        }
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }

            if (buttonString.equals("Logout")) {
                String currentDirectory = System.getProperty("user.dir");
                username = log.getUsername();
                SessionToken = log.getSessionToken();
                Socket s = log.getSocket();
                BufferedReader input = null;
                PrintWriter output = null;

                //reading from client props file
                try (InputStream client_properties = new FileInputStream(currentDirectory + "/client.props")) {
                    Properties client_props = new Properties();
                    // load a properties file
                    client_props.load(client_properties);

                    // get the port property value
                    port = Integer.parseInt(client_props.getProperty("srv.port"));
                    hostName = client_props.getProperty("srv.hostname").toString();

                    try {
                        s = new Socket(hostName, port);
                        output = new PrintWriter(s.getOutputStream(), true);
                        input = new BufferedReader(new InputStreamReader(s.getInputStream()));
                        output.println(SessionToken);
                        output.println("user:logout");
                        String answer = "";
                        //getting response from  server
                        while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                            System.out.println("{Server} Response:" + answer);
                            if (answer.equals("Sucess: Logged Out")) {
                                continues = true;
                            }
                            else if (answer.contains("ERR")){
                                continues = false;
                            }
                        }
                        //getting response from  server
                        while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                            System.out.println("{Server} Response:" + answer);
                            if (answer.equals("Sucess: Logged Out")) {
                                continues = true;
                            }
                            else if (answer.contains("ERR")){
                                continues = false;
                            }
                        }
                        //shows error
                        if (!continues) {
                            JOptionPane.showMessageDialog(this, answer);
                        } else {
                            //shows acknowledgement, closes connection, disposes current window, shows login window
                            JOptionPane.showMessageDialog(this, "Logout Succesfull");
                            s.close();
                            dispose();
                            Login login = new Login();
                            login.setBackground(Color.BLACK);
                            login.setForeground(Color.WHITE);
                            login.setBounds(10, 10, 370, 600);
                            login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                            login.setVisible(true);
                            login.setTitle("Billboard Control Panel Login");

                        }
                    } catch (UnknownHostException Se) {
                        System.err.println("Unknown host: " + hostName);
                        System.exit(1);
                    } catch (ConnectException Se) {
                        System.err.println("Connection refused by host: " + hostName);
                        System.exit(1);
                    } catch (IOException Se) {
                        Se.printStackTrace();
                    } catch (NullPointerException Se) {
                        System.out.println("NullPointerException thrown!");
                    }
                    // finally, close the socket and decrement runningThreads
                    finally {
                        System.out.println("closing");
                        try {
                            input.close();
                            output.close();
                            s.close();
                            System.out.flush();
                        } catch (IOException Se) {
                            System.out.println("Couldn't close socket");
                        }
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        }
        //checks if back button was pressed
        if(buttonString.equals("Back")) {
            setVisible(false);
            JFrame UM = new UserMenu();
            UM.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            UM.setBounds(20, 20, 400, 600);
            UM.setVisible(true);
            UM.setTitle("Edit Users");
        }
    }
}
