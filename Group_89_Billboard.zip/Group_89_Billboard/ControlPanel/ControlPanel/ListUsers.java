package ControlPanel;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.ConnectException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Properties;
import java.util.List;
import java.util.ArrayList;

public class ListUsers extends JFrame implements ActionListener {
    //Containers
    int port;
    String[] tmp;
    String username, SessionToken;
    Boolean continues = false;
    Boolean displaylist= false;
    String Values="";
    private static String hostName;
    //Table
    Object[][] row = {};
    String[] column = {"No.", "Username"};
    DefaultTableModel model = new DefaultTableModel(row, column){
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    JTable Table = new JTable(model);
    JScrollPane Pane = new JScrollPane(Table);
    //Container
    Container c = getContentPane();
    //Label
    JLabel ListUser = new JLabel("List of Users");
    //Button
    JButton Back = new JButton("Back");
    JButton list = new JButton("List") ;
    JButton logout = new JButton("Logout");
    //String

    //Object                                                    
    Login log =new Login();
    //Socket
    //Constructor
    ListUsers() {
        setLayoutManager();
        setBounds();
        add();

        addactionEvent();
    }
    //Function sets layout
    public void setLayoutManager() {
        c.setLayout(null);
    }
    //Function to add components to container
    public void add() {
        c.add(ListUser);
        c.add(Pane);
        c.add(list);
        c.add(Back);
        c.add(logout);
        c.setBackground(Color.WHITE);
        c.setForeground(Color.BLACK);
    }
    //Function to setBounds to components
    public void setBounds() {
        list.setBounds(170,0,75,30);
        logout.setBounds(300,0,75,30);
        ListUser.setFont(new Font("Arial ", Font.BOLD, 18));
        ListUser.setBounds(10,5,150,30);
        Pane.setBounds(10, 30, 200, 450);
        Back.setBounds(10,500,100,30);
    }
    //Function to Add Action Event to Components
    public void addactionEvent(){
        list.addActionListener(this);
        Back.addActionListener(this);
        logout.addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        String buttonString = e.getActionCommand();
        if(buttonString.equals("List")){
            String answer = "";

            Socket socket = null;
            String currentDirectory = System.getProperty("user.dir");
            BufferedReader input = null;
            PrintWriter output = null;
            try (InputStream client_properties = new FileInputStream(currentDirectory+"/client.props")) {
                Properties client_props = new Properties();
                // load a properties file
                client_props.load(client_properties);
                // get the port property value
                port = Integer.parseInt(client_props.getProperty("srv.port"));
                hostName = client_props.getProperty("srv.hostname").toString();
                try {
                    System.out.println("Connecting to Server:"+hostName+" port:"+port);
                    SessionToken = log.getSessionToken();
                    socket = new Socket(hostName, port);
                    output = new PrintWriter(socket.getOutputStream(), true);
                    input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    output.println(SessionToken);
                    output.println("user:list");
                    while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                        if (answer.equals("ACK")) {
                            displaylist = true;
                        } else if (answer.contains("ERR")) {
                            displaylist = false;
                        }
                    }
                    while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                        if (answer.contains("ERR")) {
                            displaylist = false;
                        } else {
                            list.setEnabled(false);
                            displaylist=true;
                            Values = Values + answer+"\r\n";
                        }
                    }
                    if(!displaylist){
                        JOptionPane.showMessageDialog(this, "ERR: Invalid Permission");
                    }
                    else{
                        System.out.println("Values = "+Values);
                        tmp = Values.split("\r\n");

                        System.out.println(tmp);
                        for (int i = 0; i < tmp.length; i++) {
                            model.addRow(new Object[]{i+1, tmp[i]});
                        }
                    }
                } catch (UnknownHostException Se) {
                    System.err.println("Unknown host: " + hostName);
                    System.exit(1);
                } catch (ConnectException Se) {
                    System.err.println("Connection refused by host: " + hostName);
                    System.exit(1);
                } catch (IOException Se) {
                    Se.printStackTrace();
                } catch (NullPointerException Se) {
                    System.out.println("NullPointerException thrown!");
                }
                // finally, close the socket and decrement runningThreads
                finally {
                    System.out.println("closing");
                    try {
                        input.close();
                        output.close();
                        socket.close();
                        System.out.flush();
                    } catch (IOException Se) {
                        System.out.println("Couldn't close socket");
                    }
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }


        if (buttonString.equals("Logout")) {

            String currentDirectory = System.getProperty("user.dir");
            username = log.getUsername();
            SessionToken = log.getSessionToken();
            Socket s = log.getSocket();
            BufferedReader input = null;
            PrintWriter output = null;
            try (InputStream client_properties = new FileInputStream(currentDirectory + "/client.props")) {
                Properties client_props = new Properties();
                // load a properties file
                client_props.load(client_properties);

                // get the port property value
                port = Integer.parseInt(client_props.getProperty("srv.port"));
                hostName = client_props.getProperty("srv.hostname").toString();

                try {
                    s = new Socket(hostName, port);
                    output = new PrintWriter(s.getOutputStream(), true);
                    input = new BufferedReader(new InputStreamReader(s.getInputStream()));
                    SessionToken = log.getSessionToken();
                    output.println(SessionToken);
                    output.println("user:logout");
                    String answer = "";
                    while (((answer = input.readLine()) != null) && (!answer.contains("END_MESSAGE"))) {

                        if (answer.equals("Sucess: Logged Out")) {
                            continues= true;
                        }
                        else if (answer.contains("ERR")){
                            continues = false;
                        }
                    }
                    while (((answer = input.readLine()) != null) && (!answer.contains("END_MESSAGE"))) {

                        if (answer.contains("ERR")){
                            continues = false;
                        }
                        else{
                            continues = true;
                        }
                    }
                    if (!continues) {
                        if(answer.equals("ERR: Invalid Permission!")){
                            JOptionPane.showMessageDialog(this,"ERR: Invalid Permission!");
                        }
                    } else {
                        //shows acknowledgement, closes connection, disposes current window, shows login window
                        JOptionPane.showMessageDialog(this, "Logout Succesfutl");
                        s.close();
                        dispose();
                        Login login = new Login();
                        login.setBackground(Color.BLACK);
                        login.setForeground(Color.WHITE);
                        login.setBounds(10, 10, 370, 600);
                        login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        login.setVisible(true);
                        login.setTitle("Billboard Control Panel Login");

                    }
                } catch (UnknownHostException Se) {
                    System.err.println("Unknown host: " + hostName);
                    System.exit(1);
                } catch (ConnectException Se) {
                    System.err.println("Connection refused by host: " + hostName);
                    System.exit(1);
                } catch (IOException Se) {
                    Se.printStackTrace();
                } catch (NullPointerException Se) {
                    System.out.println("NullPointerException thrown!");
                }
                // finally, close the socket and decrement runningThreads
                finally {
                    System.out.println("closing");
                    try {
                        input.close();
                        output.close();
                        s.close();
                        System.out.flush();
                    } catch (IOException Se) {
                        System.out.println("Couldn't close socket");
                    }
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        if (buttonString.equals("Back")) {
            dispose();
            JFrame UM = new UserMenu();
            UM.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            UM.setBounds(20, 20, 400, 600);
            UM.setVisible(true);
            UM.setTitle("User Menu");
        }
    }
}