package ControlPanel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.ConnectException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Properties;

public class CreateBillBoard extends JFrame implements ActionListener {
    //Integer
    int port;

    //String
    String username, SessionToken;
    Boolean continues = false;
    private static String hostName;

    //Container
    Container c = getContentPane();

    //Button
    JButton Text = new JButton("Text");
    JButton Image = new JButton("Image");
    JButton IT = new JButton("Image & Text");
    JButton logout = new JButton("Logout");
    JButton Back = new JButton("Back");

    //Labels
    JLabel CB = new JLabel("Create/Edit a BillBoard");
    JLabel InfoText = new JLabel("Billboard with only Text");
    JLabel InfoImage = new JLabel("Billboard with only Image");
    JLabel InfoIT = new JLabel("Billboard with both Image and Text");

    //Object
    Login log = new Login();

    //Container
    CreateBillBoard() {
        setLayoutManager();
        setLocationAndSize();
        addComponents();
        addActionEvent();
    }

    //Function to add Components
    public void addComponents() {
        c.add(CB);
        c.add(InfoImage);
        c.add(Image);
        c.add(InfoText);
        c.add(Text);
        c.add(InfoIT);
        c.add(IT);
        c.add(Back);
        c.add(logout);
        c.setBackground(Color.WHITE);
        c.setForeground(Color.BLACK);
    }

    //Function to add Action Listener
    public void addActionEvent() {
        Image.addActionListener(this);
        Text.addActionListener(this);
        IT.addActionListener(this);
        logout.addActionListener(this);
        Back.addActionListener(this);
    }

    //Function to set Layout
    public void setLayoutManager() {
        //Setting layout manager of Container to null
        c.setLayout(null);
    }

    //Function to set bounds
    public void setLocationAndSize() {
        logout.setBounds(300,10,75,30);
        CB.setBounds(80,10,200,40);
        CB.setFont(new Font("Arial", Font.BOLD,18));
        InfoText.setBounds(100, 60, 200, 40);
        Text.setBounds(100, 120, 200, 40);
        InfoImage.setBounds(100, 180, 200, 40);
        Image.setBounds(100,240 , 200, 40);
        InfoIT.setBounds(100,300,250,40);
        IT.setBounds(100,360,200,40);
        Back.setBounds(150,420,100,40);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        String buttonString = e.getActionCommand();

        //Checks if Text button was pressed
        if (buttonString.equals("Text")){
            dispose();
            Text text = new Text();
            text.setBounds(20, 20, 400, 600);
            text.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            text.setVisible(true);
            text.setTitle("Text Billboard");
        }
        //Checks if Image button was pressed
        else if (buttonString.equals("Image")) {
            dispose();
            Image img = new Image();
            img.setBounds(20, 20, 500, 600);
            img.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            img.setVisible(true);
            img.setTitle("Image Billboard");
        }
        //Checks if Image & Text button was pressed
        else if(buttonString.equals("Image & Text")){
            dispose();
            ImageText IT = new ImageText();
            IT.setBounds(20, 0, 500, 680);
            IT.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            IT.setVisible(true);
            IT.setTitle("Image & Text Billboard");
        }
        //Checks if Logout button was pressed
        if (buttonString.equals("Logout")) {
            String currentDirectory = System.getProperty("user.dir");
            username = log.getUsername();
            SessionToken = log.getSessionToken();
            Socket s = log.getSocket();
            BufferedReader input = null;
            PrintWriter output = null;
            //Reading from client props file
            try (InputStream client_properties = new FileInputStream(currentDirectory + "/client.props")) {
                Properties client_props = new Properties();
                // load a properties file
                client_props.load(client_properties);
                // get the port property value
                port = Integer.parseInt(client_props.getProperty("srv.port"));
                hostName = client_props.getProperty("srv.hostname").toString();
                //sending request to server
                try {
                    s = new Socket(hostName, port);
                    output = new PrintWriter(s.getOutputStream(), true);
                    input = new BufferedReader(new InputStreamReader(s.getInputStream()));
                    output.println(SessionToken);
                    output.println("user:logout");
                    String answer = "";

                    //reading response from server
                    while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                        System.out.println("{Server} Response:" + answer);
                        if (answer.equals("Success: Logged Out")) {
                            continues = true;
                        }
                        else if (answer.contains("ERR")){
                            continues = false;
                        }
                    }
                    //reading response from server
                    while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                        System.out.println("{Server} Response:" + answer);
                        if (answer.equals("Success: Logged Out")) {
                            continues = true;
                        }
                        else if (answer.contains("ERR")){
                            continues = false;
                        }
                    }
                    //shows error
                    if (!continues) {
                        JOptionPane.showMessageDialog(this, answer);
                    } else {
                        //closes connections,displays acknowledgement, disposes screen, shows logout screen
                        JOptionPane.showMessageDialog(this, "Logout Succesfutl");
                        s.close();
                        dispose();
                        Login login = new Login();
                        login.setBackground(Color.BLACK);
                        login.setForeground(Color.WHITE);
                        login.setBounds(10, 10, 370, 600);
                        login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        login.setVisible(true);
                        login.setTitle("Billboard Control Panel Login");
                    }
                } catch (UnknownHostException Se) {
                    System.err.println("Unknown host: " + hostName);
                    System.exit(1);
                } catch (ConnectException Se) {
                    System.err.println("Connection refused by host: " + hostName);
                    System.exit(1);
                } catch (IOException Se) {
                    Se.printStackTrace();
                } catch (NullPointerException Se) {
                    System.out.println("NullPointerException thrown!");
                }
                // finally, close the socket and decrement runningThreads
                finally {
                    System.out.println("closing");
                    try {
                        input.close();
                        output.close();
                        s.close();
                        System.out.flush();
                    } catch (IOException Se) {
                        System.out.println("Couldn't close socket");
                    }
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }

        //Checks if Back button was pressed
        else if (buttonString.equals("Back")) {
            dispose();
            JFrame menu = new Menu();
            menu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            menu.setBounds(20, 20, 400, 600);
            menu.setVisible(true);
            menu.setTitle("Control Panel");
        }
    }
}
