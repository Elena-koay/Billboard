package ControlPanel;

import ControlPanel.PasswordHash;
//import jdk.jfr.StackTrace;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.net.ConnectException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Stack;
import java.util.Properties;

public class Login extends JFrame implements ActionListener {

    //Strings
    private static String username;
    private static String password;
    private static String hostName;
    private static String SessionToken;

    //Int
    int port = 51234;

    //Container
    Container container = getContentPane();

    //labels
    JLabel LOGIN = new JLabel("LOGIN");
    JLabel userName = new JLabel("USERNAME");
    JLabel passWord = new JLabel("PASSWORD");

    //text fields
    JTextField userTextField = new JTextField();

    //PasswordField
    JPasswordField passwordField = new JPasswordField();

    //buttons
    JButton loginButton = new JButton("LOGIN");
    JButton resetButton = new JButton("RESET");

    //class constructor
    Login() {
        setLayoutManager();
        setLocationAndSize();
        addComponents();
        addActionEvent();
    }

    //function to add components to the container
    public void addComponents() {
        container.add(LOGIN);
        container.add(userName);
        container.add(passWord);
        container.add(userTextField);
        container.add(passwordField);
        container.add(loginButton);
        container.add(resetButton);
        container.setBackground(Color.WHITE);
        container.setForeground(Color.BLACK);
    }

    //function that adds Action listener to components
    public void addActionEvent() {
        loginButton.addActionListener(this);
        resetButton.addActionListener(this);
    }

    //function that sets layout manager of Container to null
    public void setLayoutManager() {
        container.setLayout(null);
    }

    //Setting location and Size of each components using setBounds() method.
    public void setLocationAndSize() {
        LOGIN.setBounds(145, 100, 100, 80);
        LOGIN.setFont(new Font("ARIAL", Font.BOLD, 24));
        userName.setBounds(50, 170, 100, 30);
        passWord.setBounds(50, 220, 100, 30);
        userTextField.setBounds(150, 170, 150, 30);
        passwordField.setBounds(150, 220, 150, 30);
        loginButton.setBounds(50, 300, 100, 30);
        resetButton.setBounds(200, 300, 100, 30);
    }
    //Function return Username
    public String getUsername() {
        return this.username;
    }

    //Function sets Username
    public void setUsername(String name) {
        this.username = name;
    }

    //Function returns Password
    public String getPassword() {
        return this.password;
    }

    //Function returns SessionToken
    public String getSessionToken() {
        return this.SessionToken;
    }

    //Function sets Password
    public void setPassword(String pword) {
        this.password = pword;
    }

    //Function returns Socket
    public Socket getSocket() {
        try {
            return new Socket(hostName, port);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        hostName = "localhost";
        String currentDirectory = System.getProperty("user.dir");
        String buttonString = e.getActionCommand();
        //Checks if login button is clicked
        if (buttonString.equals("LOGIN")) {
            username = userTextField.getText();
            password = passwordField.getText();

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Fields cannot be empty");
            } else {

                //Hashing password using function hashPass
                //byte[] hashedpass = hashPass(password);
                String hash_pass = "";
                try {
                    hash_pass= PasswordHash.getHashPWD(password);
                } catch (NoSuchAlgorithmException ex) {
                    ex.printStackTrace();
                }
                //starting a connection with the server
                //send a request
                //read the response
                //sending username and hash to the server
                String answer = "";
                String[] tmp;
                String ErrorMsg = "";
                Boolean isAuthenticated = false;
                Socket socket = null;
                BufferedReader input = null;
                PrintWriter output = null;
                try (InputStream client_properties = new FileInputStream(currentDirectory+"/client.props")) {
                    Properties client_props = new Properties();
                    // load a properties file
                    client_props.load(client_properties);

                    // get the port property value
                    port = Integer.parseInt(client_props.getProperty("srv.port"));
                    hostName = client_props.getProperty("srv.hostname").toString();

                    //send request to server
                    try {
                        System.out.println("Connecting to Server:"+hostName+" port:"+port);
                        socket = new Socket(hostName, port);
                        output = new PrintWriter(socket.getOutputStream(), true);
                        input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                        output.println("login:" + username + ":" + hash_pass);
                        while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {

                            System.out.println("{Server} Response:"+answer);

                            if (answer.contains("token:") || answer.contains("ERR:")) {
                                tmp = answer.split(":");
                                if (answer.contains("token:") ){
                                    SessionToken = answer;
                                    isAuthenticated = true;
                                }else {
                                    ErrorMsg = tmp[1];
                                    isAuthenticated = false;
                                }
                            }
                        }

                        // if username and password are correct and accepted then goes to next screen
                        //else displays error from Server
                        if (!isAuthenticated) {
                            if (ErrorMsg.isEmpty()) ErrorMsg = "Not connected to the server or not authenticated";
                            JOptionPane.showMessageDialog(this, ErrorMsg);
                        } else {
                            //sending session token to server for authentication
                            //SessionToken = answer;
                            //System.out.println("{Server} Response:"+answer);
                            PrintWriter ins = null;
                            try {
                                ins = new PrintWriter(socket.getOutputStream(), true);
                            } catch (IOException ioException) {
                                ioException.printStackTrace();
                            }
                            ins.println(SessionToken);
                            ins.flush();
                            //Goes to next screen
                            dispose();
                            JFrame menu = new Menu();
                            menu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                            menu.setBounds(20, 20, 400, 600);
                            menu.setVisible(true);
                            menu.setTitle("Control Panel");
                        }
                    }
                    catch (UnknownHostException Se) {
                        JOptionPane.showMessageDialog(this, "Could not connect to server:" + hostName);

                    }
                    catch (ConnectException Se) {
                       JOptionPane.showMessageDialog(this,  "Connection refused by host: " + hostName);

                    }
                    catch (IOException Se) {
                        Se.printStackTrace();
                    }
                    catch(NullPointerException Se) {
                        JOptionPane.showMessageDialog(this, "NullPointerException thrown!");
                    }
                    // finally, close the socket and decrement runningThreads
                    finally {
                        if(isAuthenticated) {
                            System.out.println("closing");
                            try {
                                input.close();
                                output.close();
                                socket.close();
                                System.out.flush();
                            } catch (IOException Se) {
                                System.out.println("Couldn't close socket");
                            }
                        }
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }

        }
        //checks if reset button is clicked
        if (buttonString.equals("RESET")) {
            //resets text fields
            userTextField.setText("");
            passwordField.setText("");
        }
    }
}
