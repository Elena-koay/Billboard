package ControlPanel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.ConnectException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Properties;

public class EditPermissions extends JFrame implements ActionListener {
    //Integer
    int port;

    //Boolean
    Boolean edit = false;
    Boolean continues = false;

    //container
    Container c = getContentPane();

    //labels
    JLabel editUser = new JLabel("Edit Permissions");
    JLabel enterUserName = new JLabel("Enter Username");
    JLabel enterPermission = new JLabel("Select Permissions");

    //Textfield
    JTextField usernameText = new JTextField("");

    //String
    String userName = null;
    String username, SessionToken;
    private static String hostName;

    //CheckBox
    JCheckBox CreateBillBoard = new JCheckBox("Create BillBoards");
    JCheckBox EditAllBillBoard = new JCheckBox("Edit All BillBoards");
    JCheckBox ScheduleBillBoard = new JCheckBox("Schedule BillBoards");
    JCheckBox EditUser = new JCheckBox("Edit Users");

    //Buttons
    JButton confirmButton = new JButton("Confirm");
    JButton Back = new JButton("Back");
    JButton logout = new JButton("Logout");

    //Object
    Login log = new Login();

    //Constructor
    EditPermissions(){
        setLayoutManager();
        setBounds();
        add();
        addActionEvent();
    }
    //Function to add action listener
    public void addActionEvent() {
        confirmButton.addActionListener(this);
        Back.addActionListener(this);
        logout.addActionListener(this);
    }

    //Function to set Layout Manager
    public void setLayoutManager()
    {
        c.setLayout(null);
    }

    //Function to add components to container
    public void add(){
        c.add(editUser);
        c.add(enterUserName);
        c.add(enterPermission);
        c.add(CreateBillBoard);
        c.add(EditAllBillBoard);
        c.add(ScheduleBillBoard);
        c.add(EditUser);
        c.add(usernameText);
        c.add(confirmButton);
        c.add(Back);
        c.add(logout);
        c.setBackground(Color.WHITE);
        c.setForeground(Color.BLACK);
    }

    //Function to set bounds
    public void setBounds(){
        editUser.setFont(new Font("Arial ",Font.BOLD,18));
        editUser.setBounds(10,10,200,30);
        enterUserName.setBounds(10,50,100,30);
        usernameText.setBounds(120,50,150,30);
        enterPermission.setBounds(10,90,150,30);
        CreateBillBoard.setBounds(10,120,150,30);
        EditAllBillBoard.setBounds(170,120,150,30);
        ScheduleBillBoard.setBounds(10,170,150,30);
        EditUser.setBounds(170,170,150,30);
        confirmButton.setBounds(10,210,100,30);
        Back.setBounds(10,250,100,30);
        logout.setBounds(300,10,75,30);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String buttonString = e.getActionCommand();
        String selected="";

        //checks which Check box was selected
        if(buttonString.equals("Confirm")) {
            userName = usernameText.getText();
            if(CreateBillBoard.isSelected()){
                selected= selected+"create billboard,";
            }
            if(EditAllBillBoard.isSelected()){
                selected= selected+"edit billboard,";
            }
            if(ScheduleBillBoard.isSelected()){
                selected= selected+"edit schedule,";
            }
            if(EditUser.isSelected()){
                selected= selected+"edit users,";

            }
            if (userName.isEmpty() ) {
                JOptionPane.showMessageDialog(this, "Fields cannot be empty");
            }
            else {
                //Sending request to server
                String request;
                if(selected.isEmpty()){
                    request= "user:set permission::"+userName;
                }
                else{
                    request=  "user:set permission:"+selected+":"+userName;
                }
                String answer = "";
                Socket socket = null;
                String currentDirectory = System.getProperty("user.dir");
                BufferedReader input = null;
                PrintWriter output = null;
                //Reading from client.props file
                try (InputStream client_properties = new FileInputStream(currentDirectory+"/client.props")) {
                    Properties client_props = new Properties();
                    // load a properties file
                    client_props.load(client_properties);
                    // get the port property value
                    port = Integer.parseInt(client_props.getProperty("srv.port"));
                    hostName = client_props.getProperty("srv.hostname").toString();
                    //Sending request to server
                    try {
                        System.out.println("Connecting to Server:"+hostName+" port:"+port);
                        SessionToken = log.getSessionToken();
                        socket = new Socket(hostName, port);
                        output = new PrintWriter(socket.getOutputStream(), true);
                        input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                        output.println(SessionToken);
                        output.println(request);
                        //reading response from server
                        while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                            System.out.println("{Server} Response:" + answer);
                            if (answer.equals("ACK")) {
                                edit = true;
                            } else if (answer.contains("ERR")) {
                                edit = false;
                            }
                        }
                        //reading response from server
                        while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                            System.out.println("{Server} Response:" + answer);
                            if (answer.equals("Success: Permissions Updated!")) {
                                edit = true;
                            } else if (answer.contains("ERR")) {
                                edit = false;
                                //Shows error
                                JOptionPane.showMessageDialog(this, answer);
                            }
                        }
                        //Shows acknowledgement
                        if(edit){
                            JOptionPane.showMessageDialog(this,userName +":Permissions Updated");
                        }
                    } catch (UnknownHostException Se) {
                        System.err.println("Unknown host: " + hostName);
                        System.exit(1);
                    } catch (ConnectException Se) {
                        System.err.println("Connection refused by host: " + hostName);
                        System.exit(1);
                    } catch (IOException Se) {
                        Se.printStackTrace();
                    } catch (NullPointerException Se) {
                        System.out.println("NullPointerException thrown!");
                    }
                    // finally, close the socket and decrement runningThreads
                    finally {
                        System.out.println("closing");
                        try {
                            input.close();
                            output.close();
                            socket.close();
                            System.out.flush();
                        } catch (IOException Se) {
                            System.out.println("Couldn't close socket");
                        }
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        }
        if (buttonString.equals("Logout")) {
            String currentDirectory = System.getProperty("user.dir");
            username = log.getUsername();
            SessionToken = log.getSessionToken();
            Socket s = log.getSocket();
            BufferedReader input = null;
            PrintWriter output = null;
            //Reading from client props file
            try (InputStream client_properties = new FileInputStream(currentDirectory + "/client.props")) {
                Properties client_props = new Properties();
                // load a properties file
                client_props.load(client_properties);

                // get the port property value
                port = Integer.parseInt(client_props.getProperty("srv.port"));
                hostName = client_props.getProperty("srv.hostname").toString();
                //Sendin request to server
                try {
                    s = new Socket(hostName, port);
                    output = new PrintWriter(s.getOutputStream(), true);
                    input = new BufferedReader(new InputStreamReader(s.getInputStream()));
                    output.println(SessionToken);
                    output.println("user:logout");
                    String answer = "";
                    //reading response from server
                    while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                        System.out.println("{Server} Response:" + answer);
                        if (answer.equals("Sucess: Logged Out")) {
                            continues = true;
                        }
                        else if (answer.contains("ERR")){
                            continues = false;
                        }
                    }
                    //reading response from server
                    while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                        System.out.println("{Server} Response:" + answer);
                        if (answer.equals("Sucess: Logged Out")) {
                            continues = true;
                        }
                        else if (answer.contains("ERR")){
                            continues = false;
                        }
                    }
                    //displays error
                    if (!continues) {
                        JOptionPane.showMessageDialog(this, answer);
                    } else {
                        //shows acknowledgement, closes connection, disposes current window, shows login window
                        JOptionPane.showMessageDialog(this, "Logout Succesfutl");
                        s.close();
                        dispose();
                        Login login = new Login();
                        login.setBackground(Color.BLACK);
                        login.setForeground(Color.WHITE);
                        login.setBounds(10, 10, 370, 600);
                        login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        login.setVisible(true);
                        login.setTitle("Billboard Control Panel Login");
                    }
                } catch (UnknownHostException Se) {
                    System.err.println("Unknown host: " + hostName);
                    System.exit(1);
                } catch (ConnectException Se) {
                    System.err.println("Connection refused by host: " + hostName);
                    System.exit(1);
                } catch (IOException Se) {
                    Se.printStackTrace();
                } catch (NullPointerException Se) {
                    System.out.println("NullPointerException thrown!");
                }
                // finally, close the socket and decrement runningThreads
                finally {
                    System.out.println("closing");
                    try {
                        input.close();
                        output.close();
                        s.close();
                        System.out.flush();
                    } catch (IOException Se) {
                        System.out.println("Couldn't close socket");
                    }
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        //checks if back button was pressed
        if(buttonString.equals("Back")) {
            dispose();
            JFrame UM = new UserMenu();
            UM.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            UM.setBounds(20, 20, 400, 600);
            UM.setVisible(true);
            UM.setTitle("User Menu");
        }
    }
}