package ControlPanel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.ConnectException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Properties;

public class DeleteBillboard extends JFrame implements ActionListener {
    //Integer
    int port;

    //Boolean
    Boolean continues = false;
    Boolean continuedelete = false;

    //Labels
    JLabel delete_billBoard = new JLabel("Delete Bill Board");
    JLabel nameLabel = new JLabel("Enter Name of Bill Board");

    //TextBoxes
    JTextField blank = new JTextField();

    //Buttons
    JButton delete = new JButton("Delete");
    JButton back = new JButton("Back");
    JButton logout = new JButton("Logout");

    //Container
    Container c = getContentPane();

    //Object
    Login log  = new Login();

    //String
    String username, SessionToken;
    private static String hostName;

    //Constructor
    DeleteBillboard() {
        setLayoutManager();
        setLocationAndSize();
        addComponents();
        addActionEvent();
    }

    //Function to add components to the container
    public void addComponents() {
        c.add(delete_billBoard);
        c.add(back);
        c.add(blank);
        c.add(delete);
        c.add(nameLabel);
        c.add(logout);
        c.setBackground(Color.WHITE);
        c.setForeground(Color.BLACK);
    }

    //Function to add action event to components
    public void addActionEvent() {
        delete.addActionListener(this);
        back.addActionListener(this);
        logout.addActionListener(this);
    }

    //Function to set Layout
    public void setLayoutManager() {
        //Setting layout manager of Container to null
        c.setLayout(null);
    }

    //Function to set the location and sizes of different components
    public void setLocationAndSize() {
        logout.setBounds(300,10,75,30);
        delete_billBoard.setBounds(10, 10, 250, 40);
        delete_billBoard.setFont(new Font("Arial", Font.BOLD, 18));
        nameLabel.setBounds(10, 50, 150, 40);
        blank.setBounds(10, 100, 150, 40);
        delete.setBounds(170, 100, 100, 40);
        back.setBounds(10, 190, 100, 40);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String buttonString = e.getActionCommand();

        //Checks if delete button was clicked
        if (buttonString.equals("Delete")) {
            String name = blank.getText();
            //checks if field was empty
            if (name.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Field cannot be empty");
            } else {
                String answer = "";
                Socket socket = null;
                String currentDirectory = System.getProperty("user.dir");
                BufferedReader input = null;
                PrintWriter output = null;
                try (InputStream client_properties = new FileInputStream(currentDirectory+"/client.props")) {
                    Properties client_props = new Properties();
                    // load a properties file
                    client_props.load(client_properties);

                    // get the port property value
                    port = Integer.parseInt(client_props.getProperty("srv.port"));
                    hostName = client_props.getProperty("srv.hostname").toString();
                    try {
                        //writing to server
                        System.out.println("Connecting to Server:"+hostName+" port:"+port);
                        SessionToken = log.getSessionToken();
                        socket = new Socket(hostName, port);
                        output = new PrintWriter(socket.getOutputStream(), true);
                        input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                        output.println(SessionToken);
                        output.println("billboard:delete:" + name);

                        //reading response
                        while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                            System.out.println("{Server} Response:" + answer);
                            if (answer.equals("ACK")) {
                                continuedelete = true;
                            } else if (answer.contains("ERR")) {
                                continuedelete = false;
                            }
                        }
                        //reading response from server
                        while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                            System.out.println("{Server} Response:" + answer);
                            if (answer.equals("ACK:BILLBOARD_DELETED")) {
                                continuedelete = true;
                            } else if (answer.contains("ERR")) {
                                continuedelete = false;
                                JOptionPane.showMessageDialog(this, answer);
                            }
                        }
                        //displays erros
                        if(continuedelete){
                            JOptionPane.showMessageDialog(this,name+ " has been deleted!");
                        }
                    } catch (UnknownHostException Se) {
                        System.err.println("Unknown host: " + hostName);
                        System.exit(1);
                    } catch (ConnectException Se) {
                        System.err.println("Connection refused by host: " + hostName);
                        System.exit(1);
                    } catch (IOException Se) {
                        Se.printStackTrace();
                    } catch (NullPointerException Se) {
                        System.out.println("NullPointerException thrown!");
                    }
                    // finally, close the socket and decrement runningThreads
                    finally {
                        System.out.println("closing");
                        try {
                            input.close();
                            output.close();
                            socket.close();
                            System.out.flush();
                        } catch (IOException Se) {
                            System.out.println("Couldn't close socket");
                        }
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        }
        if (buttonString.equals("Logout")) {
            String currentDirectory = System.getProperty("user.dir");
            username = log.getUsername();
            SessionToken = log.getSessionToken();
            Socket s = log.getSocket();
            BufferedReader input = null;
            PrintWriter output = null;
            //reading from props file
            try (InputStream client_properties = new FileInputStream(currentDirectory + "/client.props")) {
                Properties client_props = new Properties();
                // load a properties file
                client_props.load(client_properties);
                // get the port property value
                port = Integer.parseInt(client_props.getProperty("srv.port"));
                hostName = client_props.getProperty("srv.hostname").toString();

                //request to server
                try {
                    s = new Socket(hostName, port);
                    output = new PrintWriter(s.getOutputStream(), true);
                    input = new BufferedReader(new InputStreamReader(s.getInputStream()));
                    output.println(SessionToken);
                    output.println("user:logout");
                    String answer = "";

                    //reading response from server
                    while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                        System.out.println("{Server} Response:" + answer);
                        if (answer.equals("Sucess: Logged Out")) {
                            continues = true;
                        }
                        else if (answer.contains("ERR")){
                            continues = false;
                        }
                    }
                    //reading response from server
                    while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                        System.out.println("{Server} Response:" + answer);
                        if (answer.equals("Sucess: Logged Out")) {
                            continues = true;
                        }
                        else if (answer.contains("ERR")){
                            continues = false;
                        }
                    }
                    //shows error
                    if (!continues) {
                        JOptionPane.showMessageDialog(this, answer);
                    } else {
                        //closes connections
                        //disposes screen and goes to login
                        JOptionPane.showMessageDialog(this, "Logout Succesfutl");
                        s.close();
                        dispose();
                        Login login = new Login();
                        login.setBackground(Color.BLACK);
                        login.setForeground(Color.WHITE);
                        login.setBounds(10, 10, 370, 600);
                        login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        login.setVisible(true);
                        login.setTitle("Billboard Control Panel Login");
                    }
                } catch (UnknownHostException Se) {
                    System.err.println("Unknown host: " + hostName);
                    System.exit(1);
                } catch (ConnectException Se) {
                    System.err.println("Connection refused by host: " + hostName);
                    System.exit(1);
                } catch (IOException Se) {
                    Se.printStackTrace();
                } catch (NullPointerException Se) {
                    System.out.println("NullPointerException thrown!");
                }
                // finally, close the socket and decrement runningThreads
                finally {
                    System.out.println("closing");
                    try {
                        input.close();
                        output.close();
                        s.close();
                        System.out.flush();
                    } catch (IOException Se) {
                        System.out.println("Couldn't close socket");
                    }
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        //Function to return back to previous screen
        if (buttonString.equals("Back")) {
            dispose();
            JFrame listBillboard = new ListBillboard();
            listBillboard.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            listBillboard.setBounds(20, 20, 400, 600);
            listBillboard.setVisible(true);
            listBillboard.setTitle("List Billboard");
        }
    }
}