package ControlPanel;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.*;
import java.util.Base64;
import java.util.Properties;

public class Image extends JFrame implements ActionListener {
    //Integer
    int port;

    //Boolean
    Boolean continues = false;
    Boolean continuecreation=false;

    //Labels
    JLabel message_billboard = new JLabel("Image Billboard");
    JLabel name = new JLabel("Enter Name Of Billboard");
    JLabel pictureLabel = new JLabel();

    //Text
    JTextField nameb = new JTextField("");
    JTextField urltext = new JTextField();

    //Button
    JButton Browse = new JButton("Browse");
    JButton URL = new JButton("URL");
    JButton Back = new JButton("Back");
    JButton Save = new JButton("Save");
    JButton logout = new JButton("Logout");

    //Container
    Container c = getContentPane();

    //Strings
    String nameBillboard = "Billboard";
    String xml;
    String path = null, pathurl = null;
    String encodedImage;
    String username, SessionToken;
    private static String hostName;

    //Login object
    Login log = new Login();

    //Socket
    Socket s ;

    //URL
    URL purl;

    //Constructor
    Image() {
        setLayoutManager();
        setLocationAndSize();
        addComponents();
        addActionEvent();
    }

    //Function to add components to the container
    public void addComponents() {
        c.add(message_billboard);
        c.add(name);
        c.add(nameb);
        c.add(Browse);
        c.add(urltext);
        c.add(URL);
        c.add(Save);
        c.add(pictureLabel);
        c.add(Back);
        c.add(logout);
        c.setBackground(Color.WHITE);
        c.setForeground(Color.BLACK);
    }

    //Function to add action event to components
    public void addActionEvent() {
        logout.addActionListener(this);
        Browse.addActionListener(this);
        URL.addActionListener(this);
        Save.addActionListener(this);
        Back.addActionListener(this);
    }

    //Function to set Layout
    public void setLayoutManager() {
        //Setting layout manager of Container to null
        c.setLayout(null);
    }

    //Function to set the location and sizes of different components
    public void setLocationAndSize() {
        logout.setBounds(400,10,75,30);
        message_billboard.setBounds(10, 10, 250, 40);
        message_billboard.setFont(new Font("Arial", Font.BOLD, 18));
        name.setBounds(10, 60, 200, 40);
        nameb.setBounds(10, 110, 200, 40);
        Browse.setBounds(10,160, 100, 40);
        urltext.setBounds(120, 160, 250, 40);
        URL.setBounds(380,160,100,40);
        pictureLabel.setBounds(10,210,470,280);
        Save.setBounds(10,510,100,40);
        Back.setBounds(120,510,100,40);
    }

    //method to encode string to base64
    public String encodeImage(String imgPath) throws Exception {
        File file = new File(imgPath);
        FileInputStream imageStream = new FileInputStream(file);
        //byte[] data = imageStream.readAllBytes();
        long length = file.length();
        byte data[] = new byte[(int) length];
        imageStream.read(data);
        imageStream.close();
        String imageString = Base64.getEncoder().encodeToString(data);
        return imageString;
    }

    // Method to resize imageIcon with the same size of a Jlabel
    public ImageIcon ResizeImage(String ImagePath) {
        ImageIcon MyImage = new ImageIcon(ImagePath);
        java.awt.Image img = MyImage.getImage();
        java.awt.Image newImg = img.getScaledInstance(pictureLabel.getWidth(), pictureLabel.getHeight(), java.awt.Image.SCALE_SMOOTH);
        ImageIcon image = new ImageIcon(newImg);
        return image;
    }

    //Function for create XML
    public void createXML(){
        //checks if url was entered
        if(path==null){
            xml =  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+
                    "<billboard background=\"#0000FF\">"+
                    "<picture url =\""+pathurl+"\"/>"+
                    "</billboard>";
        }
        //checks if the image was selected through browse
        if(pathurl==null){
            xml =  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+
                    "<billboard background=\"#0000FF\">"+
                    "<picture data =\""+encodedImage+"\"/>"+
                    "</billboard>";
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String buttonString = e.getActionCommand();

        //checks if browse button was clicked
        if(buttonString.equals("Browse")){
            JFileChooser file = new JFileChooser();
            file.setCurrentDirectory(new File(System.getProperty("user.home")));
            //filter the files
            FileNameExtensionFilter filter = new FileNameExtensionFilter("*.Images", "jpg", "png");
            file.addChoosableFileFilter(filter);
            int result = file.showSaveDialog(null);
            //if the user click on save in Jfilechooser
            if (result == JFileChooser.APPROVE_OPTION) {
                File selectedFile = file.getSelectedFile();
                path = selectedFile.getAbsolutePath();
                pathurl=null;
                pictureLabel.setIcon(ResizeImage(path));
                try {
                    encodedImage = encodeImage(path);
                } catch (Exception exception) {
                    exception.printStackTrace();
                }
            }
        }

        //checks if URLbutton was clicked
        if (buttonString == "URL") {
            pathurl =urltext.getText();
            //displays error if text field empty
            if(pathurl.isEmpty()){
                JOptionPane.showMessageDialog(this, "Enter URL");
            }
            else {
                try {
                    purl = new URL(pathurl);
                } catch (MalformedURLException malformedURLException) {
                    JOptionPane.showMessageDialog(this,"URL broken");
                }
                java.awt.Image image = null;
                try {
                    image = ImageIO.read(purl);
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
                pictureLabel.setIcon(new ImageIcon(image));
                path = null;
            }
        }

        //checks if save button was clicked
        if(buttonString.contains("Save")) {
            nameBillboard = nameb.getText();
            //checks if any field is empty
            if(nameBillboard.isEmpty()||(path==null&&pathurl==null)){
                JOptionPane.showMessageDialog(this,"Fields cannot be empty");
            }
            else {
                createXML();
                BufferedReader input = null;
                PrintWriter output = null;
                String currentDirectory = System.getProperty("user.dir");
                //reading client props
                try (InputStream client_properties = new FileInputStream(currentDirectory + "/client.props")) {
                    Properties client_props = new Properties();
                    // load a properties file
                    client_props.load(client_properties);

                    // get the port property value
                    port = Integer.parseInt(client_props.getProperty("srv.port"));
                    hostName = client_props.getProperty("srv.hostname").toString();
                    //writing to server
                    try {
                        SessionToken = log.getSessionToken();
                        s = new Socket(hostName, port);
                        System.out.println("Connecting to Server:" + hostName + " port:" + port);
                        output = new PrintWriter(s.getOutputStream(), true);
                        input = new BufferedReader(new InputStreamReader(s.getInputStream()));
                        output.println(SessionToken);
                        output.println("billboard:update:" + nameBillboard + ":" + xml);
                        String answer = "";

                        //getting response from server
                        while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                            System.out.println("{Server} Response:" + answer);
                            if (answer.equals("ACK")) {
                                continuecreation = true;
                            } else if (answer.contains("ERR")) {
                                continuecreation = false;
                            }
                        }
                        //getting response from server
                        while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                            System.out.println("{Server} Response:" + answer);
                            if (answer.equals("ACK:BILLBOARD_CREATED") || answer.equals("ACK:BILLBOARD_EDITED")) {
                                if (answer.equals("ACK:BILLBOARD_CREATED")) {
                                    JOptionPane.showMessageDialog(this, "Billboard created");
                                } else if (answer.equals("ACK:BILLBOARD_EDITED")) {
                                    JOptionPane.showMessageDialog(this, "Billboard edited");
                                }
                                continuecreation = true;
                            } else if (answer.contains("ERR")) {
                                JOptionPane.showMessageDialog(this, answer);
                                continuecreation = false;
                            }
                        }
                    } catch (UnknownHostException Se) {
                        System.err.println("Unknown host: " + hostName);
                        System.exit(1);
                    } catch (ConnectException Se) {
                        System.err.println("Connection refused by host: " + hostName);
                        System.exit(1);
                    } catch (IOException Se) {
                        Se.printStackTrace();
                    } catch (NullPointerException Se) {
                        System.out.println("NullPointerException thrown!");
                    }
                    // finally, close the socket and decrement runningThreads
                    finally {
                        System.out.println("closing");
                        try {
                            input.close();
                            output.close();
                            s.close();
                            System.out.flush();
                        } catch (IOException Se) {
                            System.out.println("Couldn't close socket");
                        }
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        }
        //checks if logout button was pressed
        if (buttonString.equals("Logout")) {
            String currentDirectory = System.getProperty("user.dir");
            username = log.getUsername();
            SessionToken = log.getSessionToken();
            Socket s = log.getSocket();
            BufferedReader input = null;
            PrintWriter output = null;

            try (InputStream client_properties = new FileInputStream(currentDirectory + "/client.props")) {
                Properties client_props = new Properties();
                // load a properties file
                client_props.load(client_properties);
                // get the port property value
                port = Integer.parseInt(client_props.getProperty("srv.port"));
                hostName = client_props.getProperty("srv.hostname").toString();
                //writing to server
                try {
                    s = new Socket(hostName, port);
                    output = new PrintWriter(s.getOutputStream(), true);
                    input = new BufferedReader(new InputStreamReader(s.getInputStream()));
                    output.println(SessionToken);
                    output.println("user:logout");
                    String answer = "";
                    while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                        System.out.println("{Server} Response:" + answer);
                        if (answer.equals("Sucess: Logged Out")) {
                            continues = true;
                        }
                        else if (answer.contains("ERR")){
                            continues = false;
                        }
                    }
                    //getting response
                    while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                        System.out.println("{Server} Response:" + answer);
                        if (answer.equals("Sucess: Logged Out")) {
                            continues = true;
                        }
                        else if (answer.contains("ERR")){
                            continues = false;
                        }
                    }
                    //shows error
                    if (!continues) {
                        JOptionPane.showMessageDialog(this, answer);
                    } else {
                        //shows acknowledgement, closes connection, disposes current window, shows login window
                        JOptionPane.showMessageDialog(this, "Logout Succesfutl");
                        s.close();
                        dispose();
                        Login login = new Login();
                        login.setBackground(Color.BLACK);
                        login.setForeground(Color.WHITE);
                        login.setBounds(10, 10, 370, 600);
                        login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        login.setVisible(true);
                        login.setTitle("Billboard Control Panel Login");

                    }
                } catch (UnknownHostException Se) {
                    System.err.println("Unknown host: " + hostName);
                    System.exit(1);
                } catch (ConnectException Se) {
                    System.err.println("Connection refused by host: " + hostName);
                    System.exit(1);
                } catch (IOException Se) {
                    Se.printStackTrace();
                } catch (NullPointerException Se) {
                    System.out.println("NullPointerException thrown!");
                }
                // finally, close the socket and decrement runningThreads
                finally {
                    System.out.println("closing");
                    try {
                        input.close();
                        output.close();
                        s.close();
                        System.out.flush();
                    } catch (IOException Se) {
                        System.out.println("Couldn't close socket");
                    }
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        //checks if back button was pressed,if so returns to previous screen
        if (buttonString.equals("Back")) {
            setVisible(false);
            JFrame CB = new CreateBillBoard();
            CB.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            CB.setBounds(20, 20, 400, 600);
            CB.setVisible(true);
            CB.setTitle("Create Billboard");
        }
    }
}
