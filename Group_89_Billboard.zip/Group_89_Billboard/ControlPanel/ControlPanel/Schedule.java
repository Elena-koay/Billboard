package ControlPanel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.ConnectException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Properties;

public class Schedule extends JFrame implements ActionListener {
    //integer
    int port;

    //String
    String username, SessionToken;
    private static String hostName;
    String request=null;
    String item;
    String Time =null;
    String BillBoardName=null;
    String Duration=null;

    //Boolean
    Boolean schedule = false;
    Boolean continues = false;

    //container
    Container c = getContentPane() ;

    //labels
    JLabel billboardSchedule = new JLabel("Schedule a BillBoard");
    JLabel enterBName = new JLabel("Enter the BillBoard Name");
    JLabel enterTime = new JLabel("Date&Time(24H)(YYYY-MM-DD HH-MM)");
    JLabel enterDuration = new JLabel("Enter the Duration (in mins)");
    JLabel LBR = new JLabel("Re-occurrence of Billboards");
    JLabel LBminutes =new  JLabel("If \"Minutes\": Enter minutes");

    //text box
    JTextField tfBname = new JTextField();
    JTextField tfTime = new JTextField();
    JTextField tfDuration = new JTextField();
    JTextField minutes = new JTextField();

    //buttons
    JButton Confirm = new JButton("Confirm");
    JButton Reset = new JButton("Reset");
    JButton Back = new JButton("Back");
    JButton logout = new JButton("Logout");
    JButton set = new JButton("Set");

    //comboBox
    JComboBox recurrance = new JComboBox();

    //String array
    String[] values = { "Day","Hour","Minute"};

    //Login object
    Login log = new Login();

    //Constructor
    Schedule() {
        setLayoutManager();
        addComponents();
        setBounds();
        ListFunction();
        addActionEvent();
    }

    //Function to put values in JCombo Box
    public void ListFunction(){
        recurrance.setEditable(true);
        for (int i = 0; i < values.length; i++) {
            recurrance.addItem(values[i]);
        }
    }

    //add components to container
    public void addComponents() {
        c.add(LBminutes);
        c.add(minutes);
        c.add(LBR);
        c.add(recurrance);
        c.add(billboardSchedule);
        c.add(enterBName);
        c.add(enterDuration);
        c.add(enterTime);
        c.add(tfBname);
        c.add(tfTime);
        c.add(tfDuration);
        c.add(Confirm);
        c.add(Reset);
        c.add(Back);
        c.add(logout);
        c.add(set);
        c.setBackground(Color.WHITE);
        c.setForeground(Color.BLACK);
    }

    //Function to add action event to components
    public void addActionEvent() {
        Confirm.addActionListener(this);
        Reset.addActionListener(this);
        Back.addActionListener(this );
        logout.addActionListener(this);
        set.addActionListener(this );
    }

    //Function to set size and location of the components
    public void setBounds(){
        billboardSchedule.setBounds(10,10,250,30);
        billboardSchedule.setFont(new Font("Arial", Font.BOLD,18));
        enterBName.setBounds(10,50,200,30);
        tfBname.setBounds(240,50,150,30);
        enterTime.setBounds(10,90,250,30);
        tfTime.setBounds(240,90,150,30);
        enterDuration.setBounds(10,130,220,30);
        tfDuration.setBounds(240,130,150,30);
        LBR.setBounds(10,170,200,30);
        recurrance.setBounds(240,170,100,30 );
        set.setBounds(350,170,75,30);
        LBminutes.setBounds(10,210,200,30);
        minutes.setBounds(240,210,100,30 );
        Confirm.setBounds(10,250,100,30);
        Reset.setBounds(120,290,100,30 );
        Back.setBounds(10,290,100,30);
        logout.setBounds(350,10,75,30);
        minutes.setEditable(false);
    }

    //Fuction to set Layout Manager
    public void setLayoutManager() {
        //Setting layout manager of Container to null
        c.setLayout(null);
    }

    //Function to check for empty fields
    public Boolean checkError(String BillBoardName , String Time, String Duration){
        if( BillBoardName.isEmpty() || Time.isEmpty() || Duration.isEmpty()){
            return true;
        }
        else{
            return false;
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String buttonString =  e.getActionCommand();

        //checks if set button is pressed
        if(buttonString.equals("Set")){
            item = String.valueOf(recurrance.getSelectedItem());
            if(item=="Minute"){
                minutes.setEditable(true);
            }
        }

        //Checks if Confirm button is clicked
        if(buttonString.equals("Confirm")) {
            BillBoardName = tfBname.getText();
            Time = tfTime.getText();
            Duration = tfDuration.getText();
            //check for empty fields using checkError function
            if (checkError(BillBoardName, Time, Duration)) {
                JOptionPane.showMessageDialog(this, "Fields cannot be empty");
            } else {
                int minute = 0;
                if (item == "Minute") {
                    minute = Integer.parseInt(minutes.getText());
                    if (minute == 0) {
                        JOptionPane.showMessageDialog(this, "Minutes set as 15");
                    }
                    request = "billboard:schedule:" + BillBoardName + ":" + Time + ":" +Duration+":minute," + minute + ":1";

                } else if (item == "Day") {
                    request = "billboard:schedule:" + BillBoardName + ":" + Time + ":" +Duration+":day:1";

                } else if (item == "Hour") {
                    request = "billboard:schedule:" + BillBoardName + ":" + Time + ":" +Duration+":hour:1";

                } else {
                    request = "billboard:schedule:" + BillBoardName + ":" + Time + ":" +Duration+"::1";
                }

                String answer = "";
                Socket socket = null;
                String currentDirectory = System.getProperty("user.dir");
                BufferedReader input = null;
                PrintWriter output = null;
                //reading from client props file
                try (InputStream client_properties = new FileInputStream(currentDirectory + "/client.props")) {
                    Properties client_props = new Properties();
                    // load a properties file
                    client_props.load(client_properties);

                    // get the port property value
                    port = Integer.parseInt(client_props.getProperty("srv.port"));
                    hostName = client_props.getProperty("srv.hostname").toString();

                    //sending request to server
                    try {
                        System.out.println("Connecting to Server:" + hostName + " port:" + port);
                        SessionToken = log.getSessionToken();
                        socket = new Socket(hostName, port);
                        output = new PrintWriter(socket.getOutputStream(), true);
                        input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                        output.println(SessionToken);
                        output.println(request);
                        while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                            System.out.println("{Server} Response:" + answer);
                            if (answer.equals("ACK")) {
                                schedule = true;
                            } else if (answer.contains("ERR")) {
                                schedule = false;
                            }
                        }

                        //reading response
                        while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                            System.out.println("{Server} Response:" + answer);
                            if (answer.equals("Success: Billboard added to schedule")) {
                                schedule = true;
                            } else if (answer.contains("ERR")) {
                                schedule = false;
                                //shows error
                                JOptionPane.showMessageDialog(this, answer);
                            }
                        }
                        //shows acknowledgment
                        if (schedule) {
                            JOptionPane.showMessageDialog(this, "Billboard has been Scheduled");
                        }
                    } catch (UnknownHostException Se) {
                        System.err.println("Unknown host: " + hostName);
                        System.exit(1);
                    } catch (ConnectException Se) {
                        System.err.println("Connection refused by host: " + hostName);
                        System.exit(1);
                    } catch (IOException Se) {
                        Se.printStackTrace();
                    } catch (NullPointerException Se) {
                        System.out.println("NullPointerException thrown!");
                    }
                    // finally, close the socket and decrement runningThreads
                    finally {
                        System.out.println("closing");
                        try {
                            input.close();
                            output.close();
                            socket.close();
                            System.out.flush();
                        } catch (IOException Se) {
                            System.out.println("Couldn't close socket");
                        }
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        }
        //checks if logout was pressed
        if (buttonString.equals("Logout")) {
            String currentDirectory = System.getProperty("user.dir");
            username = log.getUsername();
            SessionToken = log.getSessionToken();
            Socket s = log.getSocket();
            BufferedReader input = null;
            PrintWriter output = null;

            //reading from client props file
            try (InputStream client_properties = new FileInputStream(currentDirectory + "/client.props")) {
                Properties client_props = new Properties();
                // load a properties file
                client_props.load(client_properties);

                // get the port property value
                port = Integer.parseInt(client_props.getProperty("srv.port"));
                hostName = client_props.getProperty("srv.hostname").toString();

                //requesting server
                try {
                    s = new Socket(hostName, port);
                    output = new PrintWriter(s.getOutputStream(), true);
                    input = new BufferedReader(new InputStreamReader(s.getInputStream()));
                    output.println(SessionToken);
                    output.println("user:logout");
                    String answer = "";
                    while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                        System.out.println("{Server} Response:" + answer);
                        if (answer.equals("Sucess: Logged Out")) {
                            continues = true;
                        }
                        else if (answer.contains("ERR")){
                            continues = false;
                        }
                    }

                    //reading response
                    while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                        System.out.println("{Server} Response:" + answer);
                        if (answer.equals("Sucess: Logged Out")) {
                            continues = true;
                        }
                        else if (answer.contains("ERR")){
                            continues = false;
                        }
                    }
                    //shows error
                    if (!continues) {
                        JOptionPane.showMessageDialog(this, answer);
                    } else {
                        //shows acknowledgement, closes connection, disposes current window, shows login window
                        JOptionPane.showMessageDialog(this, "Logout Succesfutl");
                        s.close();
                        dispose();
                        Login login = new Login();
                        login.setBackground(Color.BLACK);
                        login.setForeground(Color.WHITE);
                        login.setBounds(10, 10, 370, 600);
                        login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        login.setVisible(true);
                        login.setTitle("Billboard Control Panel Login");
                    }
                } catch (UnknownHostException Se) {
                    System.err.println("Unknown host: " + hostName);
                    System.exit(1);
                } catch (ConnectException Se) {
                    System.err.println("Connection refused by host: " + hostName);
                    System.exit(1);
                } catch (IOException Se) {
                    Se.printStackTrace();
                } catch (NullPointerException Se) {
                    System.out.println("NullPointerException thrown!");
                }
                // finally, close the socket and decrement runningThreads
                finally {
                    System.out.println("closing");
                    try {
                        input.close();
                        output.close();
                        s.close();
                        System.out.flush();
                    } catch (IOException Se) {
                        System.out.println("Couldn't close socket");
                    }
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        //checks if reset button was pressed
        if (buttonString.equals("Reset")){
            tfBname.setText("");
            tfTime.setText("");
            tfDuration.setText("");
        }
        //checks if back button was pressed
        if(buttonString.equals("Back")){
            setVisible(false);
            ScheduleBillBoard scheduleBillboard = new ScheduleBillBoard();
            scheduleBillboard.setBounds(20,20,400,600);
            scheduleBillboard.setVisible(true);
            scheduleBillboard.setTitle("Schedule Billboards");
            scheduleBillboard.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        }


    }
}
