package ControlPanel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.ConnectException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Properties;

public class Menu extends JFrame implements ActionListener {

    //Buttons
    JButton create = new JButton("Create/Edit Billboard");
    JButton list = new JButton("List Billboard");
    JButton schedule = new JButton("Schedule Billboard");
    JButton edituser = new JButton("Edit User");
    JButton logout = new JButton("Logout");

    //Label
    JLabel choose = new JLabel("Choose a function.");

    //Container
    Container c1 = getContentPane();

    //integer
    int port = 51234;

    //Object
    Login log = new Login();

    //String
    String username, SessionToken;
    private static String hostName;

    //Boolean
    Boolean continues = false;

    //Constructor
    Menu() {
        setLayoutManager();
        setLocationAndSize();
        addComponents();
        addActionEvent();
    }

    //function to add components to the container
    public void addComponents() {
        c1.add(create);
        c1.add(list);
        c1.add(schedule);
        c1.add(edituser);
        c1.add(choose);
        c1.add(logout);
        c1.setBackground(Color.WHITE);
        c1.setForeground(Color.BLACK);
    }

    //Function to add ActionEvent to Buttons
    public void addActionEvent() {
        create.addActionListener(this);
        list.addActionListener(this);
        schedule.addActionListener(this);
        edituser.addActionListener(this);
        logout.addActionListener(this);
    }

    //Function to setLayoutManager
    public void setLayoutManager() {
        //Setting layout manager of Container to null
        c1.setLayout(null);
    }

    //Function to set location and size
    public void setLocationAndSize() {
        create.setBounds(100, 140, 180, 40);
        list.setBounds(100, 200, 180, 40);
        schedule.setBounds(100, 260, 180, 40);
        edituser.setBounds(100, 320, 180, 40);
        logout.setBounds(300, 10, 75, 30);
        choose.setBounds(100, 50, 200, 80);
        choose.setFont(new Font("Times New Roman", Font.BOLD, 24));
        c1.setBackground(Color.WHITE);
        c1.setForeground(Color.BLACK);
    }
    //Checks if user has Permission

    @Override
    public void actionPerformed(ActionEvent e) {
        String buttonString = e.getActionCommand();

        //checks if button Create Billboards is pressed
        //If true then goes to next frame
        if (buttonString.equals("Create/Edit Billboard")) {
            dispose();
            JFrame CBillBoard = new CreateBillBoard();
            CBillBoard.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            CBillBoard.setBounds(20, 20, 400, 600);
            CBillBoard.setVisible(true);
            CBillBoard.setTitle("Create/Edit Billboard");
        }
        //checks if button List Billboards Billboard is pressed
        //If true then goes to next frame
        if (buttonString.equals("List Billboard")) {
            dispose();
            JFrame LBillBoard = new ListBillboard();
            LBillBoard.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            LBillBoard.setBounds(20, 20, 400, 600);
            LBillBoard.setVisible(true);
            LBillBoard.setTitle("List Billboard");
        }
        //checks if button Schedule Billboards is pressed
        //If true then goes to next frame
        if (buttonString.equals("Schedule Billboard")) {
            dispose();
            ScheduleBillBoard scheduleBillboard = new ScheduleBillBoard();
            scheduleBillboard.setBounds(20, 20, 400, 600);
            scheduleBillboard.setVisible(true);
            scheduleBillboard.setTitle("Schedule Billboard");
            scheduleBillboard.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        }
        //checks if button Edit User is pressed
        //If true then goes to next frame
        if (buttonString.equals("Edit User")) {
            dispose();
            JFrame editUser = new UserMenu();
            editUser.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            editUser.setBounds(20, 20, 400, 600);
            editUser.setVisible(true);
            editUser.setTitle("Edit User");

        }
        //checks if user clicked logout
        //if so sends server a logout request
        if (buttonString.equals("Logout")) {
            String currentDirectory = System.getProperty("user.dir");
            username = log.getUsername();
            SessionToken = log.getSessionToken();
            Socket s = log.getSocket();
            BufferedReader input = null;
            PrintWriter output = null;
            //reading from client props file
            try (InputStream client_properties = new FileInputStream(currentDirectory + "/client.props")) {
                Properties client_props = new Properties();
                // load a properties file
                client_props.load(client_properties);

                // get the port property value
                port = Integer.parseInt(client_props.getProperty("srv.port"));
                hostName = client_props.getProperty("srv.hostname").toString();

                //sending request to server
                try {
                    s = new Socket(hostName, port);
                    output = new PrintWriter(s.getOutputStream(), true);
                    input = new BufferedReader(new InputStreamReader(s.getInputStream()));
                    output.println(SessionToken);
                    output.println("user:logout");
                    String answer = "";

                    //reading response from server
                    while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                        System.out.println("{Server} Response:" + answer);
                        if (answer.equals("Sucess: Logged Out")) {
                            continues = true;
                        }
                        else if (answer.contains("ERR")){
                            continues = false;
                        }
                    }

                    //reading response from server
                    while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                        System.out.println("{Server} Response:" + answer);
                        if (answer.equals("Sucess: Logged Out")) {
                            continues = true;
                        }
                        else if (answer.contains("ERR")){
                            continues = false;
                        }
                    }

                    //shows error
                    if (!continues) {
                        JOptionPane.showMessageDialog(this, answer);
                    }
                    else {
                        //shows acknowledgement, closes connection, disposes current window, shows login window
                        JOptionPane.showMessageDialog(this, "Logout Succesfutl");
                        s.close();
                        dispose();
                        Login login = new Login();
                        login.setBackground(Color.BLACK);
                        login.setForeground(Color.WHITE);
                        login.setBounds(10, 10, 370, 600);
                        login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        login.setVisible(true);
                        login.setTitle("Billboard Control Panel Login");

                    }
                } catch (UnknownHostException Se) {
                    System.err.println("Unknown host: " + hostName);
                    System.exit(1);
                } catch (ConnectException Se) {
                    System.err.println("Connection refused by host: " + hostName);
                    System.exit(1);
                } catch (IOException Se) {
                    Se.printStackTrace();
                } catch (NullPointerException Se) {
                    System.out.println("NullPointerException thrown!");
                }
                // finally, close the socket and decrement runningThreads
                finally {
                    System.out.println("closing");
                    try {
                        input.close();
                        output.close();
                        s.close();
                        System.out.flush();
                    } catch (IOException Se) {
                        System.out.println("Couldn't close socket");
                    }
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }

    }
}