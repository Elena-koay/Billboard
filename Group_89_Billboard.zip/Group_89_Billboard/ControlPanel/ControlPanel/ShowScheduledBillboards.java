package ControlPanel;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.ConnectException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class ShowScheduledBillboards extends JFrame implements ActionListener {
    //Integer
    int port;
    //Boolean
    Boolean continues = false;
    Boolean displaylist= false;
    String Values="";
    //String Array
    String[] tmp;
    String[] user,eu,st;

    String  SessionToken;
    String username;
    String bname="",creator="",starttime="",rc="",rt="",duration="";
    private static String hostName;

    Object[][] row={};



    Object[] column={"Billboard","Creator","Date and Time","Duration"};
    DefaultTableModel model = new DefaultTableModel(row,column){
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    JTable Table = new JTable(model);
    //scroll for table
    JScrollPane Pane = new JScrollPane(Table);

    //Object of Login Class
    Login log = new Login();

    //Container
    Container c = getContentPane();

    //Label
    JLabel scheduled = new JLabel("Scheduled Billboards");

    //Buttons
    JButton Back = new JButton("Back");
    JButton Show = new JButton("Show");
    JButton Logout = new JButton("Logout");



    //Constructor
    ShowScheduledBillboards() {
        setLayoutManager();
        setBounds();
        add();
        addactionEvent();
    }

    public void setLayoutManager() {
        c.setLayout(null);
    }

    //Function to add components to container
    public void add() {
        c.add(scheduled);
        c.add(Pane);
        c.add(Back);
        c.add(Logout);
        c.add(Show);

    }
    public void setBounds() {
        scheduled.setFont(new Font("Arial ", Font.BOLD, 18));
        scheduled.setBounds(10,5,200,30);
        Show.setBounds(230,5,75,30);
        Pane.setBounds(10, 100, 700, 500);
        Back.setBounds(10,620,100,30);
        Logout.setBounds(310,5,75,30);
        Table.setRowHeight(20);

    }

    public void addactionEvent() {
        Back.addActionListener(this);
        Show.addActionListener(this);
        Logout.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String buttonString = e.getActionCommand();

        //Checks if list button was pressed
        if(buttonString.equals("Show")){
            String answer = "";
            Socket socket = null;
            String currentDirectory = System.getProperty("user.dir");
            BufferedReader input = null;
            PrintWriter output = null;

            //gets values from client.props
            try (InputStream client_properties = new FileInputStream(currentDirectory+"/client.props")) {
                Properties client_props = new Properties();
                // load a properties file
                client_props.load(client_properties);
                // get the port property value
                port = Integer.parseInt(client_props.getProperty("srv.port"));
                hostName = client_props.getProperty("srv.hostname").toString();

                //connecting to server
                try {

                    //writing to server
                    System.out.println("Connecting to Server:" + hostName + " port:" + port);
                    SessionToken = log.getSessionToken();
                    socket = new Socket(hostName, port);
                    output = new PrintWriter(socket.getOutputStream(), true);
                    input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    output.println(SessionToken);
                    output.println("billboard:view schedule");

                    //reading from server
                    while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                        if (answer.equals("ACK")) {
                            displaylist = true;
                        } else if (answer.contains("ERR")) {
                            displaylist = false;

                        }
                    }
                    //reading from server
                    while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                        if (answer.contains("ERR")) {
                            displaylist = false;
                        } else {
                            //Regex to split respone from seerver
                            Show.setEnabled(false);
                            displaylist = true;
                            //System.out.println(answer);

                            String pattern1 = "billboard_name:";
                            String pattern2 = ":creator";
                            Pattern p = Pattern.compile(Pattern.quote(pattern1) + "(.*?)" + Pattern.quote(pattern2));
                            Matcher m = p.matcher(answer);
                            while (m.find()) {
                                bname = bname + m.group(1) + ",";
                            }
                            String pattern3 = "creator:";
                            String pattern4 = ":time";
                            Pattern p1 = Pattern.compile(Pattern.quote(pattern3) + "(.*?)" + Pattern.quote(pattern4));
                            Matcher m2 = p1.matcher(answer);
                            while (m2.find()) {
                                creator = creator + m2.group(1) + ",";
                            }
                            String pattern5 = "time:";
                            String pattern6 = ":duration";
                            Pattern p2 = Pattern.compile(Pattern.quote(pattern5) + "(.*?)" + Pattern.quote(pattern6));
                            Matcher m3 = p2.matcher(answer);
                            while (m3.find()) {
                                starttime = starttime + m3.group(1) + ",";
                            }
                            String pattern7 = "duration:";
                            String pattern8 = ":";
                            Pattern p3 = Pattern.compile(Pattern.quote(pattern7) + "(.*?)"+Pattern.quote(pattern8));
                            Matcher m4 = p3.matcher(answer);
                            while (m4.find()) {
                                duration = duration + m4.group(1) + ",";
                            }

                        }
                        if (!displaylist) {
                            //displays the error
                            JOptionPane.showMessageDialog(this, "ERR: Invalid Permission");
                        } else {


                            tmp = bname.split(",");
                            user = creator.split(",");
                            eu = starttime.split(",");
                            st = duration.split(",");

                            for (int i = 0; i < tmp.length; i++) {
                                model.addRow(new Object[]{tmp[i], user[i],eu[i],st[i]});
                            }
                        }

                    }


                } catch (UnknownHostException Se) {
                    System.err.println("Unknown host: " + hostName);
                    System.exit(1);
                } catch (ConnectException Se) {
                    System.err.println("Connection refused by host: " + hostName);
                    System.exit(1);
                } catch (IOException Se) {
                    Se.printStackTrace();
                } catch (NullPointerException Se) {
                    System.out.println("NullPointerException thrown!");
                }
                // finally, close the socket and decrement runningThreads
                finally {
                    System.out.println("closing");
                    try {
                        input.close();
                        output.close();
                        socket.close();
                        System.out.flush();
                    } catch (IOException Se) {
                        System.out.println("Couldn't close socket");
                    }
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        //checks if back buttons was clicked
        if(buttonString.equals("Back")){
            setVisible(false);
            ScheduleBillBoard scheduleBillboard = new ScheduleBillBoard();
            scheduleBillboard.setBounds(20,20,400,600);
            scheduleBillboard.setVisible(true);
            scheduleBillboard.setTitle("Schedule Billboards");
            scheduleBillboard.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        }
        //checks if logout button was clicked
        if (buttonString.equals("Logout")) {
            String currentDirectory = System.getProperty("user.dir");
            username = log.getUsername();
            SessionToken = log.getSessionToken();
            Socket s = log.getSocket();
            BufferedReader input = null;
            PrintWriter output = null;
            //contacting the server
            try (InputStream client_properties = new FileInputStream(currentDirectory + "/client.props")) {
                //getting values from props file
                Properties client_props = new Properties();
                // load a properties file
                client_props.load(client_properties);
                // get the port property value
                port = Integer.parseInt(client_props.getProperty("srv.port"));
                hostName = client_props.getProperty("srv.hostname").toString();
                //Sending request to server
                try {
                    s = new Socket(hostName, port);
                    output = new PrintWriter(s.getOutputStream(), true);
                    input = new BufferedReader(new InputStreamReader(s.getInputStream()));
                    SessionToken = log.getSessionToken();
                    output.println(SessionToken);
                    output.println("user:logout");
                    String answer = "";
                    //reading response from server
                    while (((answer = input.readLine()) != null) && (!answer.contains("END_MESSAGE"))) {
                        if (answer.equals("Sucess: Logged Out")) {
                            continues= true;
                        }
                        else if (answer.contains("ERR")){
                            continues = false;
                        }
                    }
                    //reading response from server
                    while (((answer = input.readLine()) != null) && (!answer.contains("END_MESSAGE"))) {
                        if (answer.contains("ERR")){
                            continues = false;
                        }
                        else{
                            continues = true;
                        }
                    }
                    if (!continues) {
                        //displays error
                        if(answer.equals("ERR: Invalid Permission!")){
                            JOptionPane.showMessageDialog(this,"ERR: Invalid Permission!");
                        }
                    } else {
                        //closes connections
                        JOptionPane.showMessageDialog(this, "Logout Succesfutl");
                        s.close();
                        //disposes current screen and goes to login screen
                        dispose();
                        Login login = new Login();
                        login.setBackground(Color.BLACK);
                        login.setForeground(Color.WHITE);
                        login.setBounds(10, 10, 370, 600);
                        login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        login.setVisible(true);
                        login.setTitle("Billboard Control Panel Login");
                    }
                } catch (UnknownHostException Se) {
                    System.err.println("Unknown host: " + hostName);
                    System.exit(1);
                } catch (ConnectException Se) {
                    System.err.println("Connection refused by host: " + hostName);
                    System.exit(1);
                } catch (IOException Se) {
                    Se.printStackTrace();
                } catch (NullPointerException Se) {
                    System.out.println("NullPointerException thrown!");
                }
                // finally, close the socket and decrement runningThreads
                finally {
                    System.out.println("closing");
                    try {
                        input.close();
                        output.close();
                        s.close();
                        System.out.flush();
                    } catch (IOException Se) {
                        System.out.println("Couldn't close socket");
                    }
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }


}