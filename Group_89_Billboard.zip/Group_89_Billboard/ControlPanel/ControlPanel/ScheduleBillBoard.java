package ControlPanel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.ConnectException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Properties;

public class ScheduleBillBoard extends JFrame implements ActionListener {
    //Integer
    int port;

    //string
    String username, SessionToken;
    private static String hostName;

    //boolean
    Boolean continues = false;

    //JLabel
    JLabel schedulebillboard = new JLabel();

    //Buttons
    JButton logout = new JButton("Logout");
    JButton schedule = new JButton("Schedule");
    JButton show = new JButton("Show Scheduled Billboards");
    JButton back = new JButton("Back");

    //Container
    Container c = getContentPane();

    //login
    Login log = new Login();

    //constructor
    ScheduleBillBoard() {
        setLayoutManager();
        setLocationAndSize();
        addComponents();
        addActionEvent();
    }

    //function to add components
    public void addComponents() {
        c.add(schedulebillboard);
        c.add(logout);
        c.add(show);
        c.add(back);
        c.add(schedule);
        c.setBackground(Color.WHITE);
        c.setForeground(Color.BLACK);
    }

    //function to add action listener
    public void addActionEvent() {
        logout.addActionListener(this );
        schedule.addActionListener(this);
        show.addActionListener(this);
        back.addActionListener(this);
    }

    //function to set layout
    public void setLayoutManager() {
        //Setting layout manager of Container to null
        c.setLayout(null);
    }

    //function to set bounds
    public void setLocationAndSize() {
        logout.setBounds(300,10,75,30);
        schedulebillboard.setBounds(100,10,200,40);
        schedule.setBounds(100, 140, 200, 40);
        show.setBounds(100, 200, 200, 40);
        back.setBounds(150, 300, 100, 40);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String buttonString = e.getActionCommand();

        //checks if button Create Billboards is pressed
        //If true then goes to next frame
        if (buttonString.equals("Schedule")) {
            //checks if schedule button was pressed
                dispose();
                JFrame schedule = new Schedule();
                schedule.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                schedule.setBounds(20, 20, 450, 600);
                schedule.setVisible(true);
                schedule.setTitle("Schedule BillBoards");
        }

        //checks if show schedule billboard button is pressed
        else if (buttonString.equals("Show Scheduled Billboards")) {
                dispose();
                ShowScheduledBillboards showscheduledbillboards = new ShowScheduledBillboards();
                showscheduledbillboards.setBounds(20, 20, 900, 700);
                showscheduledbillboards.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                showscheduledbillboards.setVisible(true);
                showscheduledbillboards.setTitle("Scheduled BillBoards");
        }

        //checks if logout button is pressed
        if (buttonString.equals("Logout")) {
            String currentDirectory = System.getProperty("user.dir");
            username = log.getUsername();
            SessionToken = log.getSessionToken();
            Socket s = log.getSocket();
            BufferedReader input = null;
            PrintWriter output = null;

            //reeading from client props file
            try (InputStream client_properties = new FileInputStream(currentDirectory + "/client.props")) {
                Properties client_props = new Properties();
                // load a properties file
                client_props.load(client_properties);

                // get the port property value
                port = Integer.parseInt(client_props.getProperty("srv.port"));
                hostName = client_props.getProperty("srv.hostname").toString();

                try {
                    s = new Socket(hostName, port);
                    output = new PrintWriter(s.getOutputStream(), true);
                    input = new BufferedReader(new InputStreamReader(s.getInputStream()));
                    output.println(SessionToken);
                    output.println("user:logout");
                    String answer = "";
                    //reading from server
                    while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                        System.out.println("{Server} Response:" + answer);
                        if (answer.equals("Sucess: Logged Out")) {
                            continues = true;
                        }
                        else if (answer.contains("ERR")){
                            continues = false;
                        }
                    }
                    //reading from server
                    while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                        System.out.println("{Server} Response:" + answer);
                        if (answer.equals("Sucess: Logged Out")) {
                            continues = true;
                        }
                        else if (answer.contains("ERR")){
                            continues = false;
                        }
                    }
                    //shows error
                    if (!continues) {
                        JOptionPane.showMessageDialog(this, answer);
                    } else {
                        //shows acknowledgement, closes connection, disposes current window, shows login window
                        JOptionPane.showMessageDialog(this, "Logout Succesfutl");
                        s.close();
                        dispose();
                        Login login = new Login();
                        login.setBackground(Color.BLACK);
                        login.setForeground(Color.WHITE);
                        login.setBounds(10, 10, 370, 600);
                        login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        login.setVisible(true);
                        login.setTitle("Billboard Control Panel Login");
                    }
                } catch (UnknownHostException Se) {
                    System.err.println("Unknown host: " + hostName);
                    System.exit(1);
                } catch (ConnectException Se) {
                    System.err.println("Connection refused by host: " + hostName);
                    System.exit(1);
                } catch (IOException Se) {
                    Se.printStackTrace();
                } catch (NullPointerException Se) {
                    System.out.println("NullPointerException thrown!");
                }
                // finally, close the socket and decrement runningThreads
                finally {
                    System.out.println("closing");
                    try {
                        input.close();
                        output.close();
                        s.close();
                        System.out.flush();
                    } catch (IOException Se) {
                        System.out.println("Couldn't close socket");
                    }
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        //checks if back button was pressed
        else if (buttonString.equals("Back")) {
            dispose();
            JFrame menu = new Menu();
            menu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            menu.setBounds(20, 20, 400, 600);
            menu.setVisible(true);
            menu.setTitle("Control Panel");
        }
    }
}