package ControlPanel;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.ConnectException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.plaf.synth.SynthTextAreaUI;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AccessBillboards extends JFrame implements ActionListener {
    //Integer
    int port;

    //String Array
    String[] tmp;
    String[] user,eu,st,recurrt,reccurc,length;

    //String
    String  SessionToken;
    String bname="",creator="",edituser="",starttime="",rc="",rt="",duration="";
    String username;
    private static String hostName;

    //Boolean
    Boolean continues = false;
    Boolean displaylist= false;

    //Table
    Object[][] row={};
    Object[] column={"Billboard","Creator","Editor","Start time","Duration","Recurring Type","Recurring Count"};
    DefaultTableModel model = new DefaultTableModel(row,column){
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    JTable Table = new JTable(model);

    //scroll for table
    JScrollPane Pane = new JScrollPane(Table);

    //Object of Login Class
    Login log = new Login();

    //Container
    Container c = getContentPane();

    //Label
    JLabel Listbillboards = new JLabel("List of Billboards");

    //Buttons
    JButton Back = new JButton("Back");
    JButton Access = new JButton("List");
    JButton Logout = new JButton("Logout");

    //Constructor
    AccessBillboards() {
        setLayoutManager();
        setBounds();
        add();
        addactionEvent();
    }

    //Function sets layout to null
    public void setLayoutManager() {
        c.setLayout(null);
    }

    //Function to add components to container
    public void add() {
        c.add(Listbillboards);
        c.add(Pane);
        c.add(Back);
        c.add(Logout);
        c.add(Access);
    }

    //Function to set bounds to components
    public void setBounds() {
        Listbillboards.setFont(new Font("Arial ", Font.BOLD, 18));
        Listbillboards.setBounds(10,5,200,30);
        Access.setBounds(230,5,75,30);
        Pane.setBounds(10, 50, 700, 500);
        Back.setBounds(10,580,100,30);
        Logout.setBounds(310,5,75,30);
        Table.setRowHeight(40);
    }

    //Function adds action listener to components
    public void addactionEvent() {
        Back.addActionListener(this);
        Access.addActionListener(this);
        Logout.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String buttonString = e.getActionCommand();

        //Checks if list button was pressed
        if(buttonString.equals("List")){
            String answer = "";
            Socket socket = null;
            String currentDirectory = System.getProperty("user.dir");
            BufferedReader input = null;
            PrintWriter output = null;

            //gets values from client.props
            try (InputStream client_properties = new FileInputStream(currentDirectory+"/client.props")) {
                Properties client_props = new Properties();
                // load a properties file
                client_props.load(client_properties);
                // get the port property value
                port = Integer.parseInt(client_props.getProperty("srv.port"));
                hostName = client_props.getProperty("srv.hostname").toString();

                //connecting to server
                try {

                    //writing to server
                    System.out.println("Connecting to Server:"+hostName+" port:"+port);
                    SessionToken = log.getSessionToken();
                    socket = new Socket(hostName, port);
                    output = new PrintWriter(socket.getOutputStream(), true);
                    input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    output.println(SessionToken);
                    output.println("billboard:list");

                    //reading from server
                    while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                        if (answer.equals("ACK")) {
                            displaylist = true;
                        }
                        else if (answer.contains("ERR")) {
                            displaylist = false;
                        }
                    }
                    //reading from server
                    while (((answer = input.readLine()) != null) && (!answer.equals("END_MESSAGE"))) {
                        if (answer.contains("ERR")) {
                            displaylist = false;
                        }
                        else {
                            //Regex to split respone from seerver
                            Access.setEnabled(false);
                            displaylist = true;
                            String pattern1 = "billboard_name:";
                            String pattern2 = ":create_user";
                            Pattern p = Pattern.compile(Pattern.quote(pattern1) + "(.*?)" + Pattern.quote(pattern2));
                            Matcher m = p.matcher(answer);
                            while (m.find()) {
                                bname = bname + m.group(1) + ",";
                            }
                            String pattern3 = "create_user:";
                            String pattern4 = ":edit_user";
                            Pattern p1 = Pattern.compile(Pattern.quote(pattern3) + "(.*?)" + Pattern.quote(pattern4));
                            Matcher m2 = p1.matcher(answer);
                            while (m2.find()) {
                                creator = creator + m2.group(1) + ",";
                            }
                            String pattern5 = ":edit_user:";
                            String pattern6 = ":start_time";
                            Pattern p2 = Pattern.compile(Pattern.quote(pattern5) + "(.*?)" + Pattern.quote(pattern6));
                            Matcher m3 = p2.matcher(answer);
                            while (m3.find()) {
                                edituser = edituser + m3.group(1) + ",";
                            }
                            String pattern7 = "start_time:";
                            String pattern8 = ":duration";
                            Pattern p3 = Pattern.compile(Pattern.quote(pattern7) + "(.*?)" + Pattern.quote(pattern8));
                            Matcher m4 = p3.matcher(answer);
                            while (m4.find()) {
                                starttime = starttime + m4.group(1) + ",";
                            }
                            String pattern9 = "duration:";
                            String pattern10 = ":recurring_type";
                            Pattern p4 = Pattern.compile(Pattern.quote(pattern9) + "(.*?)" + Pattern.quote(pattern10));
                            Matcher m5 = p4.matcher(answer);
                            while (m5.find()) {
                                duration = duration + m5.group(1) + ",";
                            }
                            String pattern11 = "recurring_type:";
                            String pattern12 = ":recurring_count";
                            Pattern p5 = Pattern.compile(Pattern.quote(pattern11) + "(.*?)" + Pattern.quote(pattern12));
                            Matcher m6 = p5.matcher(answer);
                            while (m6.find()) {
                                rt = rt + m6.group(1) + ",";
                            }
                            String pattern13 = "recurring_count:";
                            Pattern p6 = Pattern.compile(Pattern.quote(pattern13) + "(.*?)");
                            Matcher m7 = p6.matcher(answer);
                            while (m7.find()) {
                                rc = rc + m7.group(1) + ",";
                            }
                        }

                        if (!displaylist) {
                            //displays the error
                            JOptionPane.showMessageDialog(this, "ERR: Invalid Permission");
                        }
                        else {
                            System.out.println(bname);
                            tmp = bname.split(",");
                            user = creator.split(",");
                            eu = edituser.split(",");
                            st = starttime.split(",");
                            length = duration.split(",");
                            recurrt = rt.split(",");
                            reccurc = rt.split(",");
                            for (int i = 0; i < tmp.length; i++) {
                                model.addRow(new Object[]{tmp[i], user[i],eu[i],st[i],st[i],length[i],recurrt[i],reccurc[i]});
                            }
                        }
                    }
                } catch (UnknownHostException Se) {
                    System.err.println("Unknown host: " + hostName);
                    System.exit(1);
                } catch (ConnectException Se) {
                    System.err.println("Connection refused by host: " + hostName);
                    System.exit(1);
                } catch (IOException Se) {
                    Se.printStackTrace();
                } catch (NullPointerException Se) {
                    System.out.println("NullPointerException thrown!");
                }
                // finally, close the socket and decrement runningThreads
                finally {
                    System.out.println("closing");
                    try {
                        input.close();
                        output.close();
                        socket.close();
                        System.out.flush();
                    } catch (IOException Se) {
                        System.out.println("Couldn't close socket");
                    }
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        //checks if back buttons was clicked
        if (buttonString.equals("Back")) {
            setVisible(false);
            JFrame listBillboard = new ListBillboard();
            listBillboard.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            listBillboard.setBounds(20, 20, 400, 600);
            listBillboard.setVisible(true);
            listBillboard.setTitle("List Billboards");
        }
        //checks if logout button was clicked
        if (buttonString.equals("Logout")) {
            String currentDirectory = System.getProperty("user.dir");
            username = log.getUsername();
            SessionToken = log.getSessionToken();
            Socket s = log.getSocket();
            BufferedReader input = null;
            PrintWriter output = null;
            //contacting the server
            try (InputStream client_properties = new FileInputStream(currentDirectory + "/client.props")) {
                //getting values from props file
                Properties client_props = new Properties();
                // load a properties file
                client_props.load(client_properties);
                // get the port property value
                port = Integer.parseInt(client_props.getProperty("srv.port"));
                hostName = client_props.getProperty("srv.hostname").toString();
                //Sending request to server
                try {
                    s = new Socket(hostName, port);
                    output = new PrintWriter(s.getOutputStream(), true);
                    input = new BufferedReader(new InputStreamReader(s.getInputStream()));
                    SessionToken = log.getSessionToken();
                    output.println(SessionToken);
                    output.println("user:logout");
                    String answer = "";
                    //reading response from server
                    while (((answer = input.readLine()) != null) && (!answer.contains("END_MESSAGE"))) {
                        if (answer.equals("Sucess: Logged Out")) {
                            continues= true;
                        }
                        else if (answer.contains("ERR")){
                            continues = false;
                        }
                    }
                    //reading response from server
                    while (((answer = input.readLine()) != null) && (!answer.contains("END_MESSAGE"))) {
                        if (answer.contains("ERR")){
                            continues = false;
                        }
                        else{
                            continues = true;
                        }
                    }
                    if (!continues) {
                        //displays error
                        if(answer.equals("ERR: Invalid Permission!")){
                            JOptionPane.showMessageDialog(this,"ERR: Invalid Permission!");
                        }
                    } else {
                        //closes connections
                        JOptionPane.showMessageDialog(this, "Logout Succesfutl");
                        s.close();
                        //disposes current screen and goes to login screen
                        dispose();
                        Login login = new Login();
                        login.setBackground(Color.BLACK);
                        login.setForeground(Color.WHITE);
                        login.setBounds(10, 10, 370, 600);
                        login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        login.setVisible(true);
                        login.setTitle("Billboard Control Panel Login");
                    }
                } catch (UnknownHostException Se) {
                    System.err.println("Unknown host: " + hostName);
                    System.exit(1);
                } catch (ConnectException Se) {
                    System.err.println("Connection refused by host: " + hostName);
                    System.exit(1);
                } catch (IOException Se) {
                    Se.printStackTrace();
                } catch (NullPointerException Se) {
                    System.out.println("NullPointerException thrown!");
                }
                // finally, close the socket and decrement runningThreads
                finally {
                    System.out.println("closing");
                    try {
                        input.close();
                        output.close();
                        s.close();
                        System.out.flush();
                    } catch (IOException Se) {
                        System.out.println("Couldn't close socket");
                    }
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
}