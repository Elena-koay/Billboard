Commands all separated by ":" example "command:request:something else"
1. login:username:password
2. token:token_hash_code (To Authenticate)
3. billboard:viewer (No Authentication required)
4. billboard:list (Require Authentication via token)
5. billboard:get (Require Authentication via token)
6. billboard:schedule (Require Authentication via token)
7. billboard:update (Require Authentication via token)
8. billboard:view schedule (Require Authentication via token)
9. billboard:remove schedule (Require Authentication via token)
10. user:delete (Require Authentication via tocken)
11. user:set password (Require Authentication via token)
12. user:set permission (Require Authentication via token)
13. user:create (Require Authentication via token)
14. user:get permission (Require Authentication via token)
15. user:list 	(Require Authentication via token)
16. user:logout (Require Authentication via token)

Test Case use (Used on Putty)
1. telnet localhost 51234 
2. enter -> billboard:viewer #Returns the current billboard content
3. enter -> login:admin:ac9689e2272427085e35b9d3e3e8bed88cb3434828b43b86fc0596cad4c6e270 #Returns -> (token:5036ae408e2192de)
4. enter -> billboard:list #Returns - > (billboard_name:Default Billboard:username:admin:start_time:2020-05-17 19-58-31:duration:0:recurring_type:minute:recurring_count:10)
5. enter -> billboard:get:Default Billboard  #Returns the content of MyBillboard
6. enter -> billboard:schedule:Default Billboard:2020-05-21 21-08-22:25:day:5 
7. enter -> billboard:update:Default Billboard: <?xml version="1.0" encoding="UTF-8"?><billboard background="#0000FF"><message colour="#FFFF00">Welcome to the CAB302 Yeet</message>
 <picture url="https://example.com/fundraiser_image.jpg" /><information colour="#00FFFF">Be sure to check out https://example.com/ for more information.</information></billboard>
#Returns the updated file.
8. enter -> billboard:view schedule 
9. enter -> billboard:remove schedule:Default Billboard:2020-05-21 21-08-22:25:day:5 (
10. enter -> billboard:delete:Default Billboard #deletes said billboard
11. enter -> user:create:User12 #creates user named User12
12. enter -> user:set permission:User12:edit_billboard,edit_schedule #adds those perms to User12
13. enter -> user:logout #logs you out

