package Client;

import Client.PasswordHash;

import java.util.*;
import java.io.*;
import java.util.concurrent.atomic.AtomicLong;
import java.net.Socket;
import java.net.UnknownHostException;
import java.net.ConnectException;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import java.security.NoSuchAlgorithmException;

/**
 * original source: https://github.com/c-lark/Simple-Java-Client-Server/tree/master/client
 * This is a mock client
 * This is the main Client class. This class
 * includes methods for obtaining the user's commands and validating them.
 */
public class Client {
    

    
	private static String hostName;


	public static void main(String[] args) {
	    Socket socket = null;
        BufferedReader input = null;
        PrintWriter output = null;
        
		int menuSelection = 0;
		String command = "command";
        int port = 51234;
        String AdminUser = "admin";
        String AdminPWD = "admin1234";
        String Token = "";
        String[] tmp; 
        String HashedPWD;
        String outputString;
        hostName = "localhost";

        // if no hostname is provided, quit
		/*int argsLength = args.length;
		if (argsLength == 0) { 
			System.out.println("Need a host name. Client program exiting.");
			System.exit(1);
		}else if (!args[0].contains(":") &&  argsLength == 1){
		    
            System.out.println("Need a port. Client program exiting.");
			System.exit(1);
        }*/
		// until the user selects 5, the Exit option, keep looping and
		// offering the menu again after running the queries to the server
		try {
		    

                //Get hostname and port from arguments
                /*if (args[0].contains(":")) {
                tmp = args[0].split(":");
                hostName = tmp[0];
                port = Integer.parseInt(tmp[1]);
                }else{
                    if (argsLength >1){
                    port = Integer.parseInt(args[1]);
                    }
                    hostName = args[0];
                }*/
                //Connect to the server 
                socket = new Socket(hostName, port);
                
                // display the menu and get the user's choice
                while (menuSelection != 5) {
                
                    //Developer's control panel or viwer code, use variable "command" to provide a command to the sever
                    menuSelection = mainMenu();

                    // if 5, exit program
                    if (menuSelection == 5) {
                        System.out.println("Quitting.");
                        System.exit(0);
                    }
                    try {
                    HashedPWD = PasswordHash.getHashPWD(AdminPWD);
                    }catch (NoSuchAlgorithmException e) {
                        throw new AssertionError("Error while hashing a password: " + e.getMessage(), e);
                    }
                    if (menuSelection == 1){
                        command = "login:"+AdminUser+":"+HashedPWD;
                    }
                    
                    if (menuSelection == 2 && Token.length()>0){
                        command = "token:"+Token;
                    }
                    if (menuSelection == 3 && Token.length()>0){
                        command = "billboard:list";
                    }
                    if (menuSelection == 4 && Token.length()>0){
                        command = "billboard:get:Default Billboard";
                    }
                    //End of Developer's code 
                    
                    output = new PrintWriter(socket.getOutputStream(), true);
                    input = new BufferedReader(new InputStreamReader(socket.getInputStream()));                
                    System.out.println("\n{Client} requesting output for the command: '" + command + "'  from " + hostName +":"+port+"\n");
                    output.println(command);
                    
                    while (((outputString = input.readLine()) != null) && (!outputString.equals("END_MESSAGE"))) {
                    
                        System.out.println("{Server} Response:"+outputString);
                        
                        if (outputString.contains("token") && outputString.contains(":")) {
                        tmp = outputString.split(":");
                        Token = tmp[1];
                        }
                    }
                    //Use the outputString for the developers code 
               }
			}
            catch (UnknownHostException e) {
                System.err.println("Unknown host: " + hostName);
                System.exit(1);
            }
            catch (ConnectException e) {
                System.err.println("Connection refused by host: " + hostName);
                System.exit(1);
            }
            catch (IOException e) {
                e.printStackTrace();
            }
            catch(NullPointerException e) {
                System.out.println("NullPointerException thrown!");
            }
            // finally, close the socket and decrement runningThreads
            finally {
                System.out.println("closing");
                try {
                    input.close();
                    output.close();
                    socket.close();
                    System.out.flush();
                }
                catch (IOException e ) {
                    System.out.println("Couldn't close socket");
                }
            }

	}
	//----------------------------------------------------------------------------
	/**
	* Function to prompt the user for a command to run
	* @return command number 1-8
	*/
	public static int mainMenu() {
		int menuSelection = 0;
		// loop (and prompt again) until the user's input is an integer between 1 and 8
		while ((menuSelection <= 0) || (menuSelection > 8)) {
			System.out.println("\nThe menu provides the following choices to the user: ");
			System.out.println("1. Login via user admin and password admin1234 \n2. Send the received token back to the server to authenticate\n"
					+ "3. List all the billboards \n4. Get Billboard content by name example -> \"Default Billboard\" \n5. Quit ");
			System.out.print("Please provide number corresponding to the action you want to be performed: ");
			Scanner sc = new Scanner(System.in);
			if (sc.hasNextInt()) menuSelection = sc.nextInt();
		}
		return menuSelection;
	}
}
