package Tests;

/**
 * Class that mocks a scheduled billboard which is stored in the Mock Database
 * Instances of the scheduled billboard are added to the Mock Database
 */
public class Mock_Schedule extends Mock_DB {

    /**
     * Constructor which creates instance of scheduled billboard with required information
     * @param billboard_id
     * @param start_time
     * @param duration_seconds
     * @param repeats
     */
    public Mock_Schedule(int billboard_id, String start_time, int duration_seconds, int repeats) {
        this.billboard_id = billboard_id;
        this.start_time = start_time;
        this.duration_seconds = duration_seconds;
        this.repeats = repeats;
        id = count++;
    }

    //Declare Variables (Similar to Maria DB Schedule Table)
    private int id;
    private int billboard_id;
    private String start_time;
    private int duration_seconds;
    private int repeats;
    private static int count = 0;

    //Generate Getters and Setters for Variables
    public int getBillboard_id() {
        return billboard_id;
    }

    public String getStart_time() {
        return start_time;
    }

    public int getDuration_seconds() {
        return duration_seconds;
    }

    public void setDuration_seconds(int duration_seconds) {
        this.duration_seconds = duration_seconds;
    }

    public int getRepeats() {
        return repeats;
    }

    public void setRepeats(int repeats) {
        this.repeats = repeats;
    }

    public static int getCount() {
        return count;
    }

    public static void setCount(int count) {
        Mock_Schedule.count = count;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setBillboard_id(int billboard_id) {
        this.billboard_id = billboard_id;
    }

    public void setStart_time(String start_time) {
        this.start_time = start_time;
    }

}
