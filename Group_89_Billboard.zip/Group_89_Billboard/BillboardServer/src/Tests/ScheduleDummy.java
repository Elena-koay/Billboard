package Tests;

import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Map;

/**
 * Class that contains dummy functions related to Scheduling Billboards
 * Functions: Schedule Billboard, View Schedule, Remove Billboard from Schedule
 */
public class ScheduleDummy extends Mock_DB {

    ScheduleDummy(Mock_DB mock) {
        this.clients = mock.clients;
        this.billboards = mock.billboards;
        this.schedule = mock.schedule;
        this.session = new SessionTokenDummy(mock);
        this.store_token_user = mock.store_token_user;
        this.store_token_time = mock.store_token_time;
        this.creator_billboards = mock.creator_billboards;
        this.billboard_id = mock.billboard_id;
    }

    //Variables to be Used in Testing
    boolean edit_billboard = false;
    boolean create_billboard = false;
    boolean edit_users = false;
    boolean edit_schedule = false;

    SessionTokenDummy session;

    //Billboard Helper Functions
    /**Gets billboard id using name of a billboard
     * @param board_name
     * @return int billboard id
     */
    private int get_billboard_id(String board_name) {
        int id = 0;
        for (Mock_Billboard board : billboards) {
            if (board.getName().equals(board_name)) {
                id = board.getId();
            }
        }
        return id;
    }


    /**Gets Billboard's name using the billboard's id
     * @param schedule instances of scheduled billboards
     * @return string with billboard's name
     */
    private String get_billboard_name(Mock_Schedule schedule) {
        //Get Billboard ID to get Billboard Name
        String name_board = "";
        for (Iterator<Map.Entry<String, Integer>> i = billboard_id.entrySet().iterator(); i.hasNext(); ) {
            Map.Entry<String, Integer> entry = i.next();
            if (schedule.getBillboard_id() == entry.getValue()) {
                name_board = entry.getKey();
            }
        }
        return name_board;
    }


    //Billboard Scheduling Functions
    /**Schedules billboard by adding billboard and other information to mock db
     * @param board_name billboard'name
     * @param time time at which the billboard should be showed
     * @param duration time the billboard should show for (seconds int)
     * @param token session token from user
     * @return string that states function's outcome (scheduled or error)
     */
    public String schedule_billboard(String board_name, String time, int duration, String token) {
        //Validate Token && User Permission

        if (!session.validate_token(token)) {
            return "Invalid Token";
        }

        if(!billboard_id.containsKey(board_name)){
            return "Billboard Does not Exist!";
        }

        //Validate Token && User Permission
        if (edit_schedule == true) {
            //Add Billboard to Schedule
            schedule.add(new Mock_Schedule(get_billboard_id(board_name), time, duration, 0));
            //Sort Array to consider new Billboard
            Collections.sort(schedule, Comparator.comparing(Mock_Schedule::getStart_time));
            return "Billboard Scheduled!";
        } else
            {
            return "Billboard not Scheduled! Invalid Permission";
        }
    }

    /**Function that removes a billboard from the schedule in the db
     * @param name billboard's name
     * @param time time which the billboard is scheduled for
     * @param token session token from user
     * @return string that states function's outcome (removed or error)
     */
    public String remove_billboard(String name, String time, String token) {

        if (!session.validate_token(token)) {
            return "Invalid Token!";
        }

        if (session.validate_token(token) && edit_schedule == true) {
            //Get Particular User from BD
            for (Mock_Schedule board : schedule) {
                if (get_billboard_name(board).equals(name) && board.getStart_time().equals(time)) {
                    schedule.remove(board);
                    return "Billboard Removed from schedule";
                }
            }
        } else {
            return "Invalid Permission!";
        }
        return "Something Happened!";
    }

    /**Sends a string containing information of billboards to be displayed
     * @param token session token from user
     * @return string of billboard information or error message
     */
    public String view_schedule(String token) {
        //Name, Creator, Time, and Duration
        if(!session.validate_token(token)){
            return "Invalid Token!";
        }

        String temp = "";
        if(edit_schedule == true){
            for (Mock_Schedule scheduled : schedule) {
                //Billboard Name
                String bill_name = get_billboard_name(scheduled);
                String creator_name = creator_billboards.get(bill_name);
                String time = scheduled.getStart_time();
                temp += "Scheduled: " + bill_name + "\t" + "Creator: " + creator_name + "\t" + "Time:" + time + "\t" + "Duration: " + scheduled.getDuration_seconds() + " seconds" + "\n";
            }
        }
        else {
            return "Invalid Permission!";
        }
        return temp;
    }
}
