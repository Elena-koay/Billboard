package Tests;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Class that mocks a Database which is stores information
 * Stores instances of objects in Array List and Hash Maps
 */
public class Mock_DB {

    //Store user, billboard and schedule details
    ArrayList<Mock_User> clients;
    ArrayList<Mock_Billboard> billboards;
    ArrayList<Mock_Schedule> schedule;

    //Map to Store Creator's Name and Billboards (for easier testing purposes they are stored together - DB stored separately)
    public HashMap<String, String> creator_billboards;
    public HashMap<String, Integer> billboard_id;

    //Store Session Token Information User's session token
    public HashMap<String, String> store_token_user; //Store User and respective token
    public HashMap<String, Long> store_token_time; //Store Token and Time

    public Mock_DB() {
        store_token_time = new HashMap<String, Long>();
        store_token_user = new HashMap<String, String>();
        clients = new ArrayList<Mock_User>();
        billboards = new ArrayList<Mock_Billboard>();
        schedule = new ArrayList<Mock_Schedule>();
        creator_billboards = new HashMap<String, String>();
        billboard_id = new HashMap<String, Integer>();
    }
}
