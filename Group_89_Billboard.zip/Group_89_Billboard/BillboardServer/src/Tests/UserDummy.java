package Tests;

import java.util.Iterator;
import java.util.Map;

/**
 *Class that contains functions related to User's
 * Functions: Create User, Delete User, List Users, Get User Permissions, Set Password, Set Permissions, login and logout
 */
public class UserDummy extends Mock_DB{

    UserDummy(Mock_DB mock){
        this.clients = mock.clients;
        this.billboards = mock.billboards;
        this.schedule = mock.schedule;
        this.creator_billboards = mock.creator_billboards;
        this.billboard_id = mock.billboard_id;
        this.store_token_user = mock.store_token_user;
        this.store_token_time = mock.store_token_time;
        this.session = new SessionTokenDummy(mock);
    }

    SessionTokenDummy session;

    //Variables to be Used in Testing
    boolean edit_users = false;
    boolean edit_billboard = false;
    boolean create_billboard = false;
    boolean edit_schedule = false;
    String user;

    /**user logs out and session token is removed from db
     * @param token sessoin token from user
     * @return string with function outcome (logged out or error message)
     */
    public String logout(String token) {
        //Validate Session Token
        if (session.validate_token(token)) {
            //Delete Session Token from
            store_token_time.remove(token);

            //Delete Token from User Map
            for (Iterator<Map.Entry<String, String>> iterate = store_token_user.entrySet().iterator(); iterate.hasNext(); ) {
                Map.Entry<String, String> user_entry = iterate.next();
                if (user_entry.getValue() == token)
                    iterate.remove();
            }
            return "Log out successful!";
        } else {
            return "Log out unsuccessful! Token invalid!";
        }
    }

    /**Delete user from db
     * @param username user name of user that is logged in
     * @param token session token from user
     * @return string with function outcome (deleted or error message)
     */
    public String delete_user(String username, String token) {
        //Validate Token && Permissions

        if(!session.validate_token(token)){
            return "Invalid Session Token";
        }

        if(username.equals(user)){
            return "Cannot Delete yourself!";
        }

        if (edit_users == true) {
            //Get Particular User from BD
            for (Mock_User person : clients) {
                if (person.getUser_name().equals(username)) {
                    clients.remove(person);
                    return "User Removed!";
                }
            }
        }
        else { return "Incorrect Permissions!";}
        return "User does not Exist!";
    }

    /**Updates password of user by changing user's stored password to new password they send
     * @param username user name of user that is logged in
     * @param password new password which the user wants to put in db
     * @return string with function outcome (changed or error message)
     */
    public String set_user_password(String username, String password) {
        //Get Particular User from BD
        if ((edit_users == true) || (username == user)) {
            for (Mock_User person : clients) {
                if (person.getUser_name().equals(username)) {
                    person.setPassword(password);
                    return "Password changed successfully!";
                }
                else {return "User does not exist!";}
            }
        }
        return "Invalid Permission!";
    }

    /**Changes a user's permissions to the permissions specified in the sent list
     * @param username user name of user that is logged in
     * @param permissions list of permission the user wants
     * @param token session token from user
     * @return string with function outcome (changed successfully or error message)
     */
    public String set_user_permissions(String username, Boolean[] permissions, String token) {

        if (!session.validate_token(token)){
            return "Invalid Token";
        }

        if (((edit_users) && (permissions[3] == false)) && (username == user)){
            return "Cannot remove own 'Edit User' Permission!";
        }
        else {
            if (session.validate_token(token) && edit_users == true) {
                for (Mock_User person : clients) {
                    if (person.getUser_name().equals(username)) {
                        person.setCreate_billboard(permissions[0]);
                        person.setEdit_billboards(permissions[1]);
                        person.setEdit_schedule(permissions[2]);
                        person.setEdit_users(permissions[3]);
                        return "Permissions changed successfully!";
                    }
                    else {return "User does not Exist!";}
                }
            }
        }
        return "Invalid Permission";
    }

    /**Creates a user to be added to the db
     * @param name username that a user wants to use to create a user
     * @param permissions list of permissions of the user which are stored in db
     * @param password password of the newly created user
     * @param token session token from current user logged in
     * @return string with function outcome (created or error message)
     */
    public String create_user(String name, boolean[] permissions, String password, String token) {
        if (edit_users == false){
            return "Invalid Permission";
        }
        //Validate Token && User Permission
        if (session.validate_token(token) && edit_users == true) {
            //Create and Add New User
            clients.add(new Mock_User(name, password, permissions));
            return "User Created!";
        } else {
            return "User not Created! Invalid Token";
        }
    }

    /**Lists user permissions of the user specified
     * @param username username that the current user seeks permissions of
     * @param token session token from current user logged in
     * @return string with listed permissions or error message
     */
    public String list_user_permission(String username, String token) {
        String temp = "Hellooooo";
        String list_permissions = "";
        //Validate Date Token Check Permissions
        if (!session.validate_token(token)) {
            return "Invalid Token";
        }

        if (!username.equals(user) && edit_users == false) {
            return "You do not have permission to view!";
        }

        if ((username == user) | (edit_users == true)) {
            for (Mock_User person : clients) {
                if (person.getUser_name().equals(username)) {
                    //Build String
                    list_permissions += "Users: " + person.getUser_name() + "\t Create Billboard: " + person.getCreate_billboard() + "\t Edit Billboard: " + person.getEdit_billboards() + "\t Edit Schedule: " + person.getEdit_schedule() + "\t Edit Users: " + person.getEdit_users() + "\n";
                }
            }
            if (list_permissions.equals("")) {
                return "User Does not Exist!";
            }
        }
        return list_permissions;
    }

    /**List all the current users
     * @param token session token from current user logged in
     * @return string with listed users or error message
     */
    public String list_users(String token) {
        String temp = "";
        int count = 0;

        if(!session.validate_token(token)){
            return "Invalid Token!";
        }

        //Validate
        if (session.validate_token(token) && edit_users == true) {
            for (Mock_User person : clients) {
                count++;
                temp += person.getUser_name() + "\n";

            }
            return temp + "Number of Users: " + count;
        } else {
            //There is an Error - Report Error
            return "Invalid Permission!";
        }
    }
}
