package Tests;

/**
 * Class that mocks a Billboard which is stored in the Mock Database
 * Instances of the billboard are added to the Mock Database
 */
public class Mock_Billboard {

    //Declare Variables
    private static int count = 0;
    private int id;
    private String name;
    private String content;
    private boolean scheduled;
    private int user_id;

    /**
     * Constructor which creates a mock billboard with required information
     * @param user_id
     * @param name
     * @param content
     */
    public Mock_Billboard(int user_id, String name, String content) {
        this.user_id = user_id;
        this.name = name;
        this.content = content;
        id = count++;
    }

    //Function that Resets count for Testing (required as new instances are repeatedly created for tests)
    public static int reset (){
        int temp = count;
        count=0;
        return temp;
    }

    //Generate Getters and Setters for Variables
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public static int getCount() {
        return count;
    }

    public static void setCount(int count) {
        Mock_Billboard.count = count;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public boolean isScheduled() {
        return scheduled;
    }

    public void setScheduled(boolean scheduled) {
        this.scheduled = scheduled;
    }
}
