package Tests;

/**
 * Class that contains dummy functions related to billboards
 * Functions: Create Billboard, Edit Billboard, Delete Billboard, List Billboards, Get Billboard Information
 */
public class BillboardDummy extends Mock_DB{

    BillboardDummy(Mock_DB mock){
        this.clients = mock.clients;
        this.billboards = mock.billboards;
        this.schedule = mock.schedule;
        this.store_token_user = mock.store_token_user;
        this.store_token_time = mock.store_token_time;
        this.creator_billboards = mock.creator_billboards;
        this.billboard_id = mock.billboard_id;
    }

    /**Function for creating and storing billboard in database
     * @param user_id user's id for checking permissions
     * @param board_name billboards name
     * @param contents context of the billboard (xml)
     * @param token session token from user
     * @return string with outcome of function (created or error)
     */
    public String create_billboard(int user_id, String board_name, String contents, String token){
        //Validate Token and Permission
        Mock_Billboard board = new Mock_Billboard(user_id, board_name, contents);

        //Store User that Created Board
        String name = "";
        //Iterate Over Users
        for (Mock_User person : clients){
            if (user_id == person.getId_num()){
                name = person.getUser_name();
                break;
            }
        }

        creator_billboards.put(board_name, name);
        billboard_id.put(board_name, board.getId());
        billboards.add(board);
        return "Billboard Created!";
    }
}
