package Tests;

import Server.SessionToken;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TestScheduleDummy {
    //Create Mock DB and Users Dummy instances
    private Mock_DB mock_db;
    private SessionTokenDummy tokenDummy;
    private ScheduleDummy scheduleDummy;
    private BillboardDummy billBoardDummy;
    private UserDummy userDummy;
    private String token;

    @BeforeEach
    public void setup() {
        mock_db = new Mock_DB();
        tokenDummy = new SessionTokenDummy(mock_db);
        scheduleDummy = new ScheduleDummy(mock_db);
        billBoardDummy = new BillboardDummy(mock_db);
        userDummy = new UserDummy(mock_db);

        //Generate Fake Token for Testing
        tokenDummy.generate_token("user1");
        this.token = mock_db.store_token_user.get("user1");

        //Set Permissions
        scheduleDummy.edit_schedule = true;
        scheduleDummy.edit_users = true;
        userDummy.edit_users = true;

        //Create some Users
        //Create Users
        userDummy.create_user("user1", new boolean[]{true,true,true,true}, "password1", token);
        userDummy.create_user("user2", new boolean[]{true,true,true,true}, "password1", token);
        userDummy.create_user("user3", new boolean[]{true,true,true,true}, "password1", token);

        //Create some Billboards to Schedule
        billBoardDummy.create_billboard(0, "Cole's Ad", "image", token);
        billBoardDummy.create_billboard(1, "Cup Ad", "image", token);
        billBoardDummy.create_billboard(2, "Cat Ad", "image", token);


        //Schedule Fake Billboards
        scheduleDummy.schedule_billboard("Cole's Ad", "14:00", 3600, token);
        scheduleDummy.schedule_billboard("Cup Ad", "15:00", 3600, token);
    }


    @AfterEach
    public void reset(){
        mock_db = null;
        tokenDummy = null;
        scheduleDummy = null;
        billBoardDummy =  null;
        userDummy = null;
        this.token = "";

        //Reset Count for ID numbers in Billboard and User
        Mock_Billboard.reset();
        Mock_User.reset();
    }

    /*********Test Driven Development*************/

    /*Test 0: user schedules billboard
     * Expected Result: billboard is added to schedule table
     * Result: billboard is schedules correctly in mock db*/
    @Test
    public void schedule_billboard() {
        assertEquals("Billboard Scheduled!", scheduleDummy.schedule_billboard("Cole's Ad", "14:00", 3600, token), "Billboard Not scheduled!");
    }

    /*Test 1: user schedules billboard with invalid token
     * Expected Result: server detects invalid token, billboard not scheduled
     * Result: return error string*/
    @Test
    public void schedule_billboard_invalid_token() {
        assertEquals("Invalid Token", scheduleDummy.schedule_billboard( "Cole's Ad", "14:00", 3600, "abc"), "Billboard scheduled using invalid token!");
    }

    /*Test 2: user schedules billboard with permission
     * Expected Result: server checks permission and schedules billboard
     * Result: billboard scheduled*/
    @Test
    public void schedule_billboard_permission() {
        assertEquals("Billboard Scheduled!", scheduleDummy.schedule_billboard( "Cole's Ad", "14:00", 3600, token), "Billboard scheduled using invalid permission!");
    }

    /*Test 3: user cannot schedule billboard without permission
     * Expected Result: server checks permission and does not schedule billboard
     * Result: Return error string*/
    @Test
    public void schedule_billboard_no_permission() {
        scheduleDummy.edit_schedule = false;
        assertEquals("Billboard not Scheduled! Invalid Permission", scheduleDummy.schedule_billboard( "Cole's Ad", "14:00", 3600, token), "Billboard scheduled using invalid permission!");
    }

    /*Test 4: user removes billboard
     * Expected Result: user removes billboard
     * Result: billboard removed from database*/
    @Test
    public void remove_billboard() {
        assertEquals("Billboard Removed from schedule", scheduleDummy.remove_billboard("Cole's Ad", "14:00", token), "Billboard not removed even tho requested!");
    }

    /*Test 5: user tries to removes billboard with invalid token
     * Expected Result: user cannot remove billboard with expired token
     * Result: error string message returned*/
    @Test
    public void remove_billboard_invalid_token() {
        assertEquals("Invalid Token!", scheduleDummy.remove_billboard( "Cole's Ad", "14:00", "abc"), "Billboard removed even tho Token Invalid!");
    }

    /*Test 6: user tries to removes billboard with invalid permission
     * Expected Result: user cannot remove billboard as does not have permission
     * Result: error string message returned*/
    @Test
    public void remove_billboard_invalid_permission() {
        scheduleDummy.edit_schedule = false;

        //Schedule Fake Billboards
        scheduleDummy.schedule_billboard("Cole's Ad", "14:00", 3600, token);
        scheduleDummy.schedule_billboard("Cup Ad", "15:00", 3600, token);
        assertEquals("Invalid Permission!", scheduleDummy.remove_billboard( "Cole's Ad", "14:00", token), "Billboard removed even tho Permission Invalid!");
    }

    /*Test 7: user removes billboard with valid permission
     * Expected Result: user removes billboard as has permission
     * Result: billboard removed from database*/
    @Test
    public void remove_billboard_valid_permission() {
        assertEquals("Billboard Removed from schedule", scheduleDummy.remove_billboard( "Cole's Ad", "14:00", token), "Billboard not removed even tho Permission Valid!");
    }

    /*Test 8: user able to list billboards
     * Expected Result: server sends scheduled billboards to user
     * Result: returns list of scheduled billboards to user*/
    @Test
    public void view_schedule() {
        //Remove One Scheduled Billboard (less to assert)
        scheduleDummy.remove_billboard("Cup Ad", "15:00", token);
        assertEquals("Scheduled: Cole's Ad\tCreator: user1\tTime:14:00\tDuration: 3600 seconds\n", scheduleDummy.view_schedule(token), "Schedule not shown!");
    }

    /*Test 9: user cannot view schedule as token invalid
     * Expected Result: server does not send schedule
     * Result: returns error string*/
    @Test
    public void view_billboard_schedule_invalid_token() {
        assertEquals("Invalid Token!", scheduleDummy.view_schedule("abc"), "Schedule shown when token invalid!");
    }

    /*Test 10: user cannot view schedule as does not have permission
     * Expected Result: server does not send schedule
     * Result: returns error string*/
    @Test
    public void view_billboard_schedule_invalid_permission() {
        scheduleDummy.edit_schedule = false; //Permission to False
        assertEquals("Invalid Permission!", scheduleDummy.view_schedule(token), "Schedule shown when permission wrong!");
    }


    /*Test 11: user cannot schedule billboard that does not exist
     * Expected Result: server does not schedule billboard
     * Result: returns error string*/
    @Test
    public void cannot_schedule_non_existent_billboard() {
        assertEquals("Billboard Does not Exist!", scheduleDummy.schedule_billboard("Dog Ad", "13:00", 3600, token), "Schedule shown when permission wrong!");
    }

    /*Test 12: schedule rearranges when user scheduled billboard
     * Expected Result: server sends re-arranged schedule
     * Result: returns re-arranged schedule*/
    @Test
    public void view_schedule_rearrange() {
        //Add New Billboard to Schedule at 14:30 (Time that sits between pre-scheduled billboards)
        scheduleDummy.schedule_billboard("Cat Ad", "14:30", 3600, token);

        assertEquals("Scheduled: Cole's Ad\tCreator: user1\tTime:14:00\tDuration: 3600 seconds\n" +
                "Scheduled: Cat Ad\tCreator: user3\tTime:14:30\tDuration: 3600 seconds\n" +
                "Scheduled: Cup Ad\tCreator: user2\tTime:15:00\tDuration: 3600 seconds\n", scheduleDummy.view_schedule(token), "Schedule not re-arranged!");
    }
}
