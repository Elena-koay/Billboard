package Tests;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class TestSessionToken {

    //Constructor Declaration
    Mock_DB mock_db;
    SessionTokenDummy tokenDummy;

    @BeforeEach
    public void setup_db(){
        mock_db = new Mock_DB();
        tokenDummy = new SessionTokenDummy(mock_db);
    }

    /*Test 0: Create Session Token for User
     * Expected Result: Session Token created for user
     * Result: Session Token created for user*/
    @Test
    public void create_token(){
        //Create Token for User
        tokenDummy.generate_token("User1");
        String token = mock_db.store_token_user.get("User1");
        assertEquals(mock_db.store_token_user.get("User1"),token, "Failed to create session token!");
    }

    /* Test 1: Token's creation time (current time of executing function) is stored in Map (Token and Time)
     *Expected Result: token is created the the current time is store with it
     * Result: current time and token stored*/
    @Test
    public void store_token_creation_time(){
        tokenDummy.generate_token("User1");
        String token = mock_db.store_token_user.get("User1");
        assertEquals(System.currentTimeMillis(),mock_db.store_token_time.get(token), "Failed to get creation time of session token!");
    }

    /* Test 2: Token not created if username not provided
     * Expected: if empty string username provided a form of error handling is provided
     * Result: null username causes a form of error handling to occur */
    @Test
    public void null_username(){
        assertEquals("",tokenDummy.generate_token(""), "Failed to create session token! - Empty Username Provided");
    }

    /*Test 3: After 24 Hours tokens and there user are removed from DB
     * Expected: after 24 hours tokens are removed from DB
     * Result: tokens are removed from DB after 24 hours*/
    @Test
    public void remove_expired_tokens_user_storage(){
        //Generate Token
        tokenDummy.generate_token("User2");

        //HardCode Change time to 24 hours later
        String token_key = mock_db.store_token_user.get("User2");
        long new_Time = (System.currentTimeMillis() - (24 * 60 * 60 * 1000)); //Add 24 hours in milliseconds
        mock_db.store_token_time.replace(token_key, new_Time);

        //Run Function to check Expiry
        tokenDummy.token_expiry(mock_db.store_token_time, mock_db.store_token_user);

        //Check the Hash Maps do not contain expired session token and related information
        assertFalse(mock_db.store_token_user.containsKey("User2"), "Expired Token not removed!");
    }

    /*Test 4: After 24 Hours tokens and there time are removed from DB
     * Expected: after 24 hours tokens are removed from DB
     * Result: tokens are removed from DB after 24 hours*/
    @Test
    public void remove_expired_tokens_time_storage(){
        //Generate Token
        tokenDummy.generate_token("User2");

        //HardCode Change time to 24 hours later
        String token_key = mock_db.store_token_user.get("User2");
        long new_Time = (System.currentTimeMillis() - (24 * 60 * 60 * 1000)); //Add 24 hours in milliseconds
        mock_db.store_token_time.replace(token_key, new_Time);

        //Run Function to check Expiry
        tokenDummy.token_expiry(mock_db.store_token_time, mock_db.store_token_user);

        //Check the Hash Maps do not contain expired session token and related information
        assertFalse(mock_db.store_token_time.containsKey(token_key), "Expired Token not removed!");
    }


    /*Test 5: Receives valid session token from user
     * Expected: checks received token against token DB, token is in DB
     * Result: valid token as received token is in DB, returns true or acknowledgment*/
    @Test
    public void valid_token(){
        //Create some token data
        tokenDummy.generate_token("User5");
        tokenDummy.generate_token("User6");

        //Get token key
        String token_key = mock_db.store_token_user.get("User5");
        assertTrue(tokenDummy.validate_token(token_key), "Token stored in DB is invalid!");
    }

    /*Test 6: Receives in-valid session token from user
     * Expected: checks received token against token DB, token is not in DB
     * Result: in-valid token as received token is in DB, returns error handling form*/
    @Test
    public void invalid_token(){
        //Create some token data
        tokenDummy.generate_token("User5");
        tokenDummy.generate_token("User6");

        assertFalse(tokenDummy.validate_token("fakeToken1234"), "Token not stored in DB is valid!");
    }
}
