package Tests;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.awt.desktop.SystemSleepEvent;

import static org.junit.jupiter.api.Assertions.*;

public class TestUserDummy {
    //Create Mock DB and Users Dummy instances
    Mock_DB mock_db;
    UserDummy usersDummy;
    SessionTokenDummy tokenDummy;
    String token;

    @BeforeEach
    public void setup() {
        mock_db = new Mock_DB();
        usersDummy = new UserDummy(mock_db);
        tokenDummy = new SessionTokenDummy(mock_db);

        //Create Fake Session Token to be Used for Testing
        tokenDummy.generate_token("user1");
        this.token = mock_db.store_token_user.get("user1");

        //Set Permission of Fake User (change in test if require false)
        usersDummy.edit_users = true;
        //Create Fake User(s)
        usersDummy.create_user("user1", new boolean[]{true, true, true, true}, "password", token);
        usersDummy.create_user("user2", new boolean[]{false, false, false, false}, "password", token);
    }

    /*********Test Driven Development*************/

    /*Test 0: User Logs out Successfully
     * Expected Result: valid session token received & server removes session token
     * Result: token received and token deleted from DB*/
    @Test
    public void logout() {
        assertEquals("Log out successful!", usersDummy.logout(token), "Log out Failed! Token invalid");
    }

    /*Test 1: User Logs out unsuccessfully as token invalid
     * Expected Result: invalid token received  user cannot log out
     * Result: return error string*/
    @Test
    public void logout_invalid_token() {
        assertEquals("Log out unsuccessful! Token invalid!", usersDummy.logout("acb"), "Log out Failed! Token invalid");
    }

    /*Test 2: receives username and token & deletes user
     * Expected Result: valid username and token received & server removes user
     * Result: user and other items (i.e. Billboards) relating to user successfully deleted*/
    @Test
    public void delete_user() {
        //Delete User
        usersDummy.delete_user("user1", token);
        //Assert True User does not Exist in DB anymore
        assertEquals("user2" + "\n" + "Number of Users: 1",usersDummy.list_users(token), "User not Deleted!");
    }

    /*Test 3: user cannot delete their self
     * Expected Result: user cannot delete themselves, returns string message
     * Result: user unable to delete themselves*/
    @Test
    public void cannot_delete_self(){
        //Mock User that is currently logged in
        usersDummy.user = "user1";
        assertEquals("Cannot Delete yourself!",usersDummy.delete_user("user1", token), "User Deleted themselves!");
    }

    /*Test 4: user cannot delete user that does not exist
     * Expected Result: user cannot user that is not in DB
     * Result: return error string*/
    @Test
    public void cannot_delete_non_existing_user(){
        assertEquals("User does not Exist!" ,usersDummy.delete_user("user3", token), "User Deleted Non-Existing User!");
    }


    /*Test 5: user cannot delete user with invalid permission
     * Expected Result: user cannot user as permission false
     * Result: return error string*/
    @Test
    public void cannot_delete_user_with_wrong_permission(){
        usersDummy.edit_users = false;
        assertEquals("Incorrect Permissions!" ,usersDummy.delete_user("user1", token), "User Deleted user without permission!");
    }

    /*Test 6: user cannot delete user with invalid token
     * Expected Result: user cannot user as token invalid
     * Result: return error string*/
    @Test
    public void cannot_delete_user_with_invalid_token(){
        usersDummy.edit_users = false;
        assertEquals("Invalid Session Token" ,usersDummy.delete_user("user1", "abc"), "User Deleted user without permission!");
    }


    /*Test 7: receives username and password & server changes user's password
     * Expected Result: valid username received & server changes password user
     * Result: user's password successfully changed*/
    @Test
    public void set_user_password() {
        assertEquals("Password changed successfully!", usersDummy.set_user_password("user1", "password12"), "Password not set! Does User exist?");
    }

    /*Test 8: user does not need permissions to set own password
     * Expected Result: permissions not checked if user setting own password
     * Result: user's password changed successfully, despite permissions*/
    @Test
    public void set_own_password(){
        //Set User that is currently Logged in
        usersDummy.user = "user1";
        usersDummy.edit_users = false; //Set Permission to False
        assertEquals("Password changed successfully!", usersDummy.set_user_password("user1", "password12"), "Password not set! Does User exist?");
    }


    /*Test 9: user cannot set password for non-existent user
     * Expected Result: user unable to set password for user that is not in DB
     * Result: error string returned*/
    @Test
    public void cannot_set_non_existent_user_password(){
        assertEquals("User does not exist!", usersDummy.set_user_password("user4", "password12"), "Password set for Non-existent User!");
    }

    /*Test 10: user cannot set password without correct permission
     * Expected Result: user unable to set password
     * Result: error string returned*/
    @Test
    public void cannot_set_password_without_permission(){
        usersDummy.edit_users = false;
        assertEquals("Invalid Permission!", usersDummy.set_user_password("user1", "password12"), "Password set without Permission!");
    }



    /*Test 11: receives username, list of permissions and token & server changes permissions to match list
     * Expected Result: valid information received and server changes permissions
     * Result: user's permission's successfully changed*/
    @Test
    public void set_user_permissions() {
        usersDummy.set_user_permissions("user1", new Boolean[]{false, true, false, true}, token);
        assertEquals("Users: user1\t Create Billboard: false\t Edit Billboard: true\t Edit Schedule: false\t Edit Users: true\n", usersDummy.list_user_permission("user1", token), "Permissions not set! Does User exist?");
    }

    /*Test 12: user cannot set permission without permission
     * Expected Result: user unable to change permissions
     * Result: return error string*/
    @Test
    public void user_cannot_change_permission_with_no_permission(){
        //Mock User that is currently logged in
        usersDummy.user = "user1";
        usersDummy.edit_users = false; //Set Permission to False
        assertEquals("Invalid Permission", usersDummy.set_user_permissions("user1", new Boolean[]{true, false, true, false}, token), "User removed owN 'Edit Permission'");
    }


    /*Test 13: user cannot set permission without invalid token
     * Expected Result: user unable to change permissions
     * Result: return error string*/
    @Test
    public void user_cannot_change_permission_with_invalid_token(){
        //Mock User that is currently logged in
        usersDummy.user = "user1";
        assertEquals("Invalid Token", usersDummy.set_user_permissions("user1", new Boolean[]{true, false, true, false}, "acb"), "User removed owN 'Edit Permission'");
    }

    /*Test 14: user cannot set permissions for user that does not exist
     * Expected Result: user's unable to set permission
     * Result: return error string*/
    @Test
    public void cannot_set_permission_non_user(){
        assertEquals("User does not Exist!", usersDummy.set_user_permissions("user6", new Boolean[]{false, false, false, false}, token), "Permission set for non-existent User");
    }

    /*Test 15: user cannot remove permissions for "Edit Permissions"
     * Expected Result: user's edit permissions unable to be removed
     * Result: permissions unable to be removed, sends return string*/
    @Test
    public void user_cannot_remove_own_edit_permission(){
        //Mock User that is currently logged in
        usersDummy.user = "user1";
        assertEquals("Cannot remove own 'Edit User' Permission!", usersDummy.set_user_permissions("user1", new Boolean[]{false, false, false, false}, token), "User removed owN 'Edit Permission'");
    }


    /*Test 16: receives username and token & server responds with permission list
     * Expected Result: valid username and token received and server sends user's permission list
     * Result: user's permission's successfully sent*/
    @Test
    public void get_user_permission() {
        //usersDummy.edit_users = true;
        //assertNotEquals("Unable to Get Permissions! Incorrect Permissions or Expired Token", usersDummy.list_user_permission("user1", token), "Cannot list permissions! Does user exist?");
        assertEquals("Users: user1\t Create Billboard: true\t Edit Billboard: true\t Edit Schedule: true\t Edit Users: true\n", usersDummy.list_user_permission("user1", token), "Cannot list permission!");
    }

    /*Test 17: user does not require permission to view their own permissions
     * Expected Result: permissions shown
     * Result: permissions changed successfully despite permissions*/
    @Test
    public void get_own_permissions(){
        //Set Permission and User
        usersDummy.user = "user1"; //Mock User that is currently Logged In
        usersDummy.edit_users = false; //Has False Permission
        assertEquals("Users: user1\t Create Billboard: true\t Edit Billboard: true\t Edit Schedule: true\t Edit Users: true\n", usersDummy.list_user_permission("user1", token), "Cannot list permissions! Does user exist?");
    }

    /*Test 18: user cannot get permissions as token invalid
     * Expected Result: permissions not shown and error message
     * Result: return error message*/
    @Test
    public void get_permissions_invalid_token(){
        assertEquals( "Invalid Token", usersDummy.list_user_permission("user1", "abc"), "Cannot list permissions! Does user exist?");
    }


    /*Test 19: receives token & server responds with user's list and details
     * Expected Result: valid token received and server sends user's details
     * Result: all user's details successfully sent*/
    @Test
    public void list_users() {
        assertEquals("user1" + "\n" + "user2" + "\n" + "Number of Users: 2", usersDummy.list_users(token), "Cannot list users! DB Connection ok?");
    }

    /*Test 20: receives invalid token
     * Expected Result: invalid token received and server does not sent user list
     * Result: returns error message*/
    @Test
    public void list_users_invalid_token() {
        assertEquals("Invalid Token!", usersDummy.list_users("abc"), "User list is shown with Invalid Token!");
    }

    /*Test 21: user does not have permission to view
     * Expected Result: list not shown
     * Result: returns error message*/
    @Test
    public void no_list_users_wrong_permission() {
        //Create User that is Logged in & Set Permission to False
        usersDummy.user = "user17";
        usersDummy.edit_users = false;
        assertEquals("Invalid Permission!", usersDummy.list_users(token), "User list is shown with Invalid Permission!");
    }


    /*Test 22: receives username, permission list, hash password, token & server creates user
     * Expected Result: valid user created using information
     * Result: user created and stored in DB with information*/
    @Test
    public void create_user() {
        usersDummy.edit_users = true;
        assertEquals("User Created!", usersDummy.create_user("user3", new boolean[]{true, false, true, false}, "password1", token), "Cannot list users! DB Connection ok? Or Invalid Permission");
    }

    /*Test 23: receives invalid token
     * Expected Result: invalid token therefore user not created
     * Result: return error string*/
    @Test
    public void no_create_user_invalid_token() {
        usersDummy.edit_users = true;
        assertEquals("User not Created! Invalid Token", usersDummy.create_user("user3", new boolean[]{true, false, true, false}, "password1", "acb"), "Users are listed despite invalid token");
    }
}

