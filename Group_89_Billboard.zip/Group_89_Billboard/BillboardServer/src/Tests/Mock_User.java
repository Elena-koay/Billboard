package Tests;

/**
 * Class that mocks a user which is stored in the Mock Database
 * Instances of the user are added to the Mock Database
 */
public class Mock_User {


    private static int count = 0;
    //Declare Variables (Similar to Maria DB User Table)
    private String user_name;
    private String password;
    private boolean create_billboard;
    private boolean edit_billboards;
    private boolean edit_schedule;
    private boolean edit_users;
    private int id_num = 0;


    public Mock_User(String user_name, String password, boolean[] permissions) {
        this.user_name = user_name;
        this.password = password;
        this.create_billboard = permissions[0];
        this.edit_billboards = permissions[1];
        this.edit_schedule = permissions[2];
        this.edit_users = permissions[3];
        id_num = count++;
    }

    //Function that resets id count for testing (required as new instances are repeatly generated during test)
    public static int reset (){
        int temp = count;
        count=0;
        return temp;
    }

    //Generate Getters and Setters
    public String getUser_name() {
        return user_name;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean getCreate_billboard() {
        return create_billboard;
    }

    public void setCreate_billboard(boolean create_billboard) {
        this.create_billboard = create_billboard;
    }

    public boolean getEdit_billboards() {
        return edit_billboards;
    }

    public void setEdit_billboards(boolean edit_billboards) {
        this.edit_billboards = edit_billboards;
    }

    public boolean getEdit_schedule() {
        return edit_schedule;
    }

    public void setEdit_schedule(boolean edit_schedule) {
        this.edit_schedule = edit_schedule;
    }

    public boolean getEdit_users() {
        return edit_users;
    }

    public void setEdit_users(boolean edit_users) {
        this.edit_users = edit_users;
    }

    public int getId_num() {
        return id_num;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getPassword() {
        return password;
    }
}
