package Tests;

import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Class that contains functions related to session token handling
 * Functions: Validating Tokens, Checking for Expired Tokens, Generating Tokens
 */
public class SessionTokenDummy extends Mock_DB{

    //Used to create random string to be used as token
    protected static SecureRandom randomToken = new SecureRandom();

    SessionTokenDummy(Mock_DB mock){
        this.clients = mock.clients;
        this.billboards = mock.billboards;
        this.schedule = mock.schedule;
        this.creator_billboards = mock.creator_billboards;
        this.store_token_user = mock.store_token_user;
        this.store_token_time = mock.store_token_time;
    }


    /**Generates a random string to be used as session token
     * @return session token in the form of a random string
     */
    private String generate_random_string() {
        long longToken = Math.abs(randomToken.nextLong());
        String token = Long.toString(longToken, 16);
        return token;
    }

    /**Gets random string and stores it in db with time and user information
     * @param UserName user name of user that is logged in
     * @return Session Token which the user uses to perform other actions
     */
    public String generate_token(String UserName) {
        if (UserName != "") {
            String token = generate_random_string();

            //Check for duplicate Tokens
            if (!store_token_time.containsKey(token)) {
                //Get Current Time
                long nowMillis = System.currentTimeMillis();

                //Store Token information (Creation time and UserName)
                store_token_time.put(token, nowMillis);

                //Store Session Token for User
                store_token_user.put(UserName, token);

                //Return Random String to Control Panel
                return token;
            }
        }
        else {
            //Return an Empty String
            //If Control Panel received Empty String perform some error handling
        }
        return "";
    }

    /**Check's whether the token is valid by seeing if the db has the session token
     * @param token session token from the user
     * @return boolean (true or false) regarding the session token's validness
     */
    public boolean validate_token(String token){
        if (store_token_time.containsKey(token)){
            //Token is valid
            return true;
        }
        else {
            //Token not in DB, therefore Invalid
            return false;
        }
    }

    /**Goes through token Hash Maps and removes tokens that are stored for 24 hours or longer
     * @param storage_time hash map that contains token and time it was created
     * @param storage_user hash map that contains token and its respective user
     */
    public void token_expiry(HashMap<String, Long> storage_time, HashMap<String, String> storage_user) {
        long currentTime = System.currentTimeMillis();
        long a_day = 24 * 60 * 60 * 1000;

        //Iterate over Hash Maps
        for (Iterator<Map.Entry<String, Long>> i = storage_time.entrySet().iterator(); i.hasNext(); ) {
            Map.Entry<String, Long> entry = i.next();
            long difference = currentTime - entry.getValue();

            //Check if over 24 hours has elapsed
            if ((difference >= a_day)) {
                //Remove from Time Map
                i.remove();
                //Get Value
                String value = entry.getKey();

                //Remove from user Hash Map
                for (Iterator<Map.Entry<String, String>> iterate = storage_user.entrySet().iterator(); iterate.hasNext(); ) {
                    Map.Entry<String, String> user_entry = iterate.next();

                    if(user_entry.getValue() == value)
                        iterate.remove();
                }
            }
        }
    }
}
