package Server;

//import jdk.jfr.StackTrace;

import java.sql.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Schedule {

    ResultSet result;
    Connection conn;

    //Prepared Statements
    private static final String SELECT_BILL_ID_FROM_NAME = "SELECT id from billboards WHERE name=?";
    private static final String SELECT_BILL_TIME = "SELECT * from schedule WHERE billboard_id=? AND start_time=?";
    private static final String DELETE_SCHEDULED_BILL = "DELETE from schedule WHERE billboard_id=? AND start_time=?";
    private static final String INSERT_BILLBOARD_SCHEDULE = "INSERT INTO schedule (billboard_id, start_time, duration, create_user_id, edit_user_id, recurring_type,  recurring_count) VALUES (?, ?, ?, ?, ?, ?, ?)";
    private static final String SCHEDULE_BILLBOARD = "INSERT INTO schedule (billboard_id, start_time, duration, recurring_type,  recurring_count) VALUES (?, ?, ?, ?, ?)";
    private static final String SELECT_BILL= "SELECT\n" +
            "  billboards.name,\n" +
            "  users.username,\n" +
            "  schedule.start_time,\n" +
            "  schedule.duration,\n" +
            " schedule.recurring_type,\n"+
            " schedule.recurring_count\n"+
            " FROM\n" +
            "  billboards\n" +
            "  LEFT JOIN users ON billboards.edit_user_id = users.id\n" +
            "  LEFT JOIN schedule ON billboards.id = schedule.billboard_id\n" +
            "WHERE\n" +
            "  schedule.start_time BETWEEN ? " +
            "  AND ? ORDER BY start_time ASC";
            //Check if you need to show who created the billboard?
    private static final String SELECT_CURRENT_SHOW_BILL = "SELECT b.content,s.billboard_id from  billboards b, schedule s WHERE s.billboard_id = b.id and NOW() >= s.start_time and DATE_ADD(s.start_time,INTERVAL s.duration minute) >=NOW() order by s.start_time desc limit 1";
    private static final String SELECT_DEFAULT_BILL = "SELECT b.content from billboards b left join schedule s on s.billboard_id = b.id WHERE b.default_bill > 0 ORDER BY s.start_time DESC limit 1";
    //Declare Variables??
    public PreparedStatement select_bill_id_from_name;
    public PreparedStatement select_week_billboards;
    public PreparedStatement select_bill_from_time;
    public PreparedStatement delete_scheduled_bill;
    public PreparedStatement insert_bill_schedule;
    public PreparedStatement select_current_show_bill;
    public PreparedStatement select_default_bill;
    public PreparedStatement schedule_billboard;


    public Schedule(){
        conn = ServerThread.getConn();
        try {
            select_bill_id_from_name = conn.prepareStatement(SELECT_BILL_ID_FROM_NAME);
            select_week_billboards = conn.prepareStatement(SELECT_BILL);
            select_bill_from_time = conn.prepareStatement(SELECT_BILL_TIME);
            delete_scheduled_bill = conn.prepareStatement(DELETE_SCHEDULED_BILL);
            insert_bill_schedule = conn.prepareStatement(INSERT_BILLBOARD_SCHEDULE);
            select_current_show_bill = conn.prepareStatement(SELECT_CURRENT_SHOW_BILL);
            select_default_bill = conn.prepareStatement(SELECT_DEFAULT_BILL);
            schedule_billboard = conn.prepareStatement(SCHEDULE_BILLBOARD);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //Properly Close connections
    public void close() {
        try {
            select_bill_id_from_name.close();
            select_week_billboards.close();
            select_bill_from_time.close();
            delete_scheduled_bill.close();
            select_current_show_bill.close();
            schedule_billboard.close();
            if(result != null)
                try{
                    result.close();
                }catch(Exception e){
                    e.printStackTrace();
                    System.out.println("Result close problem");
                }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

    }

    /**Computes the start and end date of a week period (Monday and Sunday date)
     * Dates used in query to get current scheduled billboards in a week
     * @return 2 strings - date of the start of a week and date of the end of the week period (Monday - Sunday)
     * From https://www.w3resource.com/java-exercises/datetime/java-datetime-exercise-9.php
     */
    public String[] get_week_range(){
        Calendar cal = Calendar.getInstance();

        // Set the calendar to start of current week (Monday)
        cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);

        // Specify format of dates (used same as database)
        DateFormat formatDate = new SimpleDateFormat("yyyy-MM-dd 00-00-00");

        //Add Monday Date to calendar and convert to string
        cal.add(Calendar.DATE, 0);
        String first_day = formatDate.format(cal.getTime());

        //Add Sunday Date to calendar and convert to string
        //Change if want 1 Week Monday - Friday or Monday - Sunday
        cal.add(Calendar.DATE, 4);
        String last_day = formatDate.format(cal.getTime());

        //Return 2 Dates
        return new String[] {first_day, last_day};
    }


    /**Function that gets the Billboard ID using the inputted billboard name
     * @param billboard_name billboard name
     * @return int id number of the billboard
     */
    public int bill_id_from_name(String billboard_name) throws SQLException {
        int id = 0;

        select_bill_id_from_name.setString(1, billboard_name);
        result = select_bill_id_from_name.executeQuery();

        while (result.next()){
            id = result.getInt("id");
        }

        return id;
    }


   /**Function that modifies the inputing string to a appropriate date
     * @param inputDate date
     * @return String in the specified format
     * Reference: From https://stackoverflow.com/questions/2009207/java-unparseable-date-exception
     */
    public String modifyDateLayout(String inputDate) throws ParseException {
        Date date = null;
        //Parse inputted date and change format
        date = new SimpleDateFormat("yyyy-MM-dd HH-mm-00").parse(inputDate);
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:00").format(date);
    }

    
    /**Function that displays scheduled billboards in a table format
     * @param st SQL connection to get result set 
     * @return String containing rows of data from the database
     */
    public String display_schedule(Statement st) throws SQLException {
        ResultSet rs = null;
        rs = select_week_billboards.executeQuery();

        //Declare Variables
        String output = "";
        String row = "";


        // output each row
        while (rs.next()) {
            String name = rs.getString("billboards.name");
            String creator = rs.getString("users.username");

            //Format Time
            DateFormat dateFormat = new SimpleDateFormat("EEEEEEE hh:mm a");
            Timestamp time = rs.getTimestamp("schedule.start_time");

            int duration = rs.getInt("schedule.duration");
            //long duration_min = duration /60;

            //Add line of data to string
            String line = "billboard_name:" + name + ":creator:" + creator + ":time:" + dateFormat.format(time) + ":duration:" + duration + " mins:";
            row += line;
        }
        output = row;

        rs.close();
        return output;
    }

   /**Function that gets the end date of a week using a given date
     * @param start_date a starting date
     * @return Date date of the end of the week (Friday) of the Starting date
     */
    public Date get_week_end(Date start_date){

        Calendar cal = Calendar.getInstance();

        cal.setTime(start_date);
        // Set the calendar to start of current week (Monday)
        cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);

        //Add Sunday Date to calendar and convert to string
        //Add 5 Days from Monday to Get Friday (End of Week)
        cal.add(Calendar.DATE, 5); 
        cal.getTime();

        //Return Date of Friday
        return cal.getTime();
    }
}
