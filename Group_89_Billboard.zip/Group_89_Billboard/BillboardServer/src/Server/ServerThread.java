package Server;

//import javax.naming.AuthenticationNotSupportedException;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import java.sql.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Properties;


/*
 * Individual ServerThread listens for the client to tell it what command to run, then
 * runs that command and sends the output of that command to the client
 *
 */

public class ServerThread extends Thread {
    //Initial global variables for each serverthread
    public static Connection getConn() {
        return conn;
    }

    private static Connection conn = null;

    Socket client = null;
    PrintWriter output;
    BufferedReader input;
    Properties db_prop;
    Integer userID;

    Integer sessiontime = 3600;
    Boolean isAuthenticated = false;
    Boolean user_can_create_billboards = false;
    Boolean user_can_edit_billboards = false;
    Boolean user_can_edit_schedules = false;
    Boolean user_can_edit_users = false;
    ResultSet result = null;
    String client_token = "";
    //
    private enum Recurring_type { day, hour, minute, }

    User user;
    SessionToken session;
    Schedule schedule;

    //Input variable from the main server
    public ServerThread(Socket client, Properties db_prop, Integer sessiontime) {
        this.client = client;
        this.db_prop = db_prop;
        this.sessiontime = sessiontime;
    }

    /**@Control Panel: When sending string must ensure format is HH-mm-ss else exception will occur
     *
     */
    public void run() {
        System.out.print("Accepted connection. ");
        //Try to start the serverthread and check for errors
        try {
            // get the db property value from the server

            String db_schema = db_prop.getProperty("jdbc.schema").toString();
            String databaseURL = db_prop.getProperty("jdbc.url").toString() + "/" + db_schema;
            String db_username = db_prop.getProperty("jdbc.username").toString();
            String db_password = db_prop.getProperty("jdbc.password").toString();

            //initialise mariadb driver
            Class.forName("org.mariadb.jdbc.Driver");
            //create a new connection to the database
            this.conn = DriverManager.getConnection(databaseURL, db_username, db_password);
            //If there is a connection you will be able to request to the server

            if (conn != null) {
                //to handle errors
                try {
                    Statement st = conn.createStatement();
                    user = new User();
                    session = new SessionToken();
                    schedule = new Schedule();

                    // open a new PrintWriter and BufferedReader on the socket
                    output = new PrintWriter(client.getOutputStream(), true);
                    input = new BufferedReader(new InputStreamReader(client.getInputStream())); //A new Client requests
                    System.out.println("Reader and writer created. ");

                    String inString; //Declare input string variable

                    // read the command from the client
                    inString = input.readLine().replace("\n","");
                    isAuthenticated = false;
                    //ServerThread loop, to handle continuous requests from the client


                    String bill_name = "";
                    String content_merge = "";
		            while (inString != null) {

                        System.out.println("Clients command " + inString);
                        String answer = "ACK: Request Received";
                        
                        if (!inString.isEmpty() && !inString.startsWith("login:") && !inString.startsWith("token:") && !inString.startsWith("billboard:") && !inString.startsWith("user:") && !bill_name.isEmpty() && !content_merge.isEmpty() && isAuthenticated) {
                            content_merge = content_merge + inString;
                              inString="billboard:update:"+bill_name+":"+content_merge;
                        }else {
                           bill_name = "";
                            content_merge = "";
                        }
                        //Check for command seperator ":"
                        if (inString.contains(":")){
                            //by splitting the string you will be able to put in the commands that will then execute
                            //e.g. logn:username:password, you will put login then your user which would be Admin and finally your hashed pass,
                            // so login:admin:ac9689e2272427085e35b9d3e3e8bed88cb3434828b43b86fc0596cad4c6e270  will let you login as the admin
                            String[] CommandnValues = inString.split(":");
                            Integer CommandnLength = CommandnValues.length;
                            String command = CommandnValues[0];
                            String request = "None";
                            //Provide variable to check various commands
                            if (CommandnLength > 1 )  request = CommandnValues[1];
                            else answer = "ERR: Please provide valid request";

                            //Request login, it checks whether your user is taken/valid,
                            // checks if you are using the right password and for a valid session token
                            if (command.toLowerCase().equals("login")) {
                                //Check for initial login and return token if successful
                                if (CommandnLength > 2){
                                    String username =  CommandnValues[1];
                                    String passwordhash =  CommandnValues[2];
                                    //query seach for user by userpass[0] & hashpwd userpass[0];
                                    user.select_user_id_password.setString(1, username);
                                    ResultSet result = user.select_user_id_password.executeQuery();
                                    //Get database details
                                    if (result.next()){
                                        String password  = result.getString("password");
                                        //update old token or insert a new one
                                        if (Password.check(passwordhash,password)){
                                            String token = Password.newToken();
                                            Integer user_id = result.getInt("id");
                                            //update old token
                                            if (session.validate_token(st, token)>0){
                                                session.update_token.setString(1, token);
                                                session.update_token.setInt(2,  sessiontime);
                                                session.update_token.setInt(3, user_id);
                                                session.update_token.executeUpdate();
                                            }else{
                                                session.insert.setInt(1, user_id);
                                                session.insert.setString(2, token);
                                                session.insert.setInt(3,sessiontime);
                                                session.insert.executeUpdate();
                                            }
                                            answer = "token:"+token;
                                        }else{
                                            answer = "ERR: Incorrect password";
                                        }
                                    }else{
                                        answer = "ERR: User does not exist";
                                    }
                                    result.close();
                                }else if (CommandnLength == 2) answer = "ERR: Please provide password";
                                else answer = "ERR: Please provide username and password";
                                //Validate Token and authenticate the user
                            } else if (command.toLowerCase().equals("token") ) {

                                if (CommandnLength > 1){
                                    client_token = CommandnValues[1];
                                    userID = session.validate_token(st, client_token );
                                    if (userID > 0){
                                        isAuthenticated = true;
                                        user.get_user_permissions.setInt(1,userID);
                                        ResultSet result = user.get_user_permissions.executeQuery();
                                        //update global variables for user permissions
                                        if (result.next()){
                                            if (result.getInt("create_billboard") > 0) {
                                                user_can_create_billboards = true;
                                            }
                                            if (result.getInt("edit_billboard") > 0) {
                                                user_can_edit_billboards = true;
                                            }
                                            if (result.getInt("edit_schedule") > 0) {
                                                user_can_edit_schedules = true;
                                            }
                                            if (result.getInt("edit_users") > 0) {
                                                user_can_edit_users = true;
                                            }
                                        }
                                        answer = "ACK: Connection is Authenticated";
                                    }else{
                                        answer = "ERR: Invalid Token!";
                                    }
                                }else answer = "ERR: Not provided Token!";
                                //check for existinmg token {CommandnValues[1]}
                                //This request is for billboard viewer, so when the viewer requests billboards
                                //the server will send back the contents of that billboard
                            } else if (command.toLowerCase().equals("billboard") && request.toLowerCase().equals("viewer")) {
                                //Billboard Viewer should call every 15 sec to search schedule by keyword in CommandnValues[1]
                                String billboardcontent = "";
                                ResultSet resultbill = schedule.select_current_show_bill.executeQuery();
                                if(resultbill.next()){
                                    billboardcontent = resultbill.getString("content");
                                }else{
                                    ResultSet billdefault = schedule.select_default_bill.executeQuery();
                                    if(billdefault.next()){
                                        billboardcontent = billdefault.getString("content");
                                    }
                                }
                                answer = "Billboard content:"+billboardcontent;
                            }else {

                                //If user's token is Authenticated
                                userID = session.validate_token(st, client_token);
                                if (userID < 1) {
                                    isAuthenticated = false;
                                }
                                if (isAuthenticated) {
                                    System.out.println("Token is isAuthenticated. Command:" + command + " and Request:" + request);
                                    //This request is to send a list of all billboards back to the control panel
                                    //e.g. billboard:list will return all billboards
                                    if (command.toLowerCase().equals("billboard") && request.toLowerCase().equals("list")) {
                                        ResultSet result = user.list_user_billboards.executeQuery();
                                        answer = "";
                                        Boolean isBillExist = false;
                                        while (result.next()) {
                                            bill_name = result.getString("billboard_name");
                                            String create_user = result.getString("create_user");
                                            String edit_user = result.getString("edit_user");
                                            String bill_start_time = result.getString("start_time");
                                            String duration = result.getString("duration");
                                            String recurring_type = result.getString("recurring_type");
                                            String recurring_count = result.getString("recurring_count");
                                            output.println("billboard_name:" + bill_name + ":create_user:" + create_user + ":edit_user:" + edit_user + ":start_time:" + bill_start_time + ":duration:" + duration + ":recurring_type:" + recurring_type + ":recurring_count:" + recurring_count);
                                            isBillExist = true;
                                        }
                                        if (!isBillExist) {
                                            answer = "ERR: No billboards to list!";
                                        }
                                    }
                                    //This request is to send back the contents of a particular billboard when the control panel requests it.
                                    else if (command.toLowerCase().equals("billboard") && request.toLowerCase().equals("get")) {
                                        if (CommandnLength > 2) {
                                            bill_name = CommandnValues[2];
                                            user.get_billboard_info.setString(1, bill_name);
                                            ResultSet result = user.get_billboard_info.executeQuery();
                                            if (result.next()) {
                                                answer = result.getString("content");
                                            } else {
                                                answer = "ERR: No billboard found!";
                                            }
                                        } else answer = "ERR: Please provide billboard name";
                                    }
                                    //This request is for when the control panel has users that are creating/editing billboards
                                    //This handles it for both Create user perms and Edit user perms
                                    else if (command.toLowerCase().equals("billboard") && request.toLowerCase().equals("update")) {

                                        if (CommandnLength > 3) {
                                            bill_name = CommandnValues[2];
                                            String bill_content = CommandnValues[3];
                                            //Check if content has a seperator ":" in the content and merge the rest of the array
                                            if (CommandnLength > 4) {
                                                for (int i = 4; i < CommandnLength; i++) {
                                                    bill_content = bill_content + ":" + CommandnValues[i];
                                                }
                                            }
                                            Integer current_scheduled_bill_id = 0;
                                            ResultSet resultbill = schedule.select_current_show_bill.executeQuery();
                                            //Get the billboard schedule
                                            if (resultbill.next()) {
                                                current_scheduled_bill_id = resultbill.getInt("billboard_id");
                                            }
                                            user.get_billboard_info.setString(1, bill_name);
                                            result = user.get_billboard_info.executeQuery();
                                            //Get the existing billboard
                                            if (result.next()) {
                                                Integer bill_id = result.getInt("id");
                                                Integer bill_create_user_id = result.getInt("create_user_id");
                                                //If the user has own billboard or user can edit all then update content
                                                if ((userID == bill_create_user_id && current_scheduled_bill_id != bill_id) || user_can_edit_billboards) {
                                                    user.update_billboard.setInt(1, userID);
                                                    user.update_billboard.setString(2, bill_content);
                                                    user.update_billboard.setInt(3, bill_id);
                                                    user.update_billboard.executeQuery();
                                                    answer = "ACK:BILLBOARD_EDITED";
                                                } else {
                                                    answer = "ERR: Insufficient permissions to edit billboard";
                                                }
                                                //If billboard does not exist create a new billboard
                                            } else if (user_can_create_billboards) {
                                                user.create_billboard.setInt(1, userID);
                                                user.create_billboard.setInt(2, userID);
                                                user.create_billboard.setString(3, bill_name);
                                                user.create_billboard.setString(4, bill_content);
                                                user.create_billboard.executeQuery();
                                                answer = "ACK:BILLBOARD_CREATED";
                                            } else {
                                                answer = "ERR: Insufficient permissions to create billboards";
                                            }

                                            content_merge = bill_content + "\n";

                                        } else if (CommandnLength == 2)
                                            answer = "ERR: Please provide billboard name and content";
                                        else answer = "ERR: Please provide billboard content";
                                    }
                                    //When the Control panel requests the server to delete it will execute this request
                                    //If you have the create bill perms you will be able to delete your own billboard if it is not currently scheduled
                                    //For edit all bill perms you will be able to delete all billboards including those that are currently scheduled as specified.
                                    else if (command.toLowerCase().equals("billboard") && request.toLowerCase().equals("delete")) {
                                        if (CommandnLength > 2) {
                                            bill_name = CommandnValues[2];

                                            Integer current_scheduled_bill_id = 0;
                                            ResultSet resultbill = schedule.select_current_show_bill.executeQuery();
                                            if (resultbill.next()) {
                                                current_scheduled_bill_id = resultbill.getInt("billboard_id");
                                            }
                                            user.get_billboard_info.setString(1, bill_name);
                                            result = user.get_billboard_info.executeQuery();
                                            if (result.next()) {
                                                Integer bill_id = result.getInt("id");
                                                Integer bill_create_user_id = result.getInt("create_user_id");
                                                if ((userID == bill_create_user_id && current_scheduled_bill_id != bill_id) || user_can_edit_billboards) {
                                                    user.delete_billboard_schedules.setInt(1, bill_id);
                                                    user.delete_billboard_schedules.executeQuery();
                                                    user.delete_billboard.setInt(1, bill_id);
                                                    user.delete_billboard.executeQuery();
                                                    answer = "ACK:BILLBOARD_DELETED";
                                                } else {
                                                    answer = "ERR: Insufficient permissions to delete billboard";
                                                }
                                            } else {
                                                answer = "ERR: Billboard not found";
                                            }
                                        } else answer = "ERR: Please provide billboard name";
                                    }
                                    /*Schedule Billboard
                                     *Control Panel sends billboard name, time, duration, recurrence values [type] to be stored in database
                                     * User requires edit schedule permission
                                     * */
                                    else if (command.equals("billboard") && request.equals("schedule") && CommandnLength > 6) {
                                        //Declare Variables
                                        boolean error = false;
                                        int duration = 0;
                                        Recurring_type occurrence_type = null;
                                        int check = 0;
                                        String formatted_time = "";
                                        int recurring_count = 0;

                                        bill_name = CommandnValues[2];
                                        String time = CommandnValues[3];

                                        //Create calendar instance to use date
                                        Calendar calendar = Calendar.getInstance();


                                        //Format Time Stamp to appropriate format for inserting in DB
                                        Timestamp start_time = null;
                                        try {
					     if (time.length() < 17 ){
                                                //Add 00 on the end for seconds
                                                time += "-00";
					     }
						
                                            //Check if Data is Weekend
                                            formatted_time = schedule.modifyDateLayout(time);
                                            start_time = Timestamp.valueOf(formatted_time);

                                            //Check if Data Falls On a Saturday Or Sunday
                                            calendar.setTime(start_time);
                                        } catch (Exception e) {
                                            error = true;
                                            answer = "ERR: Please input an appropriate date (yyyy-MM-dd) and time (HH-mm)";

                                        }

                                        //Parse Int Duration from String from Control Panel
                                        try {
                                            duration = Integer.parseInt(CommandnValues[4]);
                                        } catch (Exception e) {
                                            error = true;
                                            answer = "ERR: Please input the number of minutes you wish for the billboard to show for!";

                                        }

                                        int minute_apart = 0;

                                        if (!error) {
                                            //Assign re-occurance value depending on user input
                                            if (!CommandnValues[5].contains(",")) {
                                                //Get Enum of Re-occurring Type
                                                if (CommandnValues[5].isEmpty()) {
                                                    occurrence_type = null;
                                                } else if (CommandnValues[5].equals("day")) {
                                                    occurrence_type = Recurring_type.day;
                                                } else if (CommandnValues[5].equals("hour")) {
                                                    occurrence_type = Recurring_type.hour;
                                                }
                                            } else {
                                                //Occurrence Type is Minute
                                                occurrence_type = Recurring_type.minute;

                                                //Split String and get Number of Minutes
                                                String[] min_details = CommandnValues[5].split(",");
                                                try {
                                                    minute_apart = Integer.parseInt(min_details[1]);
                                                } catch (Exception e) {
                                                    error = true;
                                                    answer = "ERR: Please input the number of minutes you wish for the billboard to wait before showing!";
                                                }
                                            }

                                            //Ensure no errors before continuing
                                            if (!error) {
                                                recurring_count = Integer.parseInt(CommandnValues[6]);

                                                //Check if Billboard Exist
                                                schedule.select_bill_id_from_name.setString(1, bill_name);
                                                result = schedule.select_bill_id_from_name.executeQuery();

                                                //Get ID of Billboard (Query Name to get ID)
                                                int id = schedule.bill_id_from_name(bill_name);

                                                //Create variables to Check if Times are between 9am and 5pm
                                                //Get Time portion of Date Time String
                                                String[] time_split = time.split("\\s+");
                                                LocalTime billboard_time = LocalTime.parse(time_split[1], DateTimeFormatter.ofPattern("H-mm-00"));
                                                LocalTime schedule_start = LocalTime.parse("09:00:00");
                                                LocalTime schedule_end = LocalTime.parse("17:00:00");


                                                //Check permssions  and whether billboard exist
                                                if (!user_can_edit_schedules) {
                                                    answer = "ERR: Error: You do not have permission!";

                                                } else if (!result.next()) {
                                                    answer = "ERR: Specified billboard does not exist!";

                                                } else if ((calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) || calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
                                                    answer = "ERR: Cannot schedule billboard on Weekend!";

						                        }else if ((occurrence_type == Recurring_type.minute) && (minute_apart < duration)){
                                                    answer = "ERR: Cannot set minutes between Billboards less than duration!";

                                                }else if (!(billboard_time.isAfter(schedule_start) && billboard_time.isBefore(schedule_end))){
                                                    answer = "ERR: Cannot schedule billboard before 9am or after 5pm!";

                                                } else {

                                                    //No re-occruance is specified so just insert 1 query
                                                    if (occurrence_type == null) {
                                                        recurring_count = 0;
                                                        schedule.schedule_billboard.setInt(1, id);
                                                        schedule.schedule_billboard.setTimestamp(2, start_time);
                                                        schedule.schedule_billboard.setInt(3, duration);
                                                        schedule.schedule_billboard.setNull(4, Types.CHAR);
                                                        schedule.schedule_billboard.setInt(5, recurring_count);
                                                        check = schedule.schedule_billboard.executeUpdate();
                                                        if (check > 0) {
                                                            answer = "Success: Billboard added to schedule";

                                                        } else {
                                                            answer = "ERR: Something went wrong! Billboard not scheduled";

                                                        }
                                                    } else {
                                                        //Calculate End Time
                                                        Calendar end = Calendar.getInstance();
                                                        end.setTime(schedule.get_week_end(calendar.getTime()));
                                                        end.getTime();

                                                        //Calculate End Time at 5pm
                                                        Calendar closing_startTime = Calendar.getInstance();
                                                        closing_startTime.setTime(start_time);
                                                        closing_startTime.set(Calendar.HOUR_OF_DAY, 17);
                                                        closing_startTime.set(Calendar.MINUTE, 00);
                                                        closing_startTime.set(Calendar.SECOND, 0);
                                                        closing_startTime.set(Calendar.MILLISECOND, 0);

                                                        switch (occurrence_type) {
                                                            case day:
                                                                //Create Instances of Billboard at same time of day for Remaining days of the week
                                                                while (calendar.getTime().before(end.getTime())) {

                                                                    //Convert Start Time into Timestamp
                                                                    Timestamp start = new Timestamp(calendar.getTimeInMillis());

                                                                    schedule.schedule_billboard.setInt(1, id);
                                                                    schedule.schedule_billboard.setTimestamp(2, start);
                                                                    schedule.schedule_billboard.setInt(3, duration);
                                                                    schedule.schedule_billboard.setString(4, occurrence_type.name());
                                                                    schedule.schedule_billboard.setInt(5, recurring_count);
                                                                    check = schedule.schedule_billboard.executeUpdate();
                                                                    if (check > 0) {
                                                                        answer = "Success: Billboard added to schedule";

                                                                    } else {
                                                                        answer = "ERR: Something went wrong! Billboard not scheduled";

                                                                    }
                                                                    //Add 24 Hours
                                                                    calendar.add(Calendar.DATE, 1);
                                                                }
                                                                break;
                                                            case hour:
                                                                //While start time before 5pm continue adding 1 hour
                                                                while (calendar.getTime().before(closing_startTime.getTime())) {
                                                                    //Convert Start Time into Timestamp
                                                                    Timestamp start = new Timestamp(calendar.getTimeInMillis());
                                                                    schedule.schedule_billboard.setInt(1, id);
                                                                    schedule.schedule_billboard.setTimestamp(2, start);
                                                                    schedule.schedule_billboard.setInt(3, duration);
                                                                    schedule.schedule_billboard.setString(4, occurrence_type.name());
                                                                    schedule.schedule_billboard.setInt(5, recurring_count);
                                                                    check = schedule.schedule_billboard.executeUpdate();

                                                                    //check if query executed
                                                                    if (check > 0) {
                                                                        answer = "Success: Billboard added to schedule";

                                                                    } else {
                                                                        answer = "ERR: Something went wrong! Billboard not scheduled";

                                                                    }
                                                                    //Add 24 Hours
                                                                    calendar.add(Calendar.HOUR, 1);
                                                                }
                                                                break;
                                                            case minute:
                                                                //While before 5pm on date of date time continue adding xx minutes and creating queries
                                                                while (calendar.getTime().before(closing_startTime.getTime())) {
                                                                    //Convert Start Time into Timestamp
                                                                    Timestamp start = new Timestamp(calendar.getTimeInMillis());
                                                                    schedule.schedule_billboard.setInt(1, id);
                                                                    schedule.schedule_billboard.setTimestamp(2, start);
                                                                    schedule.schedule_billboard.setInt(3, duration);
                                                                    schedule.schedule_billboard.setString(4, occurrence_type.name());
                                                                    schedule.schedule_billboard.setInt(5, recurring_count);
                                                                    check = schedule.schedule_billboard.executeUpdate();

                                                                    //Check if query is successful
                                                                    if (check > 0) {
                                                                        answer = "Success: Billboard added to schedule";

                                                                    } else {
                                                                        answer = "ERR: Something went wrong! Billboard not scheduled";

                                                                    }
                                                                    //Add xx minutes to start time of bilboard
                                                                    calendar.add(Calendar.MINUTE, minute_apart);
                                                                }
                                                                break;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    /*View Billboard Schedule
                                     *Control Panel sends valid session token and server returns list of billboards that are scheduled along with details
                                     * User requires Edit schedule permission
                                     * */
                                    else if (command.equals("billboard") && request.equals("view schedule")) {

                                        //Check user permissions
                                        if (user_can_edit_schedules) {
                                            String[] dates = schedule.get_week_range();
                                            String first_week_day = dates[0];
                                            String last_week_day = dates[1];

                                            //Add 1 Day to Last Week Date (so schedule is not cut on Thursday)
                                            try {
                                                first_week_day = schedule.modifyDateLayout(first_week_day);
                                                last_week_day = schedule.modifyDateLayout(last_week_day);
                                            } catch (ParseException e) {
                                                e.printStackTrace();
                                            }

                                            Timestamp start_week = Timestamp.valueOf(first_week_day);
                                            Timestamp end_week = Timestamp.valueOf(last_week_day);

                                            //Assign 5 pm to end of Week Time and Date
                                            Calendar ending_time = Calendar.getInstance();
                                            ending_time.setTime(end_week);
                                            ending_time.add(Calendar.HOUR_OF_DAY, 17);
                                            ending_time.getTime();

                                            //Assign Times to Calendar and Set Hour to 9 am
                                            Calendar start = Calendar.getInstance();
                                            start.setTime(start_week);
                                            start.add(Calendar.HOUR_OF_DAY, 9);
                                            start.getTime();

                                            //Add 1 Day to End time to ensure Schedule goes to Friday
                                            Calendar end = Calendar.getInstance();
                                            end.setTime(end_week);
                                            end.add(Calendar.DATE, 1);
                                            end.getTime();

                                            //Convert Calendar to Time stamp
                                            Timestamp start_stamp = new Timestamp(start.getTimeInMillis());
                                            Timestamp end_stamp = new Timestamp(end.getTimeInMillis());

                                            schedule.select_week_billboards.setTimestamp(1, start_stamp);
                                            schedule.select_week_billboards.setTimestamp(2, end_stamp);
                                            schedule.select_week_billboards.executeQuery();

                                            //Display Schedule in Table like format string
                                            DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd EEEEEEE hh:mm a");

                                            answer = dateFormat.format(start_stamp) + " - " + dateFormat.format(ending_time.getTimeInMillis()) + ":" + schedule.display_schedule(st);


                                        } else {
                                            answer = "ERR: Invalid Permission to view!";
                                        }
                                    }

                                    /*Delete Billboard from Schedule
                                     *Control Panel sends billboard name and time which is deleted from Schedule
                                     * User requires edit schedule permission
                                     * */
                                    else if (command.equals("billboard") && request.equals("remove schedule") && CommandnLength > 3) {
                                        bill_name = CommandnValues[2];
                                        String time = CommandnValues[3];

                                        int id = schedule.bill_id_from_name(bill_name);
                                        boolean error = false;
                                        String formatted_time = "";

                                        //Format Time Stamp for DB
                                        try {
                                            formatted_time = schedule.modifyDateLayout(time);
                                        } catch (ParseException e) {
                                            error = true;
                                            answer = "Please input an appropriate date (yyyy-MM-dd) and time (HH-mm-ss)";

                                        }

                                        //Delete Billboard that Has ID and Same Time
                                        //Check permissions, blank inputs and whether billboard exist in schedule
                                        if (!error) {
                                            schedule.select_bill_from_time.setInt(1, id);
                                            schedule.select_bill_from_time.setTimestamp(2, Timestamp.valueOf(formatted_time));
                                            result = schedule.select_bill_from_time.executeQuery();

                                            if (!user_can_edit_schedules) {
                                                answer = "ERR: You do not have permission!";

                                            } else if (bill_name.isEmpty()) {
                                                answer = "ERR: Please Specify a Billboard to remove!";

                                            } else if (result.next() == false) {
                                                answer = "ERR: Specified billboard does not exist in schedule!";

                                            } else {
                                                //Delete Billboard
                                                schedule.delete_scheduled_bill.setInt(1, id);
                                                schedule.delete_scheduled_bill.setTimestamp(2, Timestamp.valueOf(formatted_time));
                                                int check = schedule.delete_scheduled_bill.executeUpdate();

                                                //Check if Query executed
                                                if (check > 0) {
                                                    answer = "Success: Billboard removed from Schedule";

                                                } else {
                                                    answer = "ERR: Something went wrong! Billboard not removed from schedule";

                                                }
                                            }
                                        }
                                    }

                                    /*Delete User
                                     *Control Panel sends username to delete from database (if the user has created billboards, billboard id's are changed to 0)
                                     * User cannot delete themselves and must have edit user permission
                                     * */
                                    else if (command.equals("user") && request.equals("delete") && CommandnLength > 2) {
                                        String name = CommandnValues[2];

                                        user.select_permission.setString(1, name);
                                        result = user.select_permission.executeQuery();

                                        //Check uers existence, blank spaes, and whether use is removing themselves
                                        if (!result.next()) {
                                            answer = "ERR: User does not Exist!";

                                        } else if (name.isEmpty()) {
                                            answer = "ERR: Please specify user to delete!";

                                        } else if (!user_can_edit_users) {
                                            answer = "ERR: You do not have permission to delete!";

                                        } else if ((user.check_user_and_token(name, client_token))) {
                                            answer = "ERR: Unable to remove user! Cannot remove yourself!";
					} else if (name.equals("admin")){
                                            answer = "ERR: Unable to remove admin!";
                                        } else if ((user_can_edit_users) && (!user.check_user_and_token(name, client_token))) {
                                            //Get User ID using Username
                                            user.select_user_id_using_username.setString(1, name);
                                            result = user.select_user_id_using_username.executeQuery();

                                            int id_user = 0;
                                            while (result.next()) {
                                                id_user = result.getInt("id");
                                            }

                                            //Change Billboard User_Id to 0
                                            user.update_bill_id.setInt(1, id_user);
                                            user.update_bill_id.executeQuery();

                                            //Delete User
                                            user.delete_user.setString(1, name);
                                            int check = user.delete_user.executeUpdate();

                                            //Check if datbase updated
                                            if (check > 0) {
                                                answer = "Success: " + name + " has been deleted!";

                                            } else {
                                                answer = "ERR: User Not Deleted!";

                                            }
                                        }
                                    }

                                    /* Set User Password
                                     * Control Panel sends username and hashed password, salted password is stored in database of the user specified
                                     * User must have edit user permission unless user is changing own password
                                     * */
                                    else if (command.equals("user") && request.equals("set password") && CommandnLength > 3) {
                                        String name = CommandnValues[2];
                                        String hashed_password = CommandnValues[3];

                                        //Check if user exist
                                        user.select_permission.setString(1, name);
                                        result = user.select_permission.executeQuery();


                                        //Check if user exist, blank inputs, & permssions
                                        if (!result.next()) {
                                            answer = "ERR: User does not Exist!";

                                        } else if (name.isEmpty() || hashed_password.equals(null)) {
                                            answer = "ERR: Please specify a username and password!";

                                        }
                                        //Check if User has Edit User permission to change
                                        //Check if user is trying to change another password without permission
                                        else if ((!user_can_edit_users) && (!user.check_user_and_token(name, client_token))) {
                                            answer = "ERR: Please specify a username and password!";

                                        } else if ((user_can_edit_users) || (user.check_user_and_token(name, client_token))) {
                                            //Salt Hashed Password and Store in Database
                                            String salted_hash = Password.getSaltedHash(hashed_password);
                                            user.update_password.setString(1, salted_hash);
                                            user.update_password.setString(2, name);
                                            int check = user.update_password.executeUpdate();

                                            if (check > 0) {
                                                answer = "Success: Password Updated!";

                                            } else {
                                                answer = "ERR: Password Not Changed!";

                                            }
                                        }
                                    }

                                    /* Set User Permissions
                                     * Control Panel sends username and list of permissions (separated by ,) to be updated in database
                                     * User must have edit user permission and cannot remove own edit permission
                                     * */
                                    else if (command.equals("user") && request.equals("set permission") && CommandnLength > 3) {
                                        String permission_list = CommandnValues[2];
					String name = CommandnValues[3];
                                        

                                        //Check if username exist
                                        user.select_permission.setString(1, name);
                                        result = user.select_permission.executeQuery();


                                        //Declare Variables to store permissions
                                        int edit_bill = 0;
                                        int create_bill = 0;
                                        int edit_users = 0;
                                        int edit_schedule = 0;

                                        //Split Permissions from List
                                        String[] permissions = null;
                                        //Split Permission List
                                        if (permission_list != null) {
                                            permissions = permission_list.trim().split(",");
                                            for (String s : permissions) {
                                                switch (s.trim()) { //Remove any trailing or leading spaces
                                                    case ("edit billboard"):
                                                        edit_bill = 1;
                                                        break;
                                                    case ("create billboard"):
                                                        create_bill = 1;
                                                        break;
                                                    case ("edit users"):
                                                        edit_users = 1;
                                                        break;
                                                    case ("edit schedule"):
                                                        edit_schedule = 1;
                                                        break;
                                                }
                                            }
                                        }

                                        //Check if user exist, permssions, blank inputs,
                                        //Check whether use is trying to remove own edit permissions
                                        if (!result.next()) {
                                            answer = "ERR: User does not Exist!";
                                        } else if (!user_can_edit_users) {
                                            answer = "ERR: Incorrect permissions to change!";

                                        } else if ((user.check_user_and_token(name, client_token)) & (edit_users == 0)) {
                                            answer = "ERR: Unable to remove Edit Users Permission";

                                        }else if ((name.equals("admin")) && (edit_users == 0 || edit_bill == 0 || edit_schedule == 0 || create_bill == 0)){
                                            answer = "ERR: Unable to remove Permissions from admin";
                                        } else {
                                            //Update Permissions
                                            user.update_permissions.setInt(1, create_bill);
                                            user.update_permissions.setInt(2, edit_bill);
                                            user.update_permissions.setInt(3, edit_schedule);
                                            user.update_permissions.setInt(4, edit_users);
                                            user.update_permissions.setString(5, name);
                                            int check = user.update_permissions.executeUpdate();

                                            //Check if Query Successful
                                            if (check > 0) {
                                                answer = "Success: Permissions Updated!";

                                            } else {
                                                answer = "ERR: Try again later!";

                                            }
                                        }
                                    }

                                    /*Create User
                                     * Control Panel sends username, permissions list (separated by comma), hashed password
                                     * Must have edit user permission, cannot use username that already exist, username and password must not be blank
                                     * */
                                    else if (command.equals("user") && request.equals("create") && CommandnLength > 4) {
                                        String name = CommandnValues[2];
                                        String permission_list = CommandnValues[3];
                                        String hashed_password = CommandnValues[4];

                                        //Declare Variables to store list of permissions
                                        int edit_bill = 0;
                                        int create_bill = 0;
                                        int edit_users = 0;
                                        int edit_schedule = 0;

                                        //Store Split Permissions from List
                                        String[] permissions = null;
                                        //Split Permission List
                                        if (permission_list != null) {
                                            permissions = permission_list.split(",");
                                            for (String s : permissions) {
                                                System.out.println(s);
                                                switch (s.trim()) { //Remove any trailing or leading spaces
                                                    case ("edit billboard"):
                                                        edit_bill = 1;
                                                        break;
                                                    case ("create billboard"):
                                                        create_bill = 1;
                                                        break;
                                                    case ("edit users"):
                                                        edit_users = 1;
                                                        break;
                                                    case ("edit schedule"):
                                                        edit_schedule = 1;
                                                        break;
                                                }
                                            }
                                        }

                                        //Check if Username Already Exist in database
                                        user.select_user.setString(1, name);
                                        result = user.select_user.executeQuery();


                                        //Check permission, black inputs, and user existence
                                        if (!user_can_edit_users) {
                                            answer = "ERR: You do not have correct permissions!";

                                        } else if (name.isEmpty() || hashed_password.isEmpty()) {
                                            answer = "ERR: Please username or password cannot be blank!";

                                        } else if (result.next()) {
                                            answer = "ERR: Username already exist! Please select another name...";

                                        } else {
                                            //Store New User variables in database
                                            user.insert_user.setString(1, name);
                                            String salted_hash = Password.getSaltedHash(hashed_password);
                                            user.insert_user.setString(2, salted_hash);
                                            user.insert_user.setInt(3, create_bill);
                                            user.insert_user.setInt(4, edit_bill);
                                            user.insert_user.setInt(5, edit_schedule);
                                            user.insert_user.setInt(6, edit_users);
                                            int check = user.insert_user.executeUpdate();

                                            if (check > 0) {
                                                answer = "Success: User '" + name + "' created!";

                                            } else {
                                                answer = "ERR: Try again later!";

                                            }
                                        }

                                    }

                                    /*Get User Permissions
                                     * Control Panel sends username and returns a list of permissions
                                     * Must have edit user permission unless requesting for own permissions
                                     * */
                                    else if (command.equals("user") && request.equals("get permission") && CommandnLength > 2) {
                                        String user_name = CommandnValues[2];

                                        //Check if user exist
                                        user.select_permission.setString(1, user_name);
                                        result = user.select_permission.executeQuery();

                                        //Check user existence, permissions
                                        if (!result.next()) {
                                            answer = "ERR: User does not Exist!";

                                        } else if ((!user_can_edit_users) && (!user.check_user_and_token(user_name, client_token))) {
                                            answer = "ERR: You do not have permission to view!";

                                        }
                                        //if user has permission or user is asking for own permissions
                                        else if ((user_can_edit_users) || (user.check_user_and_token(user_name, client_token))) {
                                            answer = user.displayPermissions(st);

                                        } else {
                                            answer = "ERR: Try again later!";

                                        }
                                    }

                                    /*List Users
                                     * Control Panel valid token and returns a list of users
                                     * Must have edit user permission
                                     * */
                                    else if (command.equals("user") && request.equals("list") && CommandnLength > 1) {

                                        //Check if user has permissions before displaying user
                                        if (user_can_edit_users) {
                                            answer = user.displayUsers(st, User.SELECT_USER);
                                        } else {
                                            answer = "ERR: Invalid Permission!";

                                        }
                                    }

                                    /*Logout
                                     * Control Panel valid token and logs user out of database by deleting session token
                                     * No permissions required
                                     * */
                                    else if (command.equals("user") && request.equals("logout")) {

                                        isAuthenticated = false;

                                        if (session.validate_token(st, client_token) == userID) {
                                            //Remove Session From database
                                            session.delete.setString(1, client_token);
                                            int check = session.delete.executeUpdate();

                                            //Reset Variables
                                            user_can_edit_schedules = false;
                                            user_can_edit_users = false;
                                            user_can_create_billboards = false;
                                            user_can_edit_billboards = false;
                                            client_token = null;

                                            if (check > 0) {
                                                answer = "Sucess: Logged Out";

                                            } else {
                                                answer = "ERR has occurred!";

                                            }
                                        } else {
                                            answer = "ERR: Unable to Log out!";
                                        }
                                    } else answer = "ERR: Bad command!";

                                } else answer = "ERR: Invalid Token or Expired!";
                            }

                        }else  answer = "ERR: Bad command!";
                        //
                        if (answer.length() > 0 ) output.println(answer);
                        if (answer.contains("ERR:") || answer.contains("ACK:")) System.out.println(answer);
                        output.println("END_MESSAGE");
                        inString = input.readLine();
                    }
                    st.close();
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    // close the connections to the client & connections to the db
                    if(client != null)
                        try{
                            client.close();
                        }catch(Exception e){
                            e.printStackTrace();
                            System.out.println("client close problem");
                        }
                    if(conn != null)
                        try{
                            conn.close();
                        }catch(Exception e){
                            e.printStackTrace();
                            System.out.println("Database Connection close problem");
                        }
                    if(user != null)
                        try{
                            user.close();
                        }catch(Exception e){
                            e.printStackTrace();
                            System.out.println("User close problem");
                        }
                    if(session != null)
                        try{
                            session.close_token();
                        }catch(Exception e){
                            e.printStackTrace();
                            System.out.println("Session Token close problem");
                        }
                    if(schedule != null)
                        try{
                            schedule.close();
                        }catch(Exception e){
                            e.printStackTrace();
                            System.out.println("Schedule close problem");
                        }
                    System.out.println("Output closed.");
                }
            } else {
                System.out.print("No connection to the database ");
            }
        } catch (ClassNotFoundException ex) {
            System.out.println("Could not find database driver class");
            ex.printStackTrace();
        } catch (SQLException ex) {
            System.out.println("An error occurred. Maybe user/password is invalid");
            ex.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        }

    }
}

