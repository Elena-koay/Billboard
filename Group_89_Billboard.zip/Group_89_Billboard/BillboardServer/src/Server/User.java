package Server;

import javax.swing.*;
import javax.swing.plaf.nimbus.State;
import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

//Class holds functions that are used for User related functions in the Server Thread
public class User {

    ResultSet result;
    private Connection conn;

    //Statements
    public static final String SELECT_USER = "SELECT id, username from users";

    //Prepared Statements
    private static final String SELECT_USER_PERMISSION = "SELECT id, username, create_billboard, edit_billboard, edit_schedule, edit_users FROM users WHERE username=? ";
    private static final String INSERT_USER = "INSERT INTO users (username, password, create_billboard, edit_billboard, edit_schedule, edit_users) VALUES (?, ?, ?, ?, ?, ?)";
    private static final String SELECT_USER_NAME = "SELECT username from users WHERE username=?";
    private static final String UPDATE_PERMISSIONS = "UPDATE users SET create_billboard=?, edit_billboard=?, edit_schedule=?, edit_users=? WHERE username=?";
    private static final String UPDATE_USER_PASS = "UPDATE users SET password=? WHERE username=?";
    private static final String DELETE_USER = "DELETE from users WHERE username=?";
    private static final String SELECT_USER_ID_USERNAME = "SELECT id from users WHERE username=?";

    //Prepared Statements Helper Functions
    private static final String SELECT_USERNAME_ID = "SELECT username from users WHERE id=?";
    private static final String SELECT_ID_USING_TOKEN = "SELECT user_id from session_tokens WHERE session_token=?";

    //Update Billboards
    private static final String UPDATE_BILL_ID = "UPDATE billboards SET create_user_id=0 WHERE create_user_id=?";
    
    //login
    private static final String SEARCH_USER_ID_PASSWORD = "SELECT * from users where username=? order by id limit 1";
    private static final String LIST_USER_BILLBOARDS = "select b.name as billboard_name,cu.username as create_user,eu.username as edit_user,DATE_FORMAT(s.start_time,'%y-%m-%d %H-%i-%s') as start_time,s.duration,s.recurring_type,s.recurring_count from billboards b left join users cu on cu.id=b.create_user_id left join users eu on eu.id=b.edit_user_id left join schedule s on s.billboard_id = b.id";

    private static final String GET_USER_PERMISSIONS = "select create_billboard,edit_billboard,edit_schedule,edit_schedule,edit_users from users where id=?";

    //create billboards
    private static final String CREATE_BILL = "INSERT INTO billboards (create_user_id,edit_user_id, name, content, default_bill) values (?,?,?,?,0)";
    private static final String UPDATE_BILL = "UPDATE billboards set edit_user_id=?,content=? where id=?";
    private static final String DELETE_BILL = "DELETE FROM billboards where id=?";
    private static final String DELETE_BILL_SCHEDULES = "DELETE FROM schedule where billboard_id=?";
    private static final String GET_BILLBOARD_INFO = "select id,create_user_id,content from billboards where name =?";

    //Variables????
    public PreparedStatement select_permission;
    public PreparedStatement insert_user;
    public PreparedStatement select_user;
    public PreparedStatement update_permissions;
    public PreparedStatement update_password;
    public PreparedStatement delete_user;

    public PreparedStatement select_user_id;
    public PreparedStatement select_user_id_token;
    public PreparedStatement update_bill_id;
    public PreparedStatement select_user_id_using_username;
    public PreparedStatement select_user_id_password;
    public PreparedStatement list_user_billboards;
    public PreparedStatement get_user_permissions;

    public PreparedStatement get_billboard_info;
    public PreparedStatement create_billboard;
    public PreparedStatement update_billboard;
    public PreparedStatement delete_billboard_schedules;
    public PreparedStatement delete_billboard;

    public User(){
        conn = ServerThread.getConn();
        try {
            select_permission = conn.prepareStatement(SELECT_USER_PERMISSION);
            insert_user = conn.prepareStatement(INSERT_USER);
            select_user = conn.prepareStatement(SELECT_USER_NAME);
            update_permissions = conn.prepareStatement(UPDATE_PERMISSIONS);
            update_password = conn.prepareStatement(UPDATE_USER_PASS);
            delete_user = conn.prepareStatement(DELETE_USER);
            update_bill_id = conn.prepareStatement(UPDATE_BILL_ID);
            select_user_id = conn.prepareStatement(SELECT_USERNAME_ID);
            select_user_id_token = conn.prepareStatement(SELECT_ID_USING_TOKEN);
            select_user_id_using_username = conn.prepareStatement(SELECT_USER_ID_USERNAME);

            select_user_id_password = conn.prepareStatement(SEARCH_USER_ID_PASSWORD);
            list_user_billboards = conn.prepareStatement(LIST_USER_BILLBOARDS);
            get_user_permissions = conn.prepareStatement(GET_USER_PERMISSIONS);
            
            get_billboard_info = conn.prepareStatement(GET_BILLBOARD_INFO);
            create_billboard = conn.prepareStatement(CREATE_BILL);
            update_billboard = conn.prepareStatement(UPDATE_BILL);
            delete_billboard_schedules = conn.prepareStatement(DELETE_BILL_SCHEDULES);
            delete_billboard = conn.prepareStatement(DELETE_BILL);
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //Close Connections Properly
    public void close() {
        try {
            select_user.close();
            select_permission.close();
            insert_user.close();
            update_password.close();
            update_permissions.close();
            delete_user.close();
            update_bill_id.close();
            select_user_id_token.close();
            select_user_id.close();
            select_user_id_password.close();
            list_user_billboards.close();
            get_billboard_info.close();
            get_user_permissions.close();
            
            create_billboard.close();
            update_billboard.close();
            delete_billboard_schedules.close();
            delete_billboard.close();
            
            if(result != null)
                try{
                    result.close();
                }catch(Exception e){
                    e.printStackTrace();
                    System.out.println("Result close problem");
                }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

     /**Function that Checks Whether the Inputted User Name Matches the Current User
     * (tokens are sent rather than usernames therefore gets username using current token)
     * @param username Take a username and checks
     * @param token
     * @return boolean value on whether the username belongs to the provided token
     * @throws SQLException
     */
    public boolean check_user_and_token(String username, String token) throws SQLException {
        int id = get_user_id(token);
        String name = "";

        //Get Username using Use ID
        select_user_id.setInt(1, id);
        result = select_user_id.executeQuery();

        //Iterate through the table to find User's ID
        while (result.next()) {
            name = result.getString("username");
        }

        if (username.equals(name)){
            result.close();
            return true;
        }
        else {
            result.close();
            return false;
        }
    }

    //Function that Get the ID of a User using the user's token (Helper Function)
    private int get_user_id(String token) throws SQLException {
        //Get User Id of User using Session Token
        int user_id = 0;

        select_user_id_token.setString(1, token);
        result = select_user_id_token.executeQuery();

        //Iterate through the table to find User's ID
        if (result.next()) {
            user_id = result.getInt("user_id");
        }
        result.close();
        return user_id;
    }

     /**
     * Function that Returns Yes or No depending on integer, used for converting boolean values in datbase for control panel
     * @param yes_no Integer that is 0 or 1 that represents True and False
     * @return yes if 1 and no if 0
     */
    private String convert_int(int yes_no){
        if (yes_no == 1){
            return "Yes";
        }
        else {
            return "No";
        }
    }

    
   /**Function that displays a users permissions in a table like format
     * @param st takes an sql statement connection to implement result set
     * @return String contain user permissions
     * @throws SQLException
     */
    public String displayPermissions(Statement st) throws SQLException{

        //Query User Permissions
        ResultSet rs = select_permission.executeQuery();

        //Declare Variables
        String output = "";
        String row = "";
        String name = ";";
        //Variables for Table format
        //String column = String.format("%-15s%-20s%-25s%-25s%-25s%-25s", "User ID", "Username", "Create Billboard", "Edit Billboard", "Edit Schedule", "Edit Users");

        // output each row
        while (rs.next()) {
            
            //Display User Permissions in Table Format
            /*int id = rs.getInt("id");
            String name = rs.getString("username");
            int create_bill_int = rs.getInt("create_billboard");
            int edit_bill_int = rs.getInt("edit_billboard");
            int edit_schedule_int = rs.getInt("edit_schedule");
            int edit_users_int = rs.getInt("edit_users");

            //Convert Int Values to Yes or No Strings
            String create_bill = convert_int(create_bill_int);
            String edit_bill = convert_int(edit_bill_int);
            String edit_schedule = convert_int(edit_schedule_int);
            String edit_users = convert_int(edit_users_int);

            //Format a line String
            String line = String.format("%-15d%-20s%-25s%-25s%-25s%-25s", id, name, create_bill, edit_bill, edit_schedule, edit_users);
            row += line + "\r\n";*/
            
            //Code to Display Permissions only with new line
            int create_bill_int = rs.getInt("create_billboard");
            int edit_bill_int = rs.getInt("edit_billboard");
            int edit_schedule_int = rs.getInt("edit_schedule");
            int edit_users_int = rs.getInt("edit_users");
            name = rs.getString("username");
            //Add the user's permissions to string
            if (create_bill_int == 1){
                row += "Create Billboard" + "<br>";
            }
            if (edit_bill_int == 1){
                row += "Edit Billboard" + "<br>";
            }
            if (edit_schedule_int == 1){
                row += "Edit Schedule" + "<br>";
            }
            if (edit_users_int == 1){
                row += "Edit Users" + "<br>";
            }
            if (row.equals("")){
                row = "User does not have any permissions!";
            }
        }
        //output = String.format("%s\r\n%s", column, row); output for table format

        //Assign row to output
        output = "<html>" + name + " has the following permissions: " + "<br>" + row + "</html>";

        //Close Connections
        rs.close();


        return output;
    }

    /**
     * Function that displays a list of users
     * @param st takes an sql statement connection to implement result set
     * @param query sql query that gets usernames
     * @return String contains a list of usernames
     * @throws SQLException
     */
    public String displayUsers(Statement st, String query) throws SQLException {
        // get all current entries
        ResultSet rs = st.executeQuery(query);

        String row = "";
        String output = "";
        // output each row
        while (rs.next()) {
            String name = rs.getString("username");
            //Format a line String
            String line = name;
            row += line + "\r\n";
        }
        output = row;

        rs.close();
        return output;
    }
}
