package Server;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.util.Base64;
import java.util.Random;


public class Password {
    // static number of iterations and key length 
    private static final int ITERATIONS = 20000;
    private static final int KEY_LENGTH = 384;
    private static final Random RANDOM = new SecureRandom();
    protected static SecureRandom randomToken = new SecureRandom();

    /**
     *
     * @param password
     * @return
     *
     * Computes a salted hash from the given plaintext password
     *         suitable for storing in a database
     */
    public static String getSaltedHash(String password) {

        byte[] salt = new byte[32];
        RANDOM.nextBytes(salt);
        // store the salt with the password
        return Base64.getEncoder().encodeToString(salt)+"$" + hash(password,salt);
    }

    /**
     *
     * @param password
     * @param stored
     * @return
     * @throws NoSuchAlgorithmException
     *
     * Check if the password is valid
     */
    public static boolean check(String hashedPassword, String stored) {

        String[] saltAndHash = stored.split("\\$");
        if (saltAndHash.length != 2) {
            throw new IllegalStateException(
                    "The stored password must have the form 'salt$hash'");
        }

        byte[] StoredSalt = Base64.getDecoder().decode(saltAndHash[0]);
        String StoredHash = saltAndHash[1];
        String InputHash = hash(hashedPassword,StoredSalt);
        return InputHash.equals(StoredHash);
    }

    /**
     *
     * @param password
     * @param salt
     * @return
     * encrypt password with hash
     */
    private static String hash(String password, byte[] salt){
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_LENGTH);
        try {
            SecretKeyFactory skf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
            return Base64.getEncoder().encodeToString(skf.generateSecret(spec).getEncoded());
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            throw new AssertionError("Error while hashing a password: " + e.getMessage(), e);
        } finally {
            spec.clearPassword();
        }
    }
    public static String newToken(){
        long longToken = Math.abs( randomToken.nextLong() );
        String token = Long.toString( longToken, 16 );
        return token;
    }
    
}
