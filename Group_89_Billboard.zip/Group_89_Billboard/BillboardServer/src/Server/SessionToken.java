package Server;

import java.security.SecureRandom;
import java.sql.*;
import java.util.Date;

public class SessionToken {

    protected static SecureRandom randomToken = new SecureRandom();
    ResultSet result;

    private static final String DELETE_token = "DELETE FROM session_tokens WHERE session_token=?";
    private static final String INSERT_token = "INSERT INTO session_tokens (user_id, session_token, end_time) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL ? second))";
    private static final String SELECT_token = "SELECT * from session_tokens WHERE session_token=?";

    private static final String SELECT_USER_ID = "SELECT id from users WHERE username=?";

    private static final String UPADTE_token = "update session_tokens set session_token=?,end_time=DATE_ADD(NOW(),INTERVAL ? second) where user_id = ?";
    private Connection conn;

    public PreparedStatement insert;
    public PreparedStatement delete;
    public PreparedStatement select;
    public PreparedStatement select_user_id;
    public PreparedStatement update_token;

    public SessionToken(){
        conn = ServerThread.getConn();
        try {
            insert = conn.prepareStatement(INSERT_token);
            delete = conn.prepareStatement(DELETE_token);
            select = conn.prepareStatement(SELECT_token);
            select_user_id = conn.prepareStatement(SELECT_USER_ID);
            update_token = conn.prepareStatement(UPADTE_token);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    //Ensure connections are closed properly
    public void close_token(){
        try {
            delete.close();
            insert.close();
            select.close();
            select_user_id.close();
            if(result != null)
                try{
                    result.close();
                }catch(Exception e){
                    e.printStackTrace();
                    System.out.println("Result close problem");
                }
        }catch (SQLException ex){
            ex.printStackTrace();
        }
    }

    /**
     * Function that validates a token by checking whether it is in the database
     * @param st takes an sql statement connection to get result
     * @param String token given token of user
     * @return int user id of given token
     * @throws SQLException
     */
    public int validate_token(Statement st, String token) throws SQLException{
      
        //Remove Expiry Tokens before checking
        token_expiry(st);
        
        select.setString(1, token);
        result = select.executeQuery();
        Integer userid =0;
        
        if(result.next()){
            userid = result.getInt("user_id");
        }

        result.close();
        return userid;
    }

    /**Function that removed a token if it has been in the database over 24 hours
     * @param st takes an sql statement connection to get result
     * @throws SQLException
     */
    public void token_expiry(Statement st) throws SQLException {
        //Use Query to check to see if Token's creation time has surpassed 24 hours
        st = conn.createStatement();
        st.executeQuery("Delete from session_tokens where end_time <= NOW()");
        //st.close();
    }
}
