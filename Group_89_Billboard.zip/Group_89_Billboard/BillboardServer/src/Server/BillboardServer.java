package Server;

import Server.Password;
import Server.PasswordHash;
import Server.ServerThread;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.stream.Collectors;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;

import java.security.NoSuchAlgorithmException;

/**
 * @Main server class. This class includes main(), and is the class that listens
 * for incoming connections and starts ServerThreads to handle those connections
 *
 */
public class BillboardServer {

	/**
	 * @param args
	 */
	//Function to open and read xml files
    public static String readFile(String path) throws IOException {
		BufferedReader reader = new BufferedReader(new FileReader(new File(path)));
		return reader.lines().collect(Collectors.joining(System.lineSeparator()));
	}
	//Main program starts here!
	public static void main(String[] args) {
        //variable for opening a number of threads
        AtomicInteger numThreads = new AtomicInteger(0);
        // the list of threads is kept in a linked list
        ArrayList<Thread> list = new ArrayList<Thread>();
        //a variable used to check if the database exists
        ArrayList<String> dblist=new ArrayList<String>();

        Integer port = 51234; //default server port
        Integer sessiontime = 3600;
        String AdminUser = "admin";
        String AdminPWD = "admin1234";
        String currentDirectory = System.getProperty("user.dir");
        Connection conn = null;
        String sql = "";
        String Billboard_Default ="BillboardServer/src/billboard_default.xml";
        //Load server external configurations
        try (InputStream server_properties = new FileInputStream(currentDirectory+"/BillboardServer/src/server.props")) {

            Properties srv_prop = new Properties();
            // load a properties file
            srv_prop.load(server_properties);

            // get the port property value
            port = Integer.parseInt(srv_prop.getProperty("srv.port"));
            sessiontime = Integer.parseInt(srv_prop.getProperty("srv.sessiontime"));
            AdminUser = srv_prop.getProperty("srv.admuser").toString();
            AdminPWD = srv_prop.getProperty("srv.admuserpwd").toString();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        //check if the database configuration exists, then continue to the server
        try (InputStream db_properties = new FileInputStream(currentDirectory+"/BillboardServer/src/db.props")) {

            Properties db_prop = new Properties();

            // load a properties file
            db_prop.load(db_properties);
            //try the database configuration, and if valid continue to the server
            try {
                // get the db property value

                String db_schema = db_prop.getProperty("jdbc.schema").toString();
                String databaseURL = db_prop.getProperty("jdbc.url").toString()+"/"+db_schema;
                String db_username = db_prop.getProperty("jdbc.username").toString();
                String db_password = db_prop.getProperty("jdbc.password").toString();

                Class.forName("org.mariadb.jdbc.Driver");
                conn = DriverManager.getConnection(databaseURL, db_username, db_password);
                //try to connect ot the database
                if (conn != null) {
                    //Check for database & tables
                    Statement st = conn.createStatement();
                    DatabaseMetaData meta = conn.getMetaData();
                    ResultSet rs = meta.getCatalogs();
                    while (rs.next()) {
                        String listofDatabases=rs.getString("TABLE_CAT");
                        dblist.add(listofDatabases);
                    }
                    if(!dblist.contains(db_schema)){
                        System.out.println("Can not connect to the database!");
                        System.exit(1);
                    }
                    rs.close();
                    //Create the tables if they do not exist
                    sql = "CREATE TABLE IF NOT EXISTS users (id int(11) NOT NULL AUTO_INCREMENT,username varchar(40) NOT NULL,password varchar(256) NOT NULL,create_billboard tinyint(1) NOT NULL,edit_billboard tinyint(1) NOT NULL,edit_schedule tinyint(1) NOT NULL,edit_users tinyint(1) NOT NULL,PRIMARY KEY (id))";
                    st.executeUpdate(sql);

                    sql = "CREATE TABLE IF NOT EXISTS billboards (  id int(11) NOT NULL AUTO_INCREMENT,  create_user_id int(11) NOT NULL, edit_user_id int(11) NOT NULL,  name varchar(100) NOT NULL,  content MEDIUMTEXT NOT NULL,   PRIMARY KEY (id), default_bill tinyint(1) NOT NULL)";
                    st.executeUpdate(sql);

                    sql = "CREATE TABLE IF NOT EXISTS session_tokens (  id int(11) NOT NULL AUTO_INCREMENT,  user_id int(11) NOT NULL,  session_token varchar(250) NOT NULL, end_time datetime NOT NULL,  PRIMARY KEY (id))";
                    st.executeUpdate(sql);

                    sql = "CREATE TABLE IF NOT EXISTS schedule (  id int(11) NOT NULL AUTO_INCREMENT,  billboard_id int(11) NOT NULL,  start_time datetime NOT NULL,  duration int(11) NOT NULL,  recurring_type ENUM ('day','hour','minute'), recurring_count int(11) NOT NULL,  PRIMARY KEY (id))";
                    st.executeUpdate(sql);
                    //check if the default admin exists
                    sql = "SELECT * from users order by id limit 1";
                    ResultSet result = st.executeQuery(sql);
                    //If the default admin user does not exist insert it
                    if (result.next() == false){

                        try {
                            //generate a hashed password the same as the control panel will use.
                            String HashedPWD = PasswordHash.getHashPWD(AdminPWD);
                            //to add the salt to the password
                            String SaltedPwd = Password.getSaltedHash(HashedPWD);
                            sql = "INSERT INTO users (username,password,create_billboard,edit_billboard,edit_schedule,edit_users) VALUES ('"+AdminUser+"','"+SaltedPwd+"',1,1,1,1)";
                            st.executeUpdate(sql);
                            ResultSet resu = st.executeQuery("SELECT LAST_INSERT_ID()");
                            //To add default billboard on initial start up
                            if(resu.next()){
                                Integer id = resu.getInt(1);
                                String default_bill_content = "<?xml version=\"1.0\" encoding=\"UTF-8\"?> <billboard background=\"#0000FF\"> <message colour=\"#FFFF00\">Buy Some Billboards</message> <picture url=\"example.com/fundraiser_image.jpg\" /> <information colour=\"#00FFFF\">Be sure to check us out for more information.</information> </billboard>";
                                File billboard_file = new File(currentDirectory+"/"+Billboard_Default);
                                if (billboard_file.isFile()){
                                    default_bill_content = readFile(currentDirectory+"/"+Billboard_Default);
                                }
                                sql = "INSERT INTO billboards (create_user_id,edit_user_id, name, content, default_bill) VALUES ("+id.toString()+","+id.toString()+", 'Default Billboard','"+default_bill_content+"',1)";
                                st.executeUpdate(sql);
                            }
                        } catch (NoSuchAlgorithmException e) {
                            throw new AssertionError("Error while hashing a password: " + e.getMessage(), e);
                        }
                    }
                    result.close();
                }else{
                    System.out.println("Could not connect to the database");
                }
            }catch (ClassNotFoundException ex) {
                System.out.println("Could not find database driver class");
                //ex.printStackTrace();
                System.exit(1);
            } catch (SQLException ex) {
                System.out.println("An error occurred. No connection to the database.\nOr maybe user/password is invalid!");
                ex.printStackTrace();
                System.exit(1);
            }

            try {
                // listen for incoming connections on port provided
                ServerSocket socket = new ServerSocket(port);
                System.out.println("Server listening on port:"+port.toString());

                //Testing
                // loop (forever) until program is stopped
                while(true) {
                    // accept a new connection
                    Socket client = socket.accept();
                    // start a new ServerThread to handle the connection and send
                    // output to the client
                    Thread thrd = new Thread(new ServerThread(client,db_prop,sessiontime));
                    list.add(thrd);
                    thrd.start();
                    numThreads.incrementAndGet();
                    System.out.println("Thread " + numThreads.get() + " started.");

                }
            }
            catch (IOException ioe){
                ioe.printStackTrace();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }

    }
}
