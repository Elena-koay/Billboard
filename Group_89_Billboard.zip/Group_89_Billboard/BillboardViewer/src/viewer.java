package Viewer;

/*import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;
import javax.swing.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;*/

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.net.ConnectException;
import java.awt.*;
import java.awt.event.*;
import java.io.StringReader;
import java.util.Properties;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.xml.sax.InputSource;

import static java.awt.Font.BOLD;


public class viewer extends JFrame {
    String output;
    Integer port = 51234; //default server port
    String hostName;
    String currentDirectory = System.getProperty("user.dir");
    //String Billboard_Default ="/../billboard_default.xml";
    Boolean ErrorGetBillboard = false;
    JLabel pictureLabel = new JLabel();

    public long BillboardTimeCheck = 5;
    private static Timer timer;

    private static String xmldoc;
    private static JTextArea xmloutput;

    //GetNextBillboard runs every 15seconds
    public void GetNextBillboard() {
        ErrorGetBillboard = false;
        try (InputStream server_properties = new FileInputStream(currentDirectory+"/BillboardViewer/src/client.props")) {

            Properties srv_prop = new Properties();
            // load a properties file
            srv_prop.load(server_properties);

            // get the port property value
            port = Integer.parseInt(srv_prop.getProperty("srv.port"));
            hostName = srv_prop.getProperty("srv.hostname").toString();

        } catch (IOException ex) {
            ex.printStackTrace();
            ErrorGetBillboard = true;
        }

        Socket socket = null;
        BufferedReader input = null;
        PrintWriter output = null;

        try {
            System.out.println("Connecting to Server:"+hostName+" port:"+port);
            socket = new Socket(hostName, port);
            output = new PrintWriter(socket.getOutputStream(), true);
            input = new BufferedReader(new InputStreamReader(socket.getInputStream()));


            output.println("billboard:viewer");

            String answer = "";
            String BillboardContent = "";
            while ((answer = input.readLine()) != null && (!answer.equals("END_MESSAGE"))) {

                if (answer.startsWith("Billboard content:")){
                    BillboardContent = answer.replace("Billboard content:","");
                }else {
                    BillboardContent += answer+"\n";
                }
            }
            //need to show the xmldoc on the GUI
            convertStringToXMLDocument(BillboardContent);

        } catch (UnknownHostException Se) {
            System.err.println("Unknown host: " + hostName);
            ErrorGetBillboard = true;
        }
        catch (ConnectException Se) {
            System.err.println("Connection refused by host: " + hostName);
            ErrorGetBillboard = true;
        }
        catch (IOException Se) {
            Se.printStackTrace();
            ErrorGetBillboard = true;
        }
        catch(NullPointerException Se) {
            System.out.println("NullPointerException thrown!");
            ErrorGetBillboard = true;
        }
        // finally, close the socket and decrement runningThreads
        finally {
            System.out.println("closing");
            try {
                input.close();
                output.close();
                socket.close();
                System.out.flush();
            }
            catch (IOException Se ) {
                System.out.println("Couldn't close socket");
            }
        }
    }


    public static void convertStringToXMLDocument(String xmlString)
    {

        //Parser that produces DOM object trees from XML content
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

        // create a new DocumentBuilderFactory
        System.out.println("{Document} parse: "+xmlString);
        try
        {
            //Create DocumentBuilder with default configuration
            DocumentBuilder docBuilder = factory.newDocumentBuilder();
            Document document;
            //Parse the content to Document object

            document = docBuilder.parse(new InputSource(new StringReader(xmlString)));
            //document = docBuilder.parse(xmlString);
            xmloutput.selectAll();
            xmloutput.replaceSelection("");
            Element root = document.getDocumentElement();
            listNodes(root,"",1) ;

        }
        catch (Exception e)
        {
            System.out.println("Not well formatted XMLDocument:");
            e.printStackTrace();
        }

    }
    private static void listNodes(Element node, String indent, int level) {
        //xmloutput.append(indent + level + ". Element named:  " + node.getTagName() + '\n');
        // get all child nodes

        indent += "   ";
        level++;
        String prefix = indent + level + ". ";
        NodeList children = node.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            int nodeType = child.getNodeType();
            if (nodeType == Node.ELEMENT_NODE)
                listNodes( (Element)child, indent, level);
            else if (nodeType == Node.TEXT_NODE) {
                String text = child.getTextContent();
                text = text.trim();
                if (text.length() > 0)
                    xmloutput.append(text + '\n');

            }
            else
                xmloutput.append(prefix + "(Some other type of node.)\n");
        }
    }

    public static void main(String[] args) throws InterruptedException {
        Action keyListener = new AbstractAction() {

            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                System.out.println("ESCAPE Pressed");
                System.exit (0);
            }
        };
        //checks for mouse click,if mouseclick=> exit
        MouseListener ml = new MouseAdapter() {
            public void mouseClicked(MouseEvent event) {
                //JFrame close
                System.out.println("Mouse Pressed");
                System.exit (0);
            }
        };
        viewer BV = new viewer();
        JFrame jframe = new JFrame("BillBoard Viewer");
        jframe.setLayout(new BorderLayout(1,1));
        //jframe.setExtendedState(JFrame.MAXIMIZED_BOTH);
        jframe.setUndecorated(true);
        jframe.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                // TODO handle the change
                jframe.setExtendedState(JFrame.MAXIMIZED_BOTH);
                jframe.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
                //jframe.setUndecorated(true);
                jframe.setVisible(true);
                jframe.addMouseListener(ml);
            }
        });
        JPanel mainPanel = new JPanel();
        //mainPanel.setBackground(Color.GRAY);
        mainPanel.setLayout(new GridLayout(1,1,1,1));

        xmloutput = new JTextArea();
        xmloutput.setEditable(false);
        xmloutput.setText("");
        xmloutput.setFont(new Font("Arial", Font.PLAIN, 50));
        xmloutput.setAlignmentY(mainPanel.CENTER_ALIGNMENT);
        xmloutput.setAlignmentX(mainPanel.CENTER_ALIGNMENT);
        xmloutput.addMouseListener(ml);
        mainPanel.addMouseListener(ml);
        mainPanel.add(new JScrollPane(xmloutput));
        jframe.setContentPane(mainPanel);

        KeyStroke stroke=KeyStroke.getKeyStroke("ESCAPE");
        InputMap inputMap=mainPanel.getInputMap();
        inputMap.put(stroke,"ESCAPE");
        mainPanel.getActionMap().put("ESCAPE",keyListener);
        xmloutput.getActionMap().put("ESCAPE",keyListener);



        jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jframe.pack();
        jframe.setBackground(Color.GRAY);
        jframe.setVisible(true);
        //Start Timer thread
        final viewer tmr = new viewer();
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                tmr.GetNextBillboard();
            }
        },0,tmr.BillboardTimeCheck * 1000);
    }

}

